# AdMob Integration Design Document

## Overview

This document outlines the technical design for integrating Google AdMob advertisements into the PureIPTV application. The design focuses on non-intrusive ad placement, optimal user experience, and maximum revenue generation while maintaining app performance.

## Architecture

### Ad SDK Integration Architecture

```
┌─────────────────────────────────────────────────────┐
│                    UI Layer                         │
├─────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌─────────────┐ │
│  │ HomeScreen   │ │ LiveScreen   │ │ PlayerScreen│ │
│  │ + Banner Ad  │ │ + Banner Ad  │ │ (Ad-Free)   │ │
│  └──────────────┘ └──────────────┘ └─────────────┘ │
├─────────────────────────────────────────────────────┤
│               AdMob Manager Layer                   │
├─────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌─────────────┐ │
│  │ Banner       │ │ Interstitial │ │ Rewarded    │ │
│  │ Manager      │ │ Manager      │ │ Manager     │ │
│  └──────────────┘ └──────────────┘ └─────────────┘ │
├─────────────────────────────────────────────────────┤
│            Google AdMob SDK                         │
├─────────────────────────────────────────────────────┤
│                Data Layer                           │
│  ┌──────────────┐ ┌──────────────┐ ┌─────────────┐ │
│  │ Premium      │ │ Ad Config    │ │ Analytics   │ │
│  │ Repository   │ │ Repository   │ │ Repository  │ │
│  └──────────────┘ └──────────────┘ └─────────────┘ │
└─────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. AdMobManager (Core Component)

**Purpose:** Central manager for all AdMob operations and configurations.

**Key Responsibilities:**
- Initialize AdMob SDK
- Manage ad configurations
- Handle premium subscription status
- Coordinate between different ad managers

```kotlin
interface AdMobManager {
    fun initialize(context: Context)
    fun isInitialized(): Boolean
    fun isPremiumUser(): Boolean
    fun updatePremiumStatus(isPremium: Boolean)
    suspend fun loadRemoteConfig(): AdConfig
    fun getAdConfig(): AdConfig
}
```

### 2. BannerAdManager

**Purpose:** Manages banner advertisement display and lifecycle.

**Key Responsibilities:**
- Load and display banner ads
- Handle banner ad events
- Manage ad refresh cycles
- Provide Compose integration

```kotlin
interface BannerAdManager {
    fun loadAd(adUnitId: String): Flow<AdState>
    fun refreshAd()
    fun pauseAd()
    fun resumeAd()
    fun destroyAd()
}

@Composable
fun BannerAdView(
    adUnitId: String,
    modifier: Modifier = Modifier,
    onAdLoaded: () -> Unit = {},
    onAdFailedToLoad: (AdError) -> Unit = {}
)
```

### 3. InterstitialAdManager

**Purpose:** Manages full-screen interstitial advertisements.

**Key Responsibilities:**
- Pre-load interstitial ads
- Show ads at appropriate times
- Implement frequency capping
- Track user interaction patterns

```kotlin
interface InterstitialAdManager {
    suspend fun loadAd(adUnitId: String): Boolean
    fun showAd(activity: Activity, onAdDismissed: () -> Unit)
    fun isAdReady(): Boolean
    fun canShowAd(): Boolean // Respects frequency capping
}
```

### 4. RewardedVideoManager

**Purpose:** Manages rewarded video advertisements for premium features.

**Key Responsibilities:**
- Load rewarded video ads
- Handle reward validation
- Manage premium feature unlocking
- Track completion rates

```kotlin
interface RewardedVideoManager {
    suspend fun loadAd(adUnitId: String): Boolean
    fun showAd(
        activity: Activity,
        onRewardEarned: (reward: RewardItem) -> Unit,
        onAdDismissed: () -> Unit
    )
    fun isAdReady(): Boolean
}
```

### 5. NativeAdManager

**Purpose:** Manages native advertisements that blend with app content.

```kotlin
@Composable
fun NativeAdView(
    adUnitId: String,
    template: NativeAdTemplate,
    modifier: Modifier = Modifier
)

enum class NativeAdTemplate {
    SMALL_TEMPLATE_1,
    MEDIUM_TEMPLATE_1,
    LARGE_TEMPLATE_1
}
```

## Data Models

### AdConfig
```kotlin
data class AdConfig(
    val bannerAdUnits: Map<String, String>, // screen -> ad unit id
    val interstitialAdUnit: String,
    val rewardedVideoAdUnit: String,
    val nativeAdUnit: String,
    val interstitialFrequencyMinutes: Int = 30,
    val maxInterstitialsPerHour: Int = 3,
    val bannerRefreshRateSeconds: Int = 60,
    val isAdsEnabled: Boolean = true,
    val testMode: Boolean = false
)
```

### AdState
```kotlin
sealed class AdState {
    object Loading : AdState()
    object Loaded : AdState()
    data class Failed(val error: AdError) : AdState()
    object Displayed : AdState()
    object Clicked : AdState()
}
```

### PremiumFeature
```kotlin
enum class PremiumFeature(val unlockDurationHours: Int) {
    NO_ADS(24),
    UNLIMITED_FAVORITES(24),
    PREMIUM_THEMES(24),
    ADVANCED_SEARCH(24)
}
```

## Ad Placement Strategy

### 1. Home Screen
- **Banner Ad**: Bottom of screen, above bottom navigation
- **Position**: Fixed at bottom, doesn't scroll with content
- **Size**: Adaptive banner (320x50 to 728x90)

### 2. Live TV Screen
- **Banner Ad**: Below search bar and category chips
- **Position**: Scrolls with content
- **Native Ad**: Every 10th item in channel list

### 3. Favorites Screen
- **Banner Ad**: Bottom of screen
- **Native Ad**: Between favorite items (every 5th item)

### 4. Settings Screen
- **Rewarded Video**: "Watch ad for premium features" option
- **Premium Upgrade**: In-app purchase option

### 5. Interstitial Placement Points
- After watching a channel for 5+ minutes and navigating away
- When returning to app after 30+ minutes
- After adding new playlist (success screen)
- Between major navigation flows

## Error Handling

### Ad Loading Failures
```kotlin
sealed class AdError(val message: String) {
    object NetworkError : AdError("Network connection failed")
    object NoFill : AdError("No ads available")
    object InvalidRequest : AdError("Invalid ad request")
    object InternalError : AdError("Internal AdMob error")
    object NoInventory : AdError("No ad inventory")
}
```

### Fallback Strategy
1. **First Failure**: Retry after 30 seconds
2. **Second Failure**: Retry after 2 minutes
3. **Third Failure**: Disable ads for current session
4. **Network Issues**: Queue requests for when network returns

## Testing Strategy

### Unit Tests
- AdMobManager initialization and configuration
- Premium status management
- Ad frequency capping logic
- Error handling scenarios

### Integration Tests
- Ad loading and display in different screens
- Premium feature unlocking flow
- Analytics event tracking
- Configuration updates

### Manual Testing Scenarios
- Test ads in different screen orientations
- Verify ad behavior during video playback
- Test premium subscription flow
- Validate ad-free experience for premium users

## Privacy and Compliance

### GDPR Compliance
- Implement consent management for EU users
- Allow users to opt-out of personalized ads
- Provide clear privacy policy updates

### Data Collection
- Only collect necessary analytics data
- Anonymize user identifiers
- Respect user privacy preferences

## Performance Considerations

### Memory Management
- Lazy load ad SDKs only when needed
- Implement proper ad lifecycle management
- Clean up resources when not in use

### Network Optimization
- Pre-load ads during idle time
- Cache ad configurations locally
- Implement exponential backoff for failed requests

### UI Performance
- Use Compose remember for ad views
- Implement smooth transitions when ads load/fail
- Avoid blocking main thread during ad operations

## Monetization Strategy

### Revenue Optimization
- A/B test different ad placements
- Optimize ad refresh rates based on performance
- Implement mediation for higher fill rates

### Premium Conversion
- Offer valuable premium features
- Provide clear value proposition
- Use rewarded videos to demonstrate premium benefits

## Implementation Phases

### Phase 1: Foundation (Week 1)
- Add AdMob SDK dependencies
- Implement basic AdMobManager
- Create ad configuration system

### Phase 2: Banner Ads (Week 2)
- Implement BannerAdManager
- Create Compose banner ad components
- Add banner ads to main screens

### Phase 3: Interstitial Ads (Week 3)
- Implement InterstitialAdManager
- Add frequency capping logic
- Integrate interstitials at key points

### Phase 4: Advanced Features (Week 4)
- Add rewarded video functionality
- Implement native ad components
- Add premium subscription handling

### Phase 5: Optimization (Week 5)
- Add analytics and monitoring
- Implement remote configuration
- Performance optimization and testing
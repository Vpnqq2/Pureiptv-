# IPTV — Native Android (Android Studio)

Kotlin + Jetpack Compose + Media3 ExoPlayer. Same screens, design tokens, M3U parser, Xtream Codes API, EPG, VOD, series, favorites, history and settings as the original app.

## Open in Android Studio

1. Unzip this folder if you received a zip.
2. Android Studio → **Open** → select the `IPTV-Android` / `android-iptv` folder (the one that contains `settings.gradle.kts`).
3. Let Gradle sync (Android Studio downloads the Gradle wrapper automatically if needed).
4. Pick a device or emulator (API 26+ / Android 8.0) and press **Run**.

## Project layout

```
app/src/main/java/com/iptv/player/
  MainActivity.kt          single activity
  IptvApp.kt               application + repository
  AppViewModel.kt          playlists, favorites, history, settings
  data/parser/M3uParser.kt full M3U / M3U8 parser
  data/xtream/Xtream.kt    Xtream Codes player_api mapping
  data/epg/Xmltv.kt        XMLTV EPG parser
  data/local/Db.kt         Room (channels, series, EPG)
  data/repo/IptvRepository.kt  load / refresh / encrypt passwords
  player/PlayerScreen.kt   Media3 ExoPlayer (HLS + MP4)
  ui/screens/              Home, Live, Favorites, VOD, Series, EPG, Search, Settings…
  ui/theme/                #070B16 / #2F6BFF design system
```

## Features

- Add playlist: M3U file, M3U URL, Xtream Codes (user / pass / server)
- Live TV with category chips, search, favorites filter
- Movies and series catalogs with details and seasons
- XMLTV EPG
- HLS / MP4 playback via Media3
- Encrypted Xtream password in Android Keystore
- Arabic RTL + English (and language picker)
- Dark / light / system theme, accent colors
- Sample demo playlist in `app/src/main/assets/sample-playlist.m3u`

The app is a **player**. You add your own legal playlists. It does not ship channels.

Package: `com.iptv.player` · minSdk 26 · targetSdk 35 · version 1.0.0

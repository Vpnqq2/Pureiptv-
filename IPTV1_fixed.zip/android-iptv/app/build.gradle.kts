plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.devtools.ksp")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
    id("com.google.firebase.firebase-perf")
}

android {
    namespace = "com.black.pureiptv"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.black.pureiptv"
        minSdk = 26
        //noinspection OldTargetApi
        targetSdk = 36
        versionCode = 8
        versionName = "1.9"
        vectorDrawables.useSupportLibrary = true
        
        // Enable NDK debugging symbols for native code
        ndk {
            debugSymbolLevel = "FULL"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.4")
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("io.coil-kt:coil-compose:2.7.0")

    // AdMob
    implementation("com.google.android.gms:play-services-ads:23.0.0")
    
    // User Messaging Platform (UMP) for GDPR/CCPA compliance
    implementation("com.google.android.ump:user-messaging-platform:2.1.0")

    // Firebase BOM
    val firebaseBom = platform("com.google.firebase:firebase-bom:33.4.0")
    implementation(firebaseBom)
    
    // Firebase Analytics
    implementation("com.google.firebase:firebase-analytics-ktx")
    
    // Firebase Crashlytics
    implementation("com.google.firebase:firebase-crashlytics-ktx")
    
    // Firebase Performance Monitoring
    implementation("com.google.firebase:firebase-perf-ktx")
    
    // Firebase Messaging (FCM)
    implementation("com.google.firebase:firebase-messaging-ktx")
}

tasks.register<Zip>("exportStudioZip") {
    archiveFileName.set("IPTV-Android-Studio.zip")
    destinationDirectory.set(rootProject.layout.projectDirectory.dir("dist"))
    from(rootProject.projectDir) {
        exclude("**/.gradle/**", "**/build/**", "dist/**", "**/.idea/**", "**/*.iml")
    }
}

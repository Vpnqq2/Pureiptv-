# Keep your app's classes for debugging
-keep class com.black.pureiptv.** { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# Firebase
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**

# Firebase Crashlytics
-keepattributes SourceFile,LineNumberTable
-keep public class * extends java.lang.Exception
-keep class com.crashlytics.** { *; }
-dontwarn com.crashlytics.**

# AdMob
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**

# Google UMP (User Messaging Platform)
-keep class com.google.android.ump.** { *; }
-dontwarn com.google.android.ump.**

# Media3 (ExoPlayer)
-keep class com.google.android.exoplayer2.** { *; }
-keep class androidx.media3.** { *; }
-dontwarn com.google.android.exoplayer2.**
-dontwarn androidx.media3.**

# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.**

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-dontwarn kotlinx.coroutines.**

# Serialization
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn kotlinx.serialization.**

# Coil
-keep class coil.** { *; }
-dontwarn coil.**

# Navigation
-keepnames class androidx.navigation.** { *; }
-dontwarn androidx.navigation.**

# General Android
-keep class android.** { *; }
-keep class androidx.** { *; }
-dontwarn android.**
-dontwarn androidx.**

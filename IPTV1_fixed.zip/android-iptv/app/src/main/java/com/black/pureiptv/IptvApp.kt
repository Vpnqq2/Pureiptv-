package com.black.pureiptv

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.black.pureiptv.ads.AdManager
import com.black.pureiptv.data.repo.IptvRepository
import com.black.pureiptv.firebase.MyFirebaseMessagingService
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import android.util.Log

class IptvApp : Application() {
    lateinit var repository: IptvRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = IptvRepository(this)
        
        // Initialize Firebase
        FirebaseApp.initializeApp(this)
        
        // Initialize AdMob
        AdManager.initialize(this)
        
        // Initialize Firebase Analytics
        val analytics = FirebaseAnalytics.getInstance(this)
        Log.d("IptvApp", "Firebase Analytics initialized")

        // Initialize Firebase Crashlytics
        val crashlytics = FirebaseCrashlytics.getInstance()
        crashlytics.setCrashlyticsCollectionEnabled(true)
        Log.d("IptvApp", "Firebase Crashlytics initialized")

        // Create notification channel for FCM
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("playback", "Playback", NotificationManager.IMPORTANCE_LOW),
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    MyFirebaseMessagingService.CHANNEL_ID,
                    "Firebase Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }
    }
}


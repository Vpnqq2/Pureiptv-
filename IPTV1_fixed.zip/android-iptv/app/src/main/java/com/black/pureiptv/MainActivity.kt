package com.black.pureiptv

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.session.MediaController
import com.black.pureiptv.ads.GlobalAppOpenAdManager
import com.black.pureiptv.ads.GdprConsentManager
import com.black.pureiptv.data.model.LangId
import com.black.pureiptv.player.PictureInPictureManager
import com.black.pureiptv.ui.nav.AppNav
import com.black.pureiptv.ui.theme.IptvTheme
import com.black.pureiptv.ui.theme.LocalIptvColors
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var pipManager: PictureInPictureManager
    private var isInPictureInPictureMode = false
    private lateinit var pipReceiver: BroadcastReceiver
    
    // Current player state for PiP
    private var currentMediaController: MediaController? = null
    private var currentPipEnabled: Boolean = true
    
    // App Open Ad Manager
    private var appOpenAdManager: com.black.pureiptv.ads.AppOpenAdManager? = null
    
    // Track if we've shown the app open ad for this foreground session
    private var hasShownAppOpenAd = false
    private var appLeaveTime: Long = 0
    
    // Track if GDPR consent has been checked
    private var hasCheckedConsent = false
    
    // Track if user has entered home screen
    private var hasEnteredHomeScreen = false
    
    // Notification permission launcher for Android 13+
    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            android.util.Log.d("MainActivity", "Notification permission granted")
        } else {
            android.util.Log.d("MainActivity", "Notification permission denied")
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        pipManager = PictureInPictureManager(this)
        setupPipReceiver()
        
        // Request notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        
        // Initialize App Open Ad Manager
        appOpenAdManager = com.black.pureiptv.ads.GlobalAppOpenAdManager.getInstance(this)
        
        // Check GDPR consent first
        lifecycleScope.launch {
            if (!hasCheckedConsent) {
                val consentLoaded = GdprConsentManager.requestConsentInfoUpdate(this@MainActivity)
                hasCheckedConsent = true
                
                if (consentLoaded) {
                    // Show consent form if required
                    GdprConsentManager.loadAndShowConsentFormIfRequired(this@MainActivity)
                }
                
                // Preload App Open ad after consent check (but don't show yet)
                appOpenAdManager?.loadAd()
            }
        }
        
        setContent {
            val vm: AppViewModel = viewModel()
            val state by vm.state.collectAsState()
            val dir = if (state.settings.language == LangId.AR) LayoutDirection.Rtl else LayoutDirection.Ltr
            IptvTheme(state.settings.theme, state.settings.accent) {
                CompositionLocalProvider(LocalLayoutDirection provides dir) {
                    val colors = LocalIptvColors.current
                    Surface(Modifier.fillMaxSize(), color = colors.bg) {
                        AppNav(vm)
                    }
                }
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        
        // Reset flag if user was away in background for more than 3 seconds
        if (appLeaveTime > 0 && System.currentTimeMillis() - appLeaveTime > 3000L) {
            hasShownAppOpenAd = false
            appLeaveTime = 0
        }
        
        // Show App Open ad when app comes to foreground (but not from PiP)
        if (!isInPictureInPictureMode && !hasShownAppOpenAd) {
            showAppOpenAdIfAvailable()
        }
    }

    override fun onStop() {
        super.onStop()
        // If an ad is not currently showing, the user is genuinely leaving the app
        if (appOpenAdManager?.isShowingAd == false) {
            appLeaveTime = System.currentTimeMillis()
        }
    }
    
    private fun showAppOpenAdIfAvailable() {
        if (hasShownAppOpenAd) return
        
        // Only show App Open ad after user has entered home screen
        if (!hasEnteredHomeScreen) {
            android.util.Log.d("MainActivity", "User hasn't entered home screen yet, skipping ad")
            return
        }
        
        // Check GDPR consent before showing ads
        if (!GdprConsentManager.getCanShowAds()) {
            android.util.Log.d("MainActivity", "GDPR consent not granted, skipping ad")
            return
        }
        
        val manager = appOpenAdManager ?: return
        
        android.util.Log.d("MainActivity", "Attempting to show App Open ad")
        
        if (manager.canShowAd()) {
            android.util.Log.d("MainActivity", "Ad is available, showing now")
            hasShownAppOpenAd = true
            manager.showAd(this, 
                onAdDismissed = {
                    android.util.Log.d("MainActivity", "App Open ad dismissed")
                    // Reload ad for next time
                    manager.loadAd()
                },
                onAdFailed = {
                    hasShownAppOpenAd = false
                    android.util.Log.d("MainActivity", "App Open ad failed to show")
                    // Load ad for next time
                    manager.loadAd()
                }
            )
        } else {
            android.util.Log.d("MainActivity", "Ad not available, loading for next time")
            // Load ad for next time
            manager.loadAd()
        }
    }
    
    fun onUserEnteredHomeScreen() {
        if (!hasEnteredHomeScreen) {
            hasEnteredHomeScreen = true
            android.util.Log.d("MainActivity", "User entered home screen, showing App Open ad")
            showAppOpenAdIfAvailable()
        }
    }
    
    private fun setupPipReceiver() {
        pipReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    "com.black.pureiptv.PIP_PLAY" -> {
                        currentMediaController?.play()
                        // Update PiP actions after state change
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            pipManager.updatePipActions(this@MainActivity, currentMediaController)
                        }
                    }
                    "com.black.pureiptv.PIP_PAUSE" -> {
                        currentMediaController?.pause()
                        // Update PiP actions after state change
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            pipManager.updatePipActions(this@MainActivity, currentMediaController)
                        }
                    }
                    "com.black.pureiptv.PIP_CLOSE" -> {
                        // Exit PiP mode and return to normal view
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode) {
                            // Bring the activity to foreground
                            val intent = Intent(this@MainActivity, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            }
                            startActivity(intent)
                        }
                    }
                }
            }
        }
        
        val filter = IntentFilter().apply {
            addAction("com.black.pureiptv.PIP_PLAY")
            addAction("com.black.pureiptv.PIP_PAUSE")
            addAction("com.black.pureiptv.PIP_CLOSE")
        }
        
        ContextCompat.registerReceiver(this, pipReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(pipReceiver)
        } catch (e: Exception) {
            // Receiver might not be registered
        }
    }
    
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        
        if (pipManager.shouldEnterPipOnUserLeave(currentMediaController, currentPipEnabled)) {
            pipManager.enterPictureInPictureMode(this, currentMediaController)
        }
    }
    
    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        this.isInPictureInPictureMode = isInPictureInPictureMode
    }
    
    // Public methods for PlayerScreen integration
    fun setCurrentPlayer(controller: MediaController?, pipEnabled: Boolean) {
        currentMediaController = controller
        currentPipEnabled = pipEnabled
    }
    
    fun enterPictureInPictureMode(mediaController: MediaController?): Boolean {
        return pipManager.enterPictureInPictureMode(this, mediaController)
    }
    
    fun isPipSupported(): Boolean = pipManager.isPipSupported()
    
    fun isInPipMode(): Boolean = pipManager.isInPictureInPictureMode(this)
}


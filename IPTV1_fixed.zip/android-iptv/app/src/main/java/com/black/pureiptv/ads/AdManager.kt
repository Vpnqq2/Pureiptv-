package com.black.pureiptv.ads

import android.content.Context
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object AdManager {
    private var isInitialized = false
    
    // Test Ad IDs - Replace with your actual Ad IDs in production
    const val BANNER_AD_ID = "ca-app-pub-2432276637240864/6132684186" // Test Banner
    const val INTERSTITIAL_AD_ID = "ca-app-pub-2432276637240864/6320386443" // Test Interstitial
    const val REWARDED_AD_ID = "ca-app-pub-3940256099942544/5224354917" // Test Rewarded
    const val APP_OPEN_AD_ID = "ca-app-pub-2432276637240864/3694223107" // Test App Open
    const val NATIVE_AD_ID = "ca-app-pub-2432276637240864/7488212931" // Test Native
    
    // Test device IDs - Add your test device IDs here
    private val testDeviceIds = listOf(
        "33BE2250B43518CCDA7DE426D04EE231" // Example test device ID
    )
    
    fun initialize(context: Context) {
        if (isInitialized) return
        
        try {
            // Configure test devices for development
            val config = RequestConfiguration.Builder()
                .setTestDeviceIds(testDeviceIds)
                .build()
            
            MobileAds.setRequestConfiguration(config)
            
            // Initialize MobileAds
            MobileAds.initialize(context) { initializationStatus ->
                isInitialized = true
                // Log initialization status if needed
            }
        } catch (e: Exception) {
            // Handle initialization error
            e.printStackTrace()
        }
    }
    
    fun isReady(): Boolean = isInitialized
    
    fun setConsent(context: Context, consentGiven: Boolean) {
        // Handle consent for GDPR/CCPA compliance
        // This is a placeholder - implement proper consent management
        CoroutineScope(Dispatchers.Main).launch {
            try {
                // Set consent status based on user's choice
                // This should be integrated with a proper consent management solution
                // like Google User Messaging Platform (UMP)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    fun canShowAds(context: Context, adsEnabled: Boolean = true, adsFreeUntil: Long? = null): Boolean {
        // Check if ads can be shown based on consent and other factors
        if (!isInitialized) return false
        
        // Check GDPR consent - allow ads if consent not loaded yet (will be checked later)
        // This is a conservative approach
        if (GdprConsentManager.getCanShowAds() == false) return false
        
        // Check if ads are disabled in settings
        if (!adsEnabled) return false
        
        // Check if user has ads-free period
        if (adsFreeUntil != null && System.currentTimeMillis() < adsFreeUntil) {
            return false
        }
        
        return true
    }
}
package com.black.pureiptv.ads

import android.app.Activity
import android.content.Context
import android.os.Bundle
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AppOpenAdManager(private val context: Context) {
    private var appOpenAd: AppOpenAd? = null
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading
    
    private val _isLoaded = MutableStateFlow(false)
    val isLoaded: StateFlow<Boolean> = _isLoaded
    
    var isShowingAd: Boolean = false
        private set
        
    private var lastAdDismissedTime: Long = 0
    private val MIN_SHOW_INTERVAL_MS = 15000L // 15s cooldown between app open ads
    
    private var loadTime: Long = 0
    private val AD_EXPIRATION_TIME = 4 * 3600 * 1000 // 4 hours in milliseconds
    
    fun loadAd(adUnitId: String = AdManager.APP_OPEN_AD_ID, adsEnabled: Boolean = true, adsFreeUntil: Long? = null) {
        if (!AdManager.canShowAds(context, adsEnabled, adsFreeUntil)) {
            android.util.Log.d("AppOpenAd", "Ads not allowed: enabled=$adsEnabled, freeUntil=$adsFreeUntil")
            return
        }
        
        if (_isLoading.value) {
            android.util.Log.d("AppOpenAd", "Already loading ad")
            return // Already loading
        }
        
        // Check if ad is still valid (not expired)
        if (isAdValid()) {
            android.util.Log.d("AppOpenAd", "Ad is still valid, no need to reload")
            return // Ad is still valid, no need to reload
        }
        
        _isLoading.value = true
        android.util.Log.d("AppOpenAd", "Loading ad with unit ID: $adUnitId")
        
        val request = com.google.android.gms.ads.AdRequest.Builder().build()
        
        AppOpenAd.load(
            context,
            adUnitId,
            request,
            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
            object : com.google.android.gms.ads.appopen.AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    loadTime = System.currentTimeMillis()
                    _isLoading.value = false
                    _isLoaded.value = true
                    android.util.Log.d("AppOpenAd", "Ad loaded successfully")
                    
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            // Ad dismissed, load next ad
                            appOpenAd = null
                            _isLoaded.value = false
                            android.util.Log.d("AppOpenAd", "Ad dismissed, loading next ad")
                            loadAd(adUnitId, adsEnabled, adsFreeUntil) // Preload next ad
                        }
                        
                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            // Ad failed to show
                            appOpenAd = null
                            _isLoaded.value = false
                            android.util.Log.d("AppOpenAd", "Ad failed to show: ${adError.message}")
                            loadAd(adUnitId, adsEnabled, adsFreeUntil) // Try loading again
                        }
                        
                        override fun onAdShowedFullScreenContent() {
                            // Ad shown
                            _isLoaded.value = false
                            android.util.Log.d("AppOpenAd", "Ad shown successfully")
                        }
                    }
                }
                
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    appOpenAd = null
                    _isLoading.value = false
                    _isLoaded.value = false
                    android.util.Log.d("AppOpenAd", "Ad failed to load: ${loadAdError.message}")
                }
            }
        )
    }
    
    fun showAd(activity: Activity, onAdDismissed: () -> Unit = {}, onAdFailed: () -> Unit = {}, adsEnabled: Boolean = true, adsFreeUntil: Long? = null) {
        android.util.Log.d("AppOpenAd", "showAd called - canShowAds: ${AdManager.canShowAds(context, adsEnabled, adsFreeUntil)}, isAdValid: ${isAdValid()}, appOpenAd: ${appOpenAd != null}")
        
        if (!AdManager.canShowAds(context, adsEnabled, adsFreeUntil)) {
            android.util.Log.d("AppOpenAd", "Ads not allowed, calling onAdFailed")
            onAdFailed()
            return
        }
        
        if (!isAdValid()) {
            android.util.Log.d("AppOpenAd", "Ad not valid, loading new ad")
            loadAd(adsEnabled = adsEnabled, adsFreeUntil = adsFreeUntil)
            onAdFailed()
            return
        }
        
        val ad = appOpenAd
        if (ad != null) {
            android.util.Log.d("AppOpenAd", "Showing ad")
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    isShowingAd = false
                    lastAdDismissedTime = System.currentTimeMillis()
                    _isLoaded.value = false
                    onAdDismissed()
                    android.util.Log.d("AppOpenAd", "Ad dismissed by user, loading next ad")
                    // Preload next ad
                    loadAd(adsEnabled = adsEnabled, adsFreeUntil = adsFreeUntil)
                }
                
                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    appOpenAd = null
                    isShowingAd = false
                    lastAdDismissedTime = System.currentTimeMillis()
                    _isLoaded.value = false
                    onAdFailed()
                    android.util.Log.d("AppOpenAd", "Ad failed to show: ${adError.message}")
                    loadAd(adsEnabled = adsEnabled, adsFreeUntil = adsFreeUntil)
                }
                
                override fun onAdShowedFullScreenContent() {
                    isShowingAd = true
                    _isLoaded.value = false
                    android.util.Log.d("AppOpenAd", "Ad is now showing on screen")
                }
            }
            
            ad.show(activity)
        } else {
            android.util.Log.d("AppOpenAd", "No ad available, loading new ad")
            loadAd(adsEnabled = adsEnabled, adsFreeUntil = adsFreeUntil)
            onAdFailed()
        }
    }
    
    fun canShowAd(): Boolean = appOpenAd != null && _isLoaded.value && isAdValid() && !isShowingAd && (System.currentTimeMillis() - lastAdDismissedTime > MIN_SHOW_INTERVAL_MS)
    
    private fun isAdValid(): Boolean {
        val currentTime = System.currentTimeMillis()
        return appOpenAd != null && (currentTime - loadTime) < AD_EXPIRATION_TIME
    }
    
    fun destroy() {
        appOpenAd = null
        _isLoading.value = false
        _isLoaded.value = false
    }
}

// Singleton instance for global access
object GlobalAppOpenAdManager {
    private var instance: AppOpenAdManager? = null
    
    fun getInstance(context: Context): AppOpenAdManager {
        return instance ?: AppOpenAdManager(context.applicationContext).also {
            instance = it
        }
    }
    
    fun destroy() {
        instance?.destroy()
        instance = null
    }
}
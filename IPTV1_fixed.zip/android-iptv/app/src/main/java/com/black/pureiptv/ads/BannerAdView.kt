package com.black.pureiptv.ads

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

@Composable
fun BannerAdView(
    adUnitId: String = AdManager.BANNER_AD_ID,
    modifier: Modifier = Modifier,
    adsEnabled: Boolean = true,
    adsFreeUntil: Long? = null
) {
    val context = LocalContext.current
    val isInPreview = LocalInspectionMode.current
    
    // Don't show ads in preview mode
    if (isInPreview) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            // Placeholder for preview
        }
        return
    }
    
    // Check if ads can be shown
    if (!AdManager.canShowAds(context, adsEnabled, adsFreeUntil)) {
        return
    }
    
    var adView by remember { mutableStateOf<AdView?>(null) }
    
    DisposableEffect(adUnitId) {
        val newAdView = AdView(context).apply {
            setAdSize(AdSize.BANNER)
            setAdUnitId(adUnitId)
            
            val adRequest = AdRequest.Builder().build()
            loadAd(adRequest)
        }
        
        adView = newAdView
        
        onDispose {
            adView?.destroy()
        }
    }
    
    adView?.let { view ->
        AndroidView(
            factory = { view },
            modifier = modifier.fillMaxWidth(),
            update = { it }
        )
    }
}

@Composable
fun AdaptiveBannerAdView(
    adUnitId: String = AdManager.BANNER_AD_ID,
    modifier: Modifier = Modifier,
    adsEnabled: Boolean = true,
    adsFreeUntil: Long? = null
) {
    val context = LocalContext.current
    val isInPreview = LocalInspectionMode.current
    
    // Don't show ads in preview mode
    if (isInPreview) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            // Placeholder for preview
        }
        return
    }
    
    // Check if ads can be shown
    if (!AdManager.canShowAds(context, adsEnabled, adsFreeUntil)) {
        return
    }
    
    var adView by remember { mutableStateOf<AdView?>(null) }
    
    DisposableEffect(adUnitId) {
        val newAdView = AdView(context).apply {
            // Use adaptive banner size
            val adSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
                context,
                320
            )
            setAdSize(adSize)
            setAdUnitId(adUnitId)
            
            val adRequest = AdRequest.Builder().build()
            loadAd(adRequest)
        }
        
        adView = newAdView
        
        onDispose {
            adView?.destroy()
        }
    }
    
    adView?.let { view ->
        AndroidView(
            factory = { view },
            modifier = modifier.fillMaxWidth(),
            update = { it }
        )
    }
}
package com.black.pureiptv.ads

import android.app.Activity
import android.util.Log
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.ConsentInformation
import com.google.android.ump.FormError
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

object GdprConsentManager {
    private const val TAG = "GdprConsentManager"
    private var canShowAds = false
    private var isConsentLoaded = false
    private var consentInformation: ConsentInformation? = null
    
    suspend fun requestConsentInfoUpdate(activity: Activity): Boolean {
        return withContext(Dispatchers.Main) {
            try {
                val parameters = ConsentRequestParameters.Builder()
                    .setTagForUnderAgeOfConsent(false)
                    .build()
                
                // Use the static method to get consent information
                consentInformation = UserMessagingPlatform.getConsentInformation(activity)
                
                val result = suspendCancellableCoroutine<Boolean> { continuation ->
                    consentInformation?.requestConsentInfoUpdate(
                        activity,
                        parameters,
                        {
                            Log.d(TAG, "Consent info update successful")
                            continuation.resume(true)
                        },
                        { error ->
                            Log.e(TAG, "Consent info update failed: ${error.message}")
                            continuation.resume(false)
                        }
                    )
                }
                
                if (result) {
                    isConsentLoaded = true
                    canShowAds = consentInformation?.canRequestAds() ?: false
                    Log.d(TAG, "Consent loaded successfully. Can show ads: $canShowAds")
                    true
                } else {
                    Log.w(TAG, "Consent info update failed")
                    false
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading consent form", e)
                false
            }
        }
    }
    
    suspend fun loadAndShowConsentFormIfRequired(activity: Activity): Boolean {
        return withContext(Dispatchers.Main) {
            try {
                if (consentInformation == null) {
                    Log.w(TAG, "Consent information not loaded")
                    return@withContext false
                }
                
                val result = suspendCancellableCoroutine<Boolean> { continuation ->
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                        activity,
                        object : com.google.android.ump.ConsentForm.OnConsentFormDismissedListener {
                            override fun onConsentFormDismissed(formError: FormError?) {
                                Log.d(TAG, "Consent form dismissed. Error: $formError")
                                canShowAds = consentInformation?.canRequestAds() ?: false
                                continuation.resume(formError == null)
                            }
                        }
                    )
                }
                
                result
            } catch (e: Exception) {
                Log.e(TAG, "Error showing consent form", e)
                false
            }
        }
    }
    
    fun getCanShowAds(): Boolean = canShowAds
    
    fun resetConsent() {
        canShowAds = false
        isConsentLoaded = false
        consentInformation = null
    }
    
    fun destroy() {
        consentInformation = null
    }
}
package com.black.pureiptv.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class InterstitialAdManager(private val context: Context) {
    private var interstitialAd: InterstitialAd? = null
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading
    
    private val _isLoaded = MutableStateFlow(false)
    val isLoaded: StateFlow<Boolean> = _isLoaded
    
    // Counter to control ad frequency - show ad every 3 channel opens
    private var channelOpenCount = 0
    private val AD_FREQUENCY = 3
    
    fun loadAd(adUnitId: String = AdManager.INTERSTITIAL_AD_ID, adsEnabled: Boolean = true, adsFreeUntil: Long? = null) {
        if (!AdManager.canShowAds(context, adsEnabled, adsFreeUntil)) {
            return
        }
        
        if (_isLoading.value) {
            return // Already loading
        }
        
        _isLoading.value = true
        
        val adRequest = com.google.android.gms.ads.AdRequest.Builder().build()
        
        InterstitialAd.load(context, adUnitId, adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                interstitialAd = ad
                _isLoading.value = false
                _isLoaded.value = true
                
                // Set full screen content callback
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        // Ad dismissed, load next ad
                        interstitialAd = null
                        _isLoaded.value = false
                        loadAd(adUnitId, adsEnabled, adsFreeUntil) // Preload next ad
                    }
                    
                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        // Ad failed to show
                        interstitialAd = null
                        _isLoaded.value = false
                        loadAd(adUnitId, adsEnabled, adsFreeUntil) // Try loading again
                    }
                    
                    override fun onAdShowedFullScreenContent() {
                        // Ad shown
                        _isLoaded.value = false
                    }
                }
            }
            
            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                interstitialAd = null
                _isLoading.value = false
                _isLoaded.value = false
            }
        })
    }
    
    fun showAd(activity: Activity, onAdDismissed: () -> Unit = {}, onAdFailed: () -> Unit = {}, adsEnabled: Boolean = true, adsFreeUntil: Long? = null) {
        if (!AdManager.canShowAds(context, adsEnabled, adsFreeUntil)) {
            onAdFailed()
            return
        }
        
        // Increment counter and check if we should show ad
        channelOpenCount++
        if (channelOpenCount % AD_FREQUENCY != 0) {
            onAdFailed() // Don't show ad this time
            return
        }
        
        val ad = interstitialAd
        if (ad != null) {
            ad.show(activity)
            onAdDismissed()
        } else {
            // Ad not loaded, try loading it
            loadAd(AdManager.INTERSTITIAL_AD_ID, adsEnabled, adsFreeUntil)
            onAdFailed()
        }
    }
    
    fun canShowAd(): Boolean = interstitialAd != null && _isLoaded.value
    
    fun destroy() {
        interstitialAd = null
        _isLoading.value = false
        _isLoaded.value = false
    }
}

// Singleton instance for global access
object GlobalInterstitialAdManager {
    private var instance: InterstitialAdManager? = null
    
    fun getInstance(context: Context): InterstitialAdManager {
        return instance ?: InterstitialAdManager(context.applicationContext).also {
            instance = it
        }
    }
    
    fun destroy() {
        instance?.destroy()
        instance = null
    }
}
package com.black.pureiptv.ads

import android.graphics.Typeface
import android.graphics.Color as AndroidColor
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RatingBar
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView

@Composable
fun NativeAdView(
    adUnitId: String = AdManager.NATIVE_AD_ID,
    modifier: Modifier = Modifier,
    adsEnabled: Boolean = true,
    adsFreeUntil: Long? = null
) {
    val context = LocalContext.current
    val isInPreview = LocalInspectionMode.current
    
    // Don't show ads in preview mode
    if (isInPreview) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(250.dp)
                .background(Color.LightGray.copy(alpha = 0.3f))
        ) {
            // Placeholder for preview
        }
        return
    }
    
    // Check if ads can be shown
    if (!AdManager.canShowAds(context, adsEnabled, adsFreeUntil)) {
        return
    }
    
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    
    DisposableEffect(adUnitId) {
        isLoading = true
        
        val adLoader = AdLoader.Builder(context, adUnitId)
            .forNativeAd { ad ->
                nativeAd = ad
                isLoading = false
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    isLoading = false
                }
            })
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()
        
        adLoader.loadAd(AdRequest.Builder().build())
        
        onDispose {
            nativeAd?.destroy()
        }
    }
    
    nativeAd?.let { ad ->
        AndroidView(
            factory = { ctx ->
                val density = ctx.resources.displayMetrics.density
                
                NativeAdView(ctx).apply {
                    // Create professional ad layout with clear indication
                    val outerLayout = LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                        background = ColorDrawable(AndroidColor.parseColor("#F5F5F5")) // Subtle light gray background
                        setPadding((8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt())
                    }
                    
                    // Ad label container - more elegant design
                    val adLabelLayout = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                        gravity = android.view.Gravity.CENTER
                        setPadding(0, (6 * density).toInt(), 0, (6 * density).toInt())
                    }
                    
                    // "Advertisement" label - professional styling
                    val adLabel = TextView(ctx).apply {
                        text = "Advertisement"
                        textSize = 11f
                        setTextColor(AndroidColor.parseColor("#AAAAAA")) // Subtle gray
                        setTypeface(null, Typeface.BOLD)
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                    }
                    adLabelLayout.addView(adLabel)
                    outerLayout.addView(adLabelLayout)
                    
                    // Ad content container - card-like design
                    val layout = LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                        setPadding(
                            (16 * density).toInt(),
                            (16 * density).toInt(),
                            (16 * density).toInt(),
                            (16 * density).toInt()
                        )
                        background = ColorDrawable(AndroidColor.WHITE)
                    }
                    
                    // Media (if available) or Icon
                    ad.mediaContent?.let {
                        val mediaView = MediaView(ctx).apply {
                            layoutParams = LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                (150 * density).toInt()
                            )
                        }
                        mediaView.id = View.generateViewId()
                        this.mediaView = mediaView
                        layout.addView(mediaView)
                    } ?: run {
                        ad.icon?.let { icon ->
                            val iconView = ImageView(ctx).apply {
                                setImageDrawable(icon.drawable)
                                scaleType = ImageView.ScaleType.CENTER_CROP
                                layoutParams = LinearLayout.LayoutParams(
                                    (80 * density).toInt(),
                                    (80 * density).toInt()
                                )
                            }
                            iconView.id = View.generateViewId()
                            this.iconView = iconView
                            layout.addView(iconView)
                        }
                    }
                    
                    // Content container
                    val contentLayout = LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                    }
                    
                    // Headline
                    val headlineView = TextView(ctx).apply {
                        text = ad.headline
                        textSize = 16f
                        setTextColor(AndroidColor.BLACK)
                        setTypeface(null, Typeface.BOLD)
                    }
                    headlineView.id = View.generateViewId()
                    this.headlineView = headlineView
                    contentLayout.addView(headlineView)
                    
                    // Body
                    val bodyView = TextView(ctx).apply {
                        text = ad.body
                        textSize = 14f
                        setTextColor(AndroidColor.DKGRAY)
                        maxLines = 2
                    }
                    bodyView.id = View.generateViewId()
                    this.bodyView = bodyView
                    contentLayout.addView(bodyView)
                    
                    // Rating (if available)
                    ad.starRating?.let { starRating ->
                        val ratingBar = RatingBar(ctx).apply {
                            rating = starRating.toFloat()
                            numStars = 5
                            layoutParams = LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            )
                        }
                        ratingBar.id = View.generateViewId()
                        this.starRatingView = ratingBar
                        contentLayout.addView(ratingBar)
                    }
                    
                    layout.addView(contentLayout)
                    
                    // Call to action button
                    val ctaView = Button(ctx).apply {
                        text = ad.callToAction
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                    }
                    ctaView.id = View.generateViewId()
                    this.callToActionView = ctaView
                    layout.addView(ctaView)
                    
                    // Add the content layout to the outer layout
                    outerLayout.addView(layout)
                    
                    // Add the outer layout to the NativeAdView
                    this.addView(outerLayout)

                    // Register the native ad object with the NativeAdView
                    setNativeAd(ad)
                }
            },
            modifier = modifier.fillMaxWidth(),
            update = { it }
        )
    }
}

package com.black.pureiptv.data.epg

import com.black.pureiptv.data.model.EpgProgram
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

object Xmltv {
    fun parse(xml: String, limit: Int = 8000): List<EpgProgram> {
        val factory = XmlPullParserFactory.newInstance().apply { isNamespaceAware = false }
        val parser = factory.newPullParser()
        parser.setInput(StringReader(xml))
        val out = mutableListOf<EpgProgram>()
        var event = parser.eventType
        var channel = ""
        var start = 0L
        var stop = 0L
        var title = "Program"
        var desc: String? = null
        var category: String? = null
        var inTitle = false
        var inDesc = false
        var inCat = false
        while (event != XmlPullParser.END_DOCUMENT && out.size < limit) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "programme" -> {
                        channel = parser.getAttributeValue(null, "channel").orEmpty()
                        start = xmlTime(parser.getAttributeValue(null, "start"))
                        stop = xmlTime(parser.getAttributeValue(null, "stop"))
                        title = "Program"
                        desc = null
                        category = null
                    }
                    "title" -> inTitle = true
                    "desc" -> inDesc = true
                    "category" -> inCat = true
                }
                XmlPullParser.TEXT -> {
                    val t = parser.text?.trim().orEmpty()
                    if (t.isNotEmpty()) when {
                        inTitle -> title = t
                        inDesc -> desc = t
                        inCat -> category = t
                    }
                }
                XmlPullParser.END_TAG -> when (parser.name) {
                    "title" -> inTitle = false
                    "desc" -> inDesc = false
                    "category" -> inCat = false
                    "programme" -> {
                        if (channel.isNotBlank() && start > 0) {
                            out += EpgProgram(
                                id = "$channel:$start",
                                channelTvgId = channel,
                                title = title,
                                description = desc,
                                start = start,
                                end = if (stop > 0) stop else start + 30 * 60_000,
                                category = category,
                            )
                        }
                    }
                }
            }
            event = parser.next()
        }
        return out
    }

    fun nowAndNext(programs: List<EpgProgram>, at: Long = System.currentTimeMillis()): Pair<EpgProgram?, EpgProgram?> {
        val sorted = programs.sortedBy { it.start }
        val current = sorted.find { it.start <= at && it.end > at }
        val next = sorted.find { it.start > at }
        return current to next
    }

    private fun xmlTime(value: String?): Long {
        if (value.isNullOrBlank()) return 0
        val m = Regex("""^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{4})?""").find(value)
        if (m == null) return 0
        val tz = m.groupValues.getOrNull(7)?.let {
            TimeZone.getTimeZone("GMT${it.dropLast(2)}:${it.takeLast(2)}")
        } ?: TimeZone.getTimeZone("UTC")
        val fmt = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply { timeZone = tz }
        return runCatching {
            fmt.parse(m.groupValues[1] + m.groupValues[2] + m.groupValues[3] + m.groupValues[4] + m.groupValues[5] + m.groupValues[6])?.time
        }.getOrNull() ?: 0
    }
}


package com.black.pureiptv.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.data.model.ContentKind
import com.black.pureiptv.data.model.EpgProgram
import com.black.pureiptv.data.model.SeriesShow

@Entity(tableName = "channels", indices = [Index("playlistId"), Index("kind")])
data class ChannelEntity(
    @PrimaryKey val id: String,
    val playlistId: String,
    val name: String,
    val url: String,
    val logo: String?,
    val groupName: String,
    val tvgId: String?,
    val tvgName: String?,
    val kind: String,
    val number: Int,
    val duration: Int?,
    val plot: String?,
    val year: String?,
    val rating: String?,
    val genre: String?,
    val poster: String?,
    val streamId: String?,
    val container: String?,
    val seriesId: String?,
    val season: Int?,
    val episode: Int?,
    val categoryId: String?,
) {
    fun toModel() = Channel(
        id, playlistId, name, url, logo, groupName, tvgId, tvgName,
        ContentKind.valueOf(kind), number, duration, plot, year, rating, genre, poster,
        streamId, container, seriesId, season, episode, categoryId,
    )

    companion object {
        fun from(c: Channel) = ChannelEntity(
            c.id, c.playlistId, c.name, c.url, c.logo, c.group, c.tvgId, c.tvgName,
            c.kind.name, c.number, c.duration, c.plot, c.year, c.rating, c.genre, c.poster,
            c.streamId, c.container, c.seriesId, c.season, c.episode, c.categoryId,
        )
    }
}

@Entity(tableName = "series", indices = [Index("playlistId")])
data class SeriesEntity(
    @PrimaryKey val id: String,
    val playlistId: String,
    val seriesId: String,
    val name: String,
    val plot: String?,
    val poster: String?,
    val backdrop: String?,
    val genre: String?,
    val year: String?,
    val rating: String?,
    val categoryId: String?,
    val categoryName: String?,
) {
    fun toModel() = SeriesShow(id, playlistId, seriesId, name, plot, poster, backdrop, genre, year, rating, categoryId, categoryName)

    companion object {
        fun from(s: SeriesShow) = SeriesEntity(
            s.id, s.playlistId, s.seriesId, s.name, s.plot, s.poster, s.backdrop, s.genre, s.year, s.rating, s.categoryId, s.categoryName,
        )
    }
}

@Entity(tableName = "epg", indices = [Index("channelTvgId")])
data class EpgEntity(
    @PrimaryKey val id: String,
    val channelTvgId: String,
    val title: String,
    val description: String?,
    val start: Long,
    val end: Long,
    val category: String?,
) {
    fun toModel() = EpgProgram(id, channelTvgId, title, description, start, end, category)

    companion object {
        fun from(p: EpgProgram) = EpgEntity(p.id, p.channelTvgId, p.title, p.description, p.start, p.end, p.category)
    }
}

@Dao
interface ChannelDao {
    @Query("SELECT * FROM channels WHERE playlistId = :playlistId")
    suspend fun forPlaylist(playlistId: String): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE playlistId = :playlistId AND kind = :kind")
    suspend fun forPlaylistKind(playlistId: String, kind: String): List<ChannelEntity>

    @Query("SELECT COUNT(*) FROM channels WHERE playlistId = :playlistId AND kind = :kind")
    suspend fun countKind(playlistId: String, kind: String): Int

    @Query("SELECT * FROM channels")
    suspend fun all(): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE id = :id")
    suspend fun get(id: String): ChannelEntity?

    @Query("DELETE FROM channels WHERE playlistId = :playlistId")
    suspend fun deletePlaylist(playlistId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ChannelEntity>)

    @Query(
        """SELECT * FROM channels WHERE (:playlistId IS NULL OR playlistId = :playlistId)
           AND (name LIKE '%' || :q || '%' OR groupName LIKE '%' || :q || '%' OR tvgName LIKE '%' || :q || '%')
           LIMIT :limit""",
    )
    suspend fun search(q: String, playlistId: String?, limit: Int): List<ChannelEntity>
}

@Dao
interface SeriesDao {
    @Query("SELECT * FROM series WHERE playlistId = :playlistId")
    suspend fun forPlaylist(playlistId: String): List<SeriesEntity>

    @Query("SELECT * FROM series WHERE id = :id")
    suspend fun get(id: String): SeriesEntity?

    @Query("DELETE FROM series WHERE playlistId = :playlistId")
    suspend fun deletePlaylist(playlistId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<SeriesEntity>)
}

@Dao
interface EpgDao {
    @Query("SELECT * FROM epg WHERE channelTvgId = :tvgId ORDER BY start")
    suspend fun forChannel(tvgId: String): List<EpgEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<EpgEntity>)

    @Query("DELETE FROM epg")
    suspend fun clear()
}

@Database(entities = [ChannelEntity::class, SeriesEntity::class, EpgEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun channels(): ChannelDao
    abstract fun series(): SeriesDao
    abstract fun epg(): EpgDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(context: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDb::class.java, "iptv-client")
                .fallbackToDestructiveMigration()
                .build()
                .also { instance = it }
        }
    }
}


package com.black.pureiptv.data.model

import kotlinx.serialization.Serializable

enum class PlaylistType { M3U, XTREAM }
enum class ContentKind { LIVE, MOVIE, SERIES }
enum class PlaylistStatus { IDLE, CONNECTING, CONNECTED, ERROR }
enum class PlaylistSource { URL, FILE, XTREAM }
enum class ThemeMode { DARK, LIGHT, SYSTEM }
enum class AccentId { BLUE, TEAL, GREEN, AMBER }
enum class LangId { EN, AR, FR, ES, DE, IT, TR }
enum class QualityPref { AUTO, Q1080, Q720, Q480 }

@Serializable
data class XtreamUserInfo(
    val username: String = "",
    val status: String? = null,
    val expDate: String? = null,
    val activeCons: String? = null,
    val maxCons: String? = null,
    val createdAt: String? = null,
    val isTrial: String? = null,
    val timezone: String? = null,
    val message: String? = null,
    val serverProtocol: String? = null,
    val serverPort: String? = null,
)

@Serializable
data class Playlist(
    val id: String,
    val name: String,
    val type: PlaylistType,
    val source: PlaylistSource,
    val createdAt: Long,
    val updatedAt: Long,
    val channelCount: Int = 0,
    val groupCount: Int = 0,
    val movieCount: Int = 0,
    val seriesCount: Int = 0,
    val status: PlaylistStatus = PlaylistStatus.IDLE,
    val lastError: String? = null,
    val epgUrl: String? = null,
    val m3uUrl: String? = null,
    val fileName: String? = null,
    val serverUrl: String? = null,
    val username: String? = null,
    val passwordEnc: String? = null,
    val xtreamInfo: XtreamUserInfo? = null,
)

@Serializable
data class Channel(
    val id: String,
    val playlistId: String,
    val name: String,
    val url: String,
    val logo: String? = null,
    val group: String = "Uncategorized",
    val tvgId: String? = null,
    val tvgName: String? = null,
    val kind: ContentKind = ContentKind.LIVE,
    val number: Int = 0,
    val duration: Int? = null,
    val plot: String? = null,
    val year: String? = null,
    val rating: String? = null,
    val genre: String? = null,
    val poster: String? = null,
    val streamId: String? = null,
    val container: String? = null,
    val seriesId: String? = null,
    val season: Int? = null,
    val episode: Int? = null,
    val categoryId: String? = null,
)

@Serializable
data class SeriesShow(
    val id: String,
    val playlistId: String,
    val seriesId: String,
    val name: String,
    val plot: String? = null,
    val poster: String? = null,
    val backdrop: String? = null,
    val genre: String? = null,
    val year: String? = null,
    val rating: String? = null,
    val categoryId: String? = null,
    val categoryName: String? = null,
)

@Serializable
data class Favorite(
    val id: String,
    val playlistId: String,
    val kind: ContentKind,
    val name: String,
    val logo: String? = null,
    val group: String? = null,
    val addedAt: Long,
)

@Serializable
data class WatchHistory(
    val id: String,
    val playlistId: String,
    val channelId: String,
    val name: String,
    val logo: String? = null,
    val group: String? = null,
    val kind: ContentKind,
    val watchedAt: Long,
    val position: Long? = null,
)

@Serializable
data class EpgProgram(
    val id: String,
    val channelTvgId: String,
    val title: String,
    val description: String? = null,
    val start: Long,
    val end: Long,
    val category: String? = null,
)

data class ParseStats(
    val channels: Int,
    val groups: Int,
    val movies: Int,
    val series: Int,
    val durationMs: Long,
)

data class ParseResult(
    val channels: List<Channel>,
    val movies: List<Channel>,
    val series: List<SeriesShow>,
    val epgUrl: String?,
    val stats: ParseStats,
)

@Serializable
data class Settings(
    val theme: ThemeMode = ThemeMode.DARK,
    val accent: AccentId = AccentId.AMBER,
    val language: LangId = LangId.EN,
    val autoPlay: Boolean = true,
    val rememberLastChannel: Boolean = true,
    val lastChannelId: String? = null,
    val lastPlaylistId: String? = null,
    val autoFullscreen: Boolean = false,
    val defaultQuality: QualityPref = QualityPref.AUTO,
    val subtitles: Boolean = false,
    val autoLoadLast: Boolean = true,
    val keepEpg: Boolean = true,
    val autoRefresh: Boolean = false,
    val onboardingDone: Boolean = false,
    val enablePictureInPicture: Boolean = true,
    val adsEnabled: Boolean = true,
    val adsFreeUntil: Long? = null,
    val m3uIdsV2: Boolean = false,
)

@Serializable
data class PersistedState(
    val playlists: List<Playlist> = emptyList(),
    val activePlaylistId: String? = null,
    val favorites: List<Favorite> = emptyList(),
    val history: List<WatchHistory> = emptyList(),
    val settings: Settings = Settings(),
    val recentSearches: List<String> = emptyList(),
)


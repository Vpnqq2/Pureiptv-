package com.black.pureiptv.data.parser

/**
 * معرّفات ثابتة للقنوات (M3U).
 * القديم: "playlistId:رقم السطر" -> يتغيّر عند تغيّر ترتيب القنوات فتتلخبط المفضلة.
 * الجديد: hash من (tvg-id + الاسم + التصنيف) فلا يتأثر بالترتيب ولا بتغيّر توكن الرابط.
 */
object ChannelIds {
    fun key(tvgId: String?, name: String, group: String): String {
        val raw = "${tvgId.orEmpty().trim().lowercase()}|${name.trim().lowercase()}|${group.trim().lowercase()}"
        return fnv1a64Hex(raw)
    }

    private fun fnv1a64Hex(s: String): String {
        var h = -0x340d631b7bdddcdbL // 0xcbf29ce484222325
        for (b in s.toByteArray(Charsets.UTF_8)) {
            h = h xor (b.toLong() and 0xff)
            h *= 0x100000001b3L
        }
        return java.lang.Long.toHexString(h).padStart(16, '0')
    }

    /** يمنح معرّفاً فريداً؛ القنوات المتطابقة (نفس الاسم/التصنيف) تأخذ لاحقة _2 و _3 حسب ترتيب ظهورها */
    class Allocator(private val playlistId: String) {
        private val seen = HashMap<String, Int>()
        fun next(tvgId: String?, name: String, group: String): String {
            val k = key(tvgId, name, group)
            val n = (seen[k] ?: 0) + 1
            seen[k] = n
            return if (n == 1) "$playlistId:c_$k" else "$playlistId:c_${k}_$n"
        }
    }
}

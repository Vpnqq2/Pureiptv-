package com.black.pureiptv.data.parser

import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.data.model.ContentKind
import com.black.pureiptv.data.model.ParseResult
import com.black.pureiptv.data.model.ParseStats
import com.black.pureiptv.data.model.SeriesShow

object M3uParser {
    private val ATTR_RE = Regex("""([A-Za-z0-9_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))""")

    fun looksLikeM3u(content: String): Boolean {
        val head = content.take(4000)
        return head.contains("#EXTM3U", true) || head.contains("#EXTINF:", true)
    }

    fun parse(content: String, playlistId: String): ParseResult {
        val started = System.currentTimeMillis()
        val text = content.removePrefix("\uFEFF")

        val channels = mutableListOf<Channel>()
        val movies = mutableListOf<Channel>()
        val seriesMap = linkedMapOf<String, SeriesShow>()
        val groups = mutableSetOf<String>()
        var epgUrl: String? = null
        var pending: Pending? = null
        var headerSeen = false
        var number = 0
        val ids = ChannelIds.Allocator(playlistId)

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTM3U") -> {
                    headerSeen = true
                    val attrs = parseAttrs(line.drop(7))
                    epgUrl = attrs["url-tvg"] ?: attrs["x-tvg-url"] ?: attrs["tvg-url"] ?: epgUrl
                }
                line.startsWith("#EXTGRP:") -> {
                    pending = pending?.copy(group = line.removePrefix("#EXTGRP:").trim())
                }
                line.startsWith("#EXTINF:") -> pending = splitExtInf(line)
                line.startsWith("#") -> Unit
                else -> {
                    if (isUrlLine(line) || pending != null) {
                        val info = pending ?: Pending(-1.0, emptyMap(), "")
                        pending = null
                        number += 1
                        val group = (info.group ?: info.attrs["group-title"] ?: info.attrs["group"] ?: "Uncategorized")
                            .trim().ifBlank { "Uncategorized" }
                        val name = (info.name.ifBlank { info.attrs["tvg-name"] } ?: "Channel $number").trim()
                            .ifBlank { "Channel $number" }
                        val kind = classify(group, line, info.duration, name)
                        val logo = info.attrs["tvg-logo"] ?: info.attrs["logo"]
                        val channel = Channel(
                            id = ids.next(info.attrs["tvg-id"], name, group),
                            playlistId = playlistId,
                            name = name,
                            url = line,
                            logo = logo,
                            poster = logo,
                            group = group,
                            tvgId = info.attrs["tvg-id"],
                            tvgName = info.attrs["tvg-name"] ?: name,
                            kind = kind,
                            number = number,
                            duration = info.duration.takeIf { it > 0 }?.toInt(),
                        )
                        groups.add(group)
                        when (kind) {
                            ContentKind.MOVIE -> movies += channel
                            ContentKind.SERIES -> {
                                val seriesName = Regex("""\s*s\d{1,2}\s*e\d{1,2}.*$""", RegexOption.IGNORE_CASE)
                                    .replace(name, "").trim().ifBlank { group }
                                val sid = "$playlistId:series:${seriesName.lowercase()}"
                                if (sid !in seriesMap) {
                                    seriesMap[sid] = SeriesShow(
                                        id = sid,
                                        playlistId = playlistId,
                                        seriesId = sid,
                                        name = seriesName,
                                        poster = logo,
                                        categoryName = group,
                                    )
                                }
                                val se = Regex("""s(\d{1,2})\s*e(\d{1,2})""", RegexOption.IGNORE_CASE).find(name)
                                channels += channel.copy(
                                    seriesId = sid,
                                    season = se?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 1,
                                    episode = se?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 1,
                                )
                            }
                            else -> channels += channel
                        }
                    }
                }
            }
        }

        if (!headerSeen && channels.isEmpty() && movies.isEmpty()) {
            throw IptvException("INVALID_M3U")
        }

        val durationMs = System.currentTimeMillis() - started
        return ParseResult(
            channels = channels,
            movies = movies,
            series = seriesMap.values.toList(),
            epgUrl = epgUrl,
            stats = ParseStats(
                channels = channels.count { it.kind == ContentKind.LIVE },
                groups = groups.size,
                movies = movies.size,
                series = seriesMap.size,
                durationMs = durationMs,
            ),
        )
    }

    private data class Pending(
        val duration: Double,
        val attrs: Map<String, String>,
        val name: String,
        val group: String? = null,
    )

    private fun parseAttrs(raw: String): Map<String, String> {
        val out = mutableMapOf<String, String>()
        ATTR_RE.findAll(raw).forEach { m ->
            out[m.groupValues[1].lowercase()] = m.groupValues[2].ifBlank { m.groupValues[3].ifBlank { m.groupValues[4] } }
        }
        return out
    }

    private fun splitExtInf(line: String): Pending {
        val body = line.replace(Regex("^#EXTINF:", RegexOption.IGNORE_CASE), "")
        val durationMatch = Regex("""^(-?\d+(?:\.\d+)?)(.*)$""").find(body) ?: return Pending(-1.0, emptyMap(), body.trim())
        val duration = durationMatch.groupValues[1].toDoubleOrNull() ?: -1.0
        val rest = durationMatch.groupValues[2]
        var inQuotes = false
        var quote = ' '
        var commaAt = -1
        for (i in rest.indices) {
            val ch = rest[i]
            if ((ch == '"' || ch == '\'') && (i == 0 || rest[i - 1] != '\\')) {
                if (!inQuotes) {
                    inQuotes = true
                    quote = ch
                } else if (ch == quote) inQuotes = false
            } else if (ch == ',' && !inQuotes) commaAt = i
        }
        val attrPart: String
        val name: String
        if (commaAt >= 0) {
            attrPart = rest.substring(0, commaAt)
            name = rest.substring(commaAt + 1).trim()
        } else {
            attrPart = rest
            name = ""
        }
        return Pending(if (duration.isFinite()) duration else -1.0, parseAttrs(attrPart), name)
    }

    private fun classify(group: String, url: String, duration: Double, name: String): ContentKind {
        val g = group.lowercase()
        val u = url.lowercase()
        val n = name.lowercase()
        if (Regex("""/series/""").containsMatchIn(u) ||
            Regex("""\b(series|shows?|tv shows?|مسلسل)\b""").containsMatchIn(g) ||
            Regex("""\bs\d{1,2}\s*e\d{1,2}\b""").containsMatchIn(n)
        ) return ContentKind.SERIES
        if (Regex("""/movie/""").containsMatchIn(u) ||
            Regex("""\b(movies?|vod|cinema|films?|أفلام)\b""").containsMatchIn(g) ||
            (duration > 300 && !Regex("""\b(live|news|sport|kids|music)\b""").containsMatchIn(g))
        ) return ContentKind.MOVIE
        return ContentKind.LIVE
    }

    private fun isUrlLine(line: String): Boolean {
        val t = line.trim()
        if (t.isEmpty() || t.startsWith("#")) return false
        return t.startsWith("http://", true) || t.startsWith("https://", true) ||
            t.startsWith("rtmp://", true) || t.startsWith("rtsp://", true) || t.startsWith("udp://", true)
    }
}

class IptvException(val code: String) : Exception(code)


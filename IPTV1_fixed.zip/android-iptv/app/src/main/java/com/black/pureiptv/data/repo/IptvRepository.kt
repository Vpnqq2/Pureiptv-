package com.black.pureiptv.data.repo

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.black.pureiptv.data.epg.Xmltv
import com.black.pureiptv.data.local.AppDb
import com.black.pureiptv.data.local.ChannelEntity
import com.black.pureiptv.data.local.EpgEntity
import com.black.pureiptv.data.local.SeriesEntity
import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.data.model.ContentKind
import com.black.pureiptv.data.model.EpgProgram
import com.black.pureiptv.data.model.Favorite
import com.black.pureiptv.data.model.ParseStats
import com.black.pureiptv.data.model.PersistedState
import com.black.pureiptv.data.model.Playlist
import com.black.pureiptv.data.model.PlaylistSource
import com.black.pureiptv.data.model.PlaylistStatus
import com.black.pureiptv.data.model.PlaylistType
import com.black.pureiptv.data.model.SeriesShow
import com.black.pureiptv.data.model.Settings
import com.black.pureiptv.data.model.WatchHistory
import com.black.pureiptv.data.model.XtreamUserInfo
import com.black.pureiptv.data.net.Http
import com.black.pureiptv.data.parser.IptvException
import com.black.pureiptv.data.parser.M3uParser
import com.black.pureiptv.data.xtream.Xtream
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.json.JsonElement
import com.black.pureiptv.data.parser.ChannelIds
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.random.Random

private val Context.dataStore by preferencesDataStore("iptv-app-v1")
private val STATE_KEY = stringPreferencesKey("state")

class IptvRepository(private val context: Context) {
    private val db = AppDb.get(context)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val state: Flow<PersistedState> = context.dataStore.data.map { prefs ->
        val raw = prefs[STATE_KEY]
        if (raw.isNullOrBlank()) PersistedState()
        else runCatching { json.decodeFromString<PersistedState>(raw) }.getOrDefault(PersistedState())
    }

    suspend fun saveState(state: PersistedState) {
        context.dataStore.edit { it[STATE_KEY] = json.encodeToString(state) }
    }

    suspend fun importM3uText(
        content: String,
        name: String,
        source: PlaylistSource,
        m3uUrl: String? = null,
        fileName: String? = null,
        existingId: String? = null,
    ): Pair<Playlist, ParseStats> {
        if (!M3uParser.looksLikeM3u(content)) throw IptvException("INVALID_M3U")
        val id = existingId ?: uid("pl")
        val parsed = M3uParser.parse(content, id)
        val live = parsed.channels.filter { it.kind == ContentKind.LIVE }
        val seriesEps = parsed.channels.filter { it.kind == ContentKind.SERIES }
        saveChannels(id, parsed.channels + parsed.movies)
        saveSeries(id, parsed.series)
        val groups = (live + parsed.movies + seriesEps).map { it.group }.toSet()
        val playlist = Playlist(
            id = id,
            name = name.trim().ifBlank { "My M3U Playlist" },
            type = PlaylistType.M3U,
            source = source,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            channelCount = live.size,
            groupCount = groups.size,
            movieCount = parsed.movies.size,
            seriesCount = parsed.series.size,
            status = if (live.isNotEmpty() || parsed.movies.isNotEmpty()) PlaylistStatus.CONNECTED else PlaylistStatus.ERROR,
            lastError = if (live.isEmpty() && parsed.movies.isEmpty()) "NO_CHANNELS" else null,
            epgUrl = parsed.epgUrl,
            m3uUrl = m3uUrl,
            fileName = fileName,
        )
        return playlist to parsed.stats
    }

    suspend fun importM3uUrl(url: String, name: String, existingId: String? = null): Pair<Playlist, ParseStats> {
        val text = runCatching { Http.getText(url) }.getOrElse { e ->
            throw if (e is IptvException) e else IptvException("NETWORK")
        }
        return importM3uText(text, name, PlaylistSource.URL, m3uUrl = url, existingId = existingId)
    }

    suspend fun connectXtream(
        name: String, serverUrl: String, username: String, password: String, existingId: String? = null,
    ): Pair<Playlist, XtreamUserInfo> {
        val base = Xtream.normalizeBase(serverUrl)
        val user = username.trim()
        val authJson = runCatching { Http.getJson(Xtream.playerApi(base, user, password)) }
            .getOrElse { e -> throw if (e is IptvException) e else IptvException("NETWORK") }
        val info = Xtream.parseAuth(authJson)
        val id = existingId ?: uid("pl")
        // طلبات متوازية (2 كحد أقصى) وكل JSON يُحوَّل لقنوات فوراً ثم يُترك للـ GC بدل إبقاء 6 ملفات ضخمة بالذاكرة
        val gate = Semaphore(2)
        suspend fun fetch(extra: Map<String, String>): JsonElement? = gate.withPermit {
            runCatching { Http.getJson(Xtream.playerApi(base, user, password, extra)) }.getOrNull()
        }
        val (liveChannels, movies, shows) = coroutineScope {
            val liveD = async(Dispatchers.IO) {
                val cats = fetch(mapOf("action" to "get_live_categories"))
                val streams = fetch(mapOf("action" to "get_live_streams"))
                Xtream.mapLive(id, base, user, password, streams, cats)
            }
            val vodD = async(Dispatchers.IO) {
                val cats = fetch(mapOf("action" to "get_vod_categories"))
                val streams = fetch(mapOf("action" to "get_vod_streams"))
                Xtream.mapVod(id, base, user, password, streams, cats)
            }
            val seriesD = async(Dispatchers.IO) {
                val cats = fetch(mapOf("action" to "get_series_categories"))
                val list = fetch(mapOf("action" to "get_series"))
                Xtream.mapSeries(id, list, cats)
            }
            Triple(liveD.await(), vodD.await(), seriesD.await())
        }
        saveChannels(id, liveChannels + movies)
        saveSeries(id, shows)
        val playlist = Playlist(
            id = id,
            name = name.trim().ifBlank { "Xtream Codes" },
            type = PlaylistType.XTREAM,
            source = PlaylistSource.XTREAM,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            channelCount = liveChannels.size,
            groupCount = liveChannels.map { it.group }.toSet().size,
            movieCount = movies.size,
            seriesCount = shows.size,
            status = if (liveChannels.isNotEmpty() || movies.isNotEmpty() || shows.isNotEmpty()) PlaylistStatus.CONNECTED else PlaylistStatus.ERROR,
            lastError = if (liveChannels.isEmpty() && movies.isEmpty() && shows.isEmpty()) "NO_CHANNELS" else null,
            epgUrl = Xtream.xmltvUrl(base, user, password),
            serverUrl = base,
            username = user,
            passwordEnc = SecretBox.encrypt(password),
            xtreamInfo = info,
        )
        return playlist to info
    }

    suspend fun refresh(playlist: Playlist): Playlist {
        if (playlist.type == PlaylistType.M3U && !playlist.m3uUrl.isNullOrBlank()) {
            val (next, _) = importM3uUrl(playlist.m3uUrl, playlist.name, playlist.id)
            return next.copy(createdAt = playlist.createdAt)
        }
        if (playlist.type == PlaylistType.XTREAM && playlist.serverUrl != null && playlist.username != null && playlist.passwordEnc != null) {
            val password = SecretBox.decrypt(playlist.passwordEnc)
            val (next, _) = connectXtream(playlist.name, playlist.serverUrl, playlist.username, password, playlist.id)
            return next.copy(createdAt = playlist.createdAt)
        }
        return playlist
    }

    suspend fun saveChannels(playlistId: String, channels: List<Channel>) {
        db.channels().deletePlaylist(playlistId)
        if (channels.isNotEmpty()) db.channels().upsertAll(channels.map { ChannelEntity.from(it) })
    }

    suspend fun saveSeries(playlistId: String, series: List<SeriesShow>) {
        db.series().deletePlaylist(playlistId)
        if (series.isNotEmpty()) db.series().upsertAll(series.map { SeriesEntity.from(it) })
    }

    suspend fun loadChannels(playlistId: String): List<Channel> = db.channels().forPlaylist(playlistId).map { it.toModel() }
    /** تحميل نوع واحد فقط من القاعدة (بدل تحميل كل الأفلام والمسلسلات ثم الفلترة بالذاكرة) */
    suspend fun loadChannels(playlistId: String, kind: ContentKind): List<Channel> =
        db.channels().forPlaylistKind(playlistId, kind.name).map { it.toModel() }

    suspend fun countChannels(playlistId: String, kind: ContentKind): Int =
        db.channels().countKind(playlistId, kind.name)

    /**
     * ترحيل لمرة واحدة: يحوّل المعرّفات القديمة "playlistId:رقم" إلى معرّفات ثابتة.
     * يرجّع خريطة (قديم -> جديد) لتحديث المفضلة والسجل.
     */
    suspend fun migrateM3uIds(playlistIds: List<String>): Map<String, String> {
        val remap = HashMap<String, String>()
        for (pid in playlistIds) {
            val rows = db.channels().forPlaylist(pid)
            val oldId = Regex("^" + Regex.escape(pid) + ":\\d+$")
            if (rows.none { oldId.matches(it.id) }) continue
            val alloc = ChannelIds.Allocator(pid)
            val updated = rows.sortedBy { it.number }.map { r ->
                val newId = alloc.next(r.tvgId, r.name, r.groupName)
                if (oldId.matches(r.id)) remap[r.id] = newId
                r.copy(id = newId)
            }
            db.withTransaction {
                db.channels().deletePlaylist(pid)
                db.channels().upsertAll(updated)
            }
        }
        return remap
    }
    suspend fun getChannel(id: String): Channel? = db.channels().get(id)?.toModel()
    suspend fun loadSeries(playlistId: String): List<SeriesShow> = db.series().forPlaylist(playlistId).map { it.toModel() }
    suspend fun getSeries(id: String): SeriesShow? = db.series().get(id)?.toModel()
    suspend fun deletePlaylistMedia(playlistId: String) {
        db.channels().deletePlaylist(playlistId)
        db.series().deletePlaylist(playlistId)
    }
    suspend fun search(q: String, playlistId: String?, limit: Int = 80): List<Channel> {
        if (q.isBlank()) return emptyList()
        return db.channels().search(q, playlistId, limit).map { it.toModel() }
    }
    suspend fun saveEpg(programs: List<EpgProgram>) {
        if (programs.isNotEmpty()) db.epg().upsertAll(programs.map { EpgEntity.from(it) })
    }
    suspend fun loadEpg(tvgId: String): List<EpgProgram> = db.epg().forChannel(tvgId).map { it.toModel() }
    suspend fun fetchEpg(url: String): List<EpgProgram> {
        val text = Http.getText(url)
        val parsed = Xmltv.parse(text)
        saveEpg(parsed)
        return parsed
    }
    suspend fun loadSeriesEpisodes(playlist: Playlist, show: SeriesShow): List<Channel> {
        var eps = loadChannels(show.playlistId, ContentKind.SERIES).filter { it.seriesId == show.seriesId || it.seriesId == show.id }
        if (eps.isEmpty() && playlist.type == PlaylistType.XTREAM && playlist.serverUrl != null &&
            playlist.username != null && playlist.passwordEnc != null
        ) {
            val password = SecretBox.decrypt(playlist.passwordEnc)
            val url = Xtream.playerApi(
                playlist.serverUrl, playlist.username, password,
                mapOf("action" to "get_series_info", "series_id" to show.seriesId),
            )
            val jsonEl = runCatching { Http.getJson(url) }.getOrNull()
            if (jsonEl != null) {
                eps = Xtream.mapEpisodes(playlist.id, show.seriesId, show.name, playlist.serverUrl, playlist.username, password, jsonEl)
                if (eps.isNotEmpty()) {
                    val existing = loadChannels(playlist.id)
                    saveChannels(playlist.id, existing + eps)
                }
            }
        }
        return eps
    }

    companion object {
        fun uid(prefix: String = "id"): String {
            val rand = Random.nextInt(0x1fffff).toString(36)
            val t = System.currentTimeMillis().toString(36)
            return "${prefix}_${rand}$t"
        }
    }
}

object SecretBox {
    private const val ALIAS = "iptv.aes.key.v1"
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        if (plain.isEmpty()) return ""
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val iv = c.iv
        val cipher = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        val packed = ByteArray(iv.size + cipher.size)
        System.arraycopy(iv, 0, packed, 0, iv.size)
        System.arraycopy(cipher, 0, packed, iv.size, cipher.size)
        return Base64.encodeToString(packed, Base64.NO_WRAP)
    }

    fun decrypt(payload: String): String {
        if (payload.isEmpty()) return ""
        return runCatching {
            val packed = Base64.decode(payload, Base64.NO_WRAP)
            val iv = packed.copyOfRange(0, 12)
            val data = packed.copyOfRange(12, packed.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(c.doFinal(data), Charsets.UTF_8)
        }.getOrDefault("")
    }
}

fun errorMessage(code: String, lang: com.black.pureiptv.data.model.LangId): String {
    val ar = lang == com.black.pureiptv.data.model.LangId.AR
    val table = if (ar) AR_ERR else EN_ERR
    table[code]?.let { return it }
    if (code.startsWith("HTTP_")) return table["HTTP_500"]!!
    return if (ar) "حدث خطأ غير متوقع" else "Something went wrong"
}

private val EN_ERR = mapOf(
    "INVALID_URL" to "Invalid playlist URL",
    "INVALID_M3U" to "This file does not look like a valid M3U playlist",
    "INVALID_XTREAM" to "Unable to read Xtream server response",
    "INVALID_CREDENTIALS" to "Invalid Xtream credentials",
    "BLOCKED_HOST" to "This address cannot be used",
    "TOO_LARGE" to "Playlist is too large to load",
    "TIMEOUT" to "The server took too long to respond",
    "NETWORK" to "No internet connection",
    "HTTP_401" to "Invalid Xtream credentials",
    "HTTP_403" to "Access denied by the server",
    "HTTP_404" to "Playlist or server was not found",
    "HTTP_500" to "Server unavailable",
    "INVALID_JSON" to "Server returned an unexpected response",
    "NO_CHANNELS" to "No channels found",
    "STREAM_UNAVAILABLE" to "Unable to play this stream",
    "LOAD_FAILED" to "Unable to load playlist",
)
private val AR_ERR = mapOf(
    "INVALID_URL" to "رابط القائمة غير صالح",
    "INVALID_M3U" to "هذا الملف لا يبدو قائمة M3U صالحة",
    "INVALID_XTREAM" to "تعذر قراءة استجابة خادم Xtream",
    "INVALID_CREDENTIALS" to "بيانات Xtream غير صحيحة",
    "BLOCKED_HOST" to "لا يمكن استخدام هذا العنوان",
    "TOO_LARGE" to "القائمة كبيرة جداً للتحميل",
    "TIMEOUT" to "استغرق الخادم وقتاً طويلاً",
    "NETWORK" to "لا يوجد اتصال بالإنترنت",
    "HTTP_401" to "بيانات Xtream غير صحيحة",
    "HTTP_403" to "الخادم رفض الوصول",
    "HTTP_404" to "القائمة أو الخادم غير موجود",
    "HTTP_500" to "الخادم غير متاح",
    "INVALID_JSON" to "استجابة غير متوقعة من الخادم",
    "NO_CHANNELS" to "لا توجد قنوات",
    "STREAM_UNAVAILABLE" to "تعذر تشغيل هذا البث",
    "LOAD_FAILED" to "تعذر تحميل القائمة",
)


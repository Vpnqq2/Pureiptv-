package com.black.pureiptv.data.xtream

import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.data.model.ContentKind
import com.black.pureiptv.data.model.SeriesShow
import com.black.pureiptv.data.model.XtreamUserInfo
import com.black.pureiptv.data.parser.IptvException
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URLEncoder
import java.util.Date
import java.util.Locale

object Xtream {
    fun normalizeBase(input: String): String {
        var url = input.trim()
        if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) url = "http://$url"
        url = url.trimEnd('/')
        url = url.replace(Regex("/player_api\\.php$", RegexOption.IGNORE_CASE), "")
        url = url.replace(Regex("/get\\.php.*$", RegexOption.IGNORE_CASE), "")
        url = url.replace(Regex("/portal\\.php.*$", RegexOption.IGNORE_CASE), "")
        return url
    }

    fun playerApi(base: String, user: String, pass: String, extra: Map<String, String> = emptyMap()): String {
        val b = StringBuilder("${normalizeBase(base)}/player_api.php")
        b.append("?username=").append(enc(user)).append("&password=").append(enc(pass))
        extra.forEach { (k, v) -> if (v.isNotBlank()) b.append("&").append(enc(k)).append("=").append(enc(v)) }
        return b.toString()
    }

    fun liveUrl(base: String, user: String, pass: String, streamId: String, ext: String = "m3u8") =
        "${normalizeBase(base)}/live/${enc(user)}/${enc(pass)}/$streamId.$ext"

    fun vodUrl(base: String, user: String, pass: String, streamId: String, ext: String = "mp4") =
        "${normalizeBase(base)}/movie/${enc(user)}/${enc(pass)}/$streamId.$ext"

    fun seriesUrl(base: String, user: String, pass: String, episodeId: String, ext: String = "mp4") =
        "${normalizeBase(base)}/series/${enc(user)}/${enc(pass)}/$episodeId.$ext"

    fun xmltvUrl(base: String, user: String, pass: String) =
        "${normalizeBase(base)}/xmltv.php?username=${enc(user)}&password=${enc(pass)}"

    fun parseAuth(json: JsonElement): XtreamUserInfo {
        val root = json as? JsonObject ?: throw IptvException("INVALID_XTREAM")
        val user = (root["user_info"] as? JsonObject) ?: root
        val server = (root["server_info"] as? JsonObject) ?: JsonObject(emptyMap())
        val auth = str(user["auth"])
        if (auth == "0" || str(user["status"]) == "Disabled") throw IptvException("INVALID_CREDENTIALS")
        if (str(user["username"]).isNullOrBlank() && auth != "1") throw IptvException("INVALID_XTREAM")
        return XtreamUserInfo(
            username = str(user["username"]).orEmpty(),
            status = str(user["status"]),
            expDate = str(user["exp_date"]),
            activeCons = str(user["active_cons"]),
            maxCons = str(user["max_connections"]),
            createdAt = str(user["created_at"]),
            isTrial = str(user["is_trial"]),
            timezone = str(user["timezone"]) ?: str(server["timezone"]),
            message = str(user["message"]),
            serverProtocol = str(server["server_protocol"]),
            serverPort = str(server["port"]),
        )
    }

    fun mapLive(
        playlistId: String, base: String, user: String, pass: String,
        streams: JsonElement?, categories: JsonElement?,
    ): List<Channel> {
        val names = categoryMap(categories)
        val list = (streams as? JsonArray) ?: return emptyList()
        return list.mapIndexed { i, item ->
            val r = item as? JsonObject ?: JsonObject(emptyMap())
            val id = str(r["stream_id"]) ?: "${i + 1}"
            val catId = str(r["category_id"]).orEmpty()
            Channel(
                id = "$playlistId:live:$id",
                playlistId = playlistId,
                name = str(r["name"]) ?: "Channel $id",
                url = liveUrl(base, user, pass, id),
                logo = str(r["stream_icon"]),
                group = names[catId] ?: "Live",
                tvgId = str(r["epg_channel_id"]),
                tvgName = str(r["name"]),
                kind = ContentKind.LIVE,
                number = num(r["num"]) ?: (i + 1),
                streamId = id,
                categoryId = catId,
                plot = str(r["plot"]),
            )
        }
    }

    fun mapVod(
        playlistId: String, base: String, user: String, pass: String,
        streams: JsonElement?, categories: JsonElement?,
    ): List<Channel> {
        val names = categoryMap(categories)
        val list = (streams as? JsonArray) ?: return emptyList()
        return list.mapIndexed { i, item ->
            val r = item as? JsonObject ?: JsonObject(emptyMap())
            val id = str(r["stream_id"]) ?: "${i + 1}"
            val ext = str(r["container_extension"]) ?: "mp4"
            val catId = str(r["category_id"]).orEmpty()
            Channel(
                id = "$playlistId:vod:$id",
                playlistId = playlistId,
                name = str(r["name"]) ?: "Movie $id",
                url = vodUrl(base, user, pass, id, ext),
                logo = str(r["stream_icon"]),
                poster = str(r["stream_icon"]),
                group = names[catId] ?: "Movies",
                kind = ContentKind.MOVIE,
                number = num(r["num"]) ?: (i + 1),
                streamId = id,
                container = ext,
                categoryId = catId,
                year = str(r["year"]) ?: str(r["releaseDate"])?.take(4),
                rating = str(r["rating"]),
                plot = str(r["plot"]),
                genre = str(r["genre"]),
                duration = num(r["duration_secs"]),
            )
        }
    }

    fun mapSeries(playlistId: String, series: JsonElement?, categories: JsonElement?): List<SeriesShow> {
        val names = categoryMap(categories)
        val list = (series as? JsonArray) ?: return emptyList()
        return list.mapIndexed { i, item ->
            val r = item as? JsonObject ?: JsonObject(emptyMap())
            val id = str(r["series_id"]) ?: "${i + 1}"
            val catId = str(r["category_id"]).orEmpty()
            SeriesShow(
                id = "$playlistId:series:$id",
                playlistId = playlistId,
                seriesId = id,
                name = str(r["name"]) ?: "Series $id",
                plot = str(r["plot"]),
                poster = str(r["cover"]),
                backdrop = (r["backdrop_path"] as? JsonArray)?.firstOrNull()?.let { str(it) }
                    ?: str(r["backdrop_path"]),
                genre = str(r["genre"]),
                year = str(r["year"]) ?: str(r["releaseDate"])?.take(4),
                rating = str(r["rating"]),
                categoryId = catId,
                categoryName = names[catId] ?: "Series",
            )
        }
    }

    fun mapEpisodes(
        playlistId: String, seriesId: String, seriesName: String,
        base: String, user: String, pass: String, info: JsonElement?,
    ): List<Channel> {
        val root = info as? JsonObject ?: return emptyList()
        val episodes = root["episodes"] as? JsonObject ?: return emptyList()
        val out = mutableListOf<Channel>()
        episodes.forEach { (seasonKey, listEl) ->
            val list = listEl as? JsonArray ?: return@forEach
            val season = seasonKey.toIntOrNull() ?: 1
            list.forEachIndexed { i, item ->
                val r = item as? JsonObject ?: return@forEachIndexed
                val id = str(r["id"]) ?: "$season-$i"
                val ext = str(r["container_extension"]) ?: "mp4"
                val ep = num(r["episode_num"]) ?: (i + 1)
                val infoRec = r["info"] as? JsonObject
                out += Channel(
                    id = "$playlistId:ep:$id",
                    playlistId = playlistId,
                    name = str(r["title"]) ?: "$seriesName S${season}E$ep",
                    url = seriesUrl(base, user, pass, id, ext),
                    group = seriesName,
                    kind = ContentKind.SERIES,
                    number = ep,
                    streamId = id,
                    container = ext,
                    seriesId = seriesId,
                    season = season,
                    episode = ep,
                    duration = num(infoRec?.get("duration")) ?: num(r["duration"]),
                    plot = str(infoRec?.get("plot")),
                )
            }
        }
        return out
    }

    fun unixToIso(unix: String?): String? {
        if (unix.isNullOrBlank()) return null
        val n = unix.toLongOrNull() ?: return unix
        if (n <= 0) return unix
        return java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(n * 1000))
    }

    private fun categoryMap(categories: JsonElement?): Map<String, String> {
        val list = categories as? JsonArray ?: return emptyMap()
        return buildMap {
            list.forEach { item ->
                val r = item as? JsonObject ?: return@forEach
                val id = str(r["category_id"])
                val name = str(r["category_name"])
                if (id != null && name != null) put(id, name)
            }
        }
    }

    private fun str(v: JsonElement?): String? {
        val p = (v as? JsonPrimitive)?.contentOrNull?.trim()
        return p?.takeIf { it.isNotEmpty() }
    }

    private fun num(v: JsonElement?): Int? {
        val s = str(v) ?: (v as? JsonPrimitive)?.contentOrNull ?: return null
        return s.toDoubleOrNull()?.toInt()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}


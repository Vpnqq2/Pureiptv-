package com.black.pureiptv.firebase

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.black.pureiptv.MainActivity

class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "FCMService"
        const val CHANNEL_ID = "firebase_notifications"
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "From: ${remoteMessage.from}")

        remoteMessage.notification?.let { notification ->
            Log.d(TAG, "Notification Title: ${notification.title}")
            Log.d(TAG, "Notification Body: ${notification.body}")
            sendNotification(notification.title ?: "إشعار", notification.body ?: "")
        }

        remoteMessage.data.isNotEmpty().let { data ->
            Log.d(TAG, "Message data payload: $data")
            // Handle data messages if needed
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "Refreshed token: $token")
        // Send token to your server or save it locally
        // This token can be used to target specific devices
    }

    private fun sendNotification(title: String, messageBody: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationManager = getSystemService(NotificationManager::class.java)

        // Create notification channel for Android O and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Firebase Notifications",
                NotificationManager.IMPORTANCE_HIGH // Use HIGH importance for Android 14+
            ).apply {
                description = "Firebase push notifications"
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Create notification with proper styling for Android 14+
        val notificationBuilder = androidx.core.app.NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(messageBody)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH) // Set priority for Android 13 and below
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setOngoing(false)
            .setDefaults(android.app.Notification.DEFAULT_ALL) // Use default sound, vibration, and lights
            .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(messageBody)) // Enable expanded text

        notificationManager.notify(System.currentTimeMillis().toInt(), notificationBuilder.build())
    }
}

package com.black.pureiptv.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.util.Rational
import androidx.annotation.RequiresApi
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import com.black.pureiptv.R

class PictureInPictureManager(private val context: Context) {
    
    fun isPipSupported(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        } else {
            false
        }
    }

    fun enterPictureInPictureMode(activity: Activity, mediaController: MediaController?): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterPipModeApi26Plus(activity, mediaController)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            enterPipModeApi24(activity)
        } else {
            false
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun enterPipModeApi26Plus(activity: Activity, mediaController: MediaController?): Boolean {
        if (!isPipSupported()) return false
        
        return try {
            val actions = createPipActions(mediaController)
            val aspectRatio = Rational(16, 9)
            
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(aspectRatio)
                .setActions(actions)
                .build()

            activity.enterPictureInPictureMode(params)
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun enterPipModeApi24(activity: Activity): Boolean {
        if (!isPipSupported()) return false
        
        return try {
            @Suppress("DEPRECATION")
            activity.enterPictureInPictureMode()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun updatePipActions(activity: Activity, mediaController: MediaController?) {
        if (!isPipSupported() || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        
        try {
            val actions = createPipActions(mediaController)
            val params = PictureInPictureParams.Builder()
                .setActions(actions)
                .build()
            
            activity.setPictureInPictureParams(params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createPipActions(mediaController: MediaController?): List<RemoteAction> {
        val actions = mutableListOf<RemoteAction>()
        
        mediaController?.let { controller ->
            // Play/Pause action based on current state
            if (controller.isPlaying) {
                val pauseAction = RemoteAction(
                    Icon.createWithResource(context, android.R.drawable.ic_media_pause),
                    "Pause",
                    "Pause playback",
                    android.app.PendingIntent.getBroadcast(
                        context,
                        0,
                        android.content.Intent("com.black.pureiptv.PIP_PAUSE"),
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                    )
                )
                actions.add(pauseAction)
            } else {
                val playAction = RemoteAction(
                    Icon.createWithResource(context, android.R.drawable.ic_media_play),
                    "Play",
                    "Resume playback",
                    android.app.PendingIntent.getBroadcast(
                        context,
                        1,
                        android.content.Intent("com.black.pureiptv.PIP_PLAY"),
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                    )
                )
                actions.add(playAction)
            }
            
            // Close PiP action
            val closeAction = RemoteAction(
                Icon.createWithResource(context, android.R.drawable.ic_menu_close_clear_cancel),
                "Close",
                "Close Picture-in-Picture",
                android.app.PendingIntent.getBroadcast(
                    context,
                    2,
                    android.content.Intent("com.black.pureiptv.PIP_CLOSE"),
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
            )
            actions.add(closeAction)
        }
        
        return actions
    }

    fun shouldEnterPipOnUserLeave(
        mediaController: MediaController?,
        enablePip: Boolean
    ): Boolean {
        if (!enablePip || !isPipSupported()) return false
        
        return mediaController?.let { controller ->
            controller.isPlaying && 
            controller.playbackState == Player.STATE_READY &&
            controller.currentMediaItem != null
        } ?: false
    }
    
    fun isInPictureInPictureMode(activity: Activity): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            activity.isInPictureInPictureMode
        } else {
            false
        }
    }
}

package com.black.pureiptv.player

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.data.model.ContentKind
import com.black.pureiptv.data.model.WatchHistory
import com.black.pureiptv.ui.components.EmptyState
import com.black.pureiptv.ui.components.InPlayerChannelList
import com.black.pureiptv.ui.components.PrimaryButton
import com.black.pureiptv.ui.components.Screen
import com.black.pureiptv.ui.components.SecondaryButton
import com.black.pureiptv.ui.components.SpinnerBox
import com.black.pureiptv.ui.i18n.I18nKey
import com.black.pureiptv.ui.theme.LocalIptvColors
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun PlayerRoute(vm: AppViewModel, id: String, onBack: () -> Unit) {
    var channel by remember { mutableStateOf<Channel?>(null) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(id) {
        channel = vm.repository.getChannel(id)
        loading = false
    }
    when {
        loading -> Screen { SpinnerBox() }
        channel == null -> Screen {
            EmptyState(vm.t(I18nKey.unablePlay))
            PrimaryButton(vm.t(I18nKey.back), onBack)
        }
        else -> PlayerScreen(vm, channel!!, onBack)
    }
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(vm: AppViewModel, channel: Channel, onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() as? com.black.pureiptv.MainActivity }
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    val favorite = state.favorites.any { it.id == channel.id }
    val isInPipMode = remember(configuration) { 
        activity?.isInPipMode() == true
    }

    var controller by remember { mutableStateOf<MediaController?>(null) }
    var error by remember { mutableStateOf(false) }
    var reconnecting by remember { mutableStateOf(false) }
    val retryScope = rememberCoroutineScope()
    var retryJob by remember { mutableStateOf<Job?>(null) }
    var retryCount by remember { mutableIntStateOf(0) }
    var buffering by remember { mutableStateOf(true) }
    var playing by remember { mutableStateOf(true) }
    var muted by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(true) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var live by remember { mutableStateOf(channel.kind == ContentKind.LIVE) }
    var isFullscreen by remember { mutableStateOf(false) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var resizeModeNotice by remember { mutableStateOf<String?>(null) }
    var rewindNotice by remember { mutableStateOf(false) }
    var forwardNotice by remember { mutableStateOf(false) }
    
    // Channel list state
    var showChannelList by remember { mutableStateOf(false) }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var channelGroups by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedGroup by remember { mutableStateOf("All Channels") }
    var filteredChannels by remember { mutableStateOf<List<Channel>>(emptyList()) }

    // Load channels from current playlist
    LaunchedEffect(channel.playlistId) {
        val playlist = vm.state.value.playlists.find { it.id == channel.playlistId }
        if (playlist != null) {
            val allChannels = vm.repository.loadChannels(playlist.id, ContentKind.LIVE)
            channels = allChannels
            
            // Extract unique groups
            val groups = mutableListOf("All Channels")
            groups.addAll(allChannels.map { it.group }.distinct().sorted())
            channelGroups = groups
            
            // Set initial filtered channels
            filteredChannels = allChannels
        }
    }
    
    // Update filtered channels when group selection changes
    LaunchedEffect(selectedGroup, channels) {
        filteredChannels = if (selectedGroup == "All Channels") {
            channels
        } else {
            channels.filter { it.group == selectedGroup }
        }
    }

    // Handle PiP mode changes
    LaunchedEffect(isInPipMode) {
        if (isInPipMode) {
            // Hide controls in PiP mode
            controls = false
        }
    }

    // Handle back button and PiP logic
    LaunchedEffect(Unit) {
        // Override back button behavior to enter PiP if enabled and video is playing
        // This will be handled by MainActivity's onUserLeaveHint
    }

    DisposableEffect(activity) {
        onDispose {
            activity?.let { act ->
                if (!isInPipMode) {
                    act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    act.window?.let { win ->
                        val windowController = WindowInsetsControllerCompat(win, win.decorView)
                        windowController.show(WindowInsetsCompat.Type.systemBars())
                    }
                }
            }
        }
    }

    LaunchedEffect(channel.id) {
        vm.addHistory(
            WatchHistory(
                id = channel.id, playlistId = channel.playlistId, channelId = channel.id,
                name = channel.name, logo = channel.logo, group = channel.group, kind = channel.kind,
                watchedAt = System.currentTimeMillis(),
            ),
        )
    }

    // Register media controller with MainActivity for PiP support
    LaunchedEffect(controller, state.settings.enablePictureInPicture, playing) {
        activity?.setCurrentPlayer(controller, state.settings.enablePictureInPicture)
        // Update PiP actions when play state changes
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O && isInPipMode) {
            controller?.let { ctrl ->
                activity?.let { act ->
                    val pipManager = com.black.pureiptv.player.PictureInPictureManager(context)
                    pipManager.updatePipActions(act, ctrl)
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            // Clear the controller reference when leaving the screen
            activity?.setCurrentPlayer(null, false)
        }
    }

    DisposableEffect(context) {
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        val executor = ContextCompat.getMainExecutor(context)

        controllerFuture.addListener({
            try {
                controller = controllerFuture.get()
            } catch (_: Exception) {
                error = true
                buffering = false
            }
        }, executor)

        onDispose {
            MediaController.releaseFuture(controllerFuture)
        }
    }

    DisposableEffect(controller, channel.id) {
        val player = controller ?: return@DisposableEffect onDispose {}

        // إعادة المحاولة التلقائية: تأخير تصاعدي (1s, 2s, 3s ... حتى 5s) بدون إظهار شاشة خطأ
        fun scheduleRetry() {
            if (retryJob?.isActive == true) return
            reconnecting = true
            buffering = true
            retryJob = retryScope.launch {
                val wait = (1000L * (retryCount + 1)).coerceAtMost(5000L)
                retryCount++
                delay(wait)
                if (live) {
                    player.seekToDefaultPosition() // العودة إلى أحدث نقطة في البث المباشر
                } else if (position > 0) {
                    player.seekTo(position)        // استئناف الفيلم/المسلسل من نفس المكان
                }
                player.prepare()
                player.play()
            }
        }

        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                buffering = playbackState == Player.STATE_BUFFERING || reconnecting
                if (playbackState == Player.STATE_READY) {
                    reconnecting = false
                    retryCount = 0
                    retryJob?.cancel()
                    duration = player.duration.coerceAtLeast(0)
                    live = player.isCurrentMediaItemLive || channel.kind == ContentKind.LIVE
                }
                // البث المباشر انتهى/انقطع من المصدر -> أعد الاتصال
                if (playbackState == Player.STATE_ENDED && channel.kind == ContentKind.LIVE) {
                    scheduleRetry()
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(err: PlaybackException) {
                // لا نُظهر شاشة الخطأ، بل نعيد المحاولة تلقائيًا
                scheduleRetry()
            }
        }
        player.addListener(listener)

        val currentMediaId = player.currentMediaItem?.mediaId
        if (currentMediaId != channel.id) {
            error = false
            reconnecting = false
            retryCount = 0
            retryJob?.cancel()
            buffering = true

            val metadata = MediaMetadata.Builder()
                .setTitle(channel.name)
                .setArtist("${channel.number.toString().padStart(3, '0')} · ${channel.group}")
                .setArtworkUri(channel.logo?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) })
                .build()

            val mediaItem = MediaItem.Builder()
                .setMediaId(channel.id)
                .setUri(channel.url)
                .setMediaMetadata(metadata)
                .build()

            player.setMediaItem(mediaItem)
            player.prepare()
            if (state.settings.autoPlay) player.play()
        } else {
            buffering = player.playbackState == Player.STATE_BUFFERING
            playing = player.isPlaying
            duration = player.duration.coerceAtLeast(0)
            position = player.currentPosition
            live = player.isCurrentMediaItemLive || channel.kind == ContentKind.LIVE
            if (player.playbackState == Player.STATE_IDLE) {
                player.prepare()
                if (state.settings.autoPlay) player.play()
            }
        }

        onDispose {
            retryJob?.cancel()
            player.removeListener(listener)
        }
    }

    LaunchedEffect(controller) {
        val player = controller ?: return@LaunchedEffect
        while (true) {
            position = player.currentPosition
            duration = player.duration.coerceAtLeast(0)
            delay(400)
        }
    }

    // إذا بقي البث في حالة تحميل أكثر من 20 ثانية دون تقدّم -> أعد المحاولة تلقائيًا
    LaunchedEffect(controller, buffering, channel.id) {
        val player = controller ?: return@LaunchedEffect
        if (buffering && !reconnecting) {
            delay(20_000)
            if (player.playbackState == Player.STATE_BUFFERING) {
                reconnecting = true
                retryJob?.cancel()
                player.seekToDefaultPosition()
                player.prepare()
                player.play()
                delay(2000)
                reconnecting = false
            }
        }
    }

    LaunchedEffect(controls, channel.id) {
        if (controls) {
            delay(3200)
            controls = false
        }
    }

    LaunchedEffect(rewindNotice) {
        if (rewindNotice) {
            delay(600)
            rewindNotice = false
        }
    }

    LaunchedEffect(forwardNotice) {
        if (forwardNotice) {
            delay(600)
            forwardNotice = false
        }
    }

    LaunchedEffect(resizeModeNotice) {
        if (resizeModeNotice != null) {
            delay(1200)
            resizeModeNotice = null
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        controls = !controls
                    },
                    onDoubleTap = { offset ->
                        val p = controller ?: return@detectTapGestures
                        val width = size.width
                        if (offset.x < width / 2) {
                            val target = (p.currentPosition - 10000L).coerceAtLeast(0L)
                            p.seekTo(target)
                            rewindNotice = true
                        } else {
                            val maxPos = if (p.duration > 0) p.duration else Long.MAX_VALUE
                            val target = (p.currentPosition + 10000L).coerceAtMost(maxPos)
                            p.seekTo(target)
                            forwardNotice = true
                        }
                    },
                )
            },
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    this.resizeMode = resizeMode
                    layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    this.player = controller
                }
            },
            update = {
                it.player = controller
                it.resizeMode = resizeMode
            },
            modifier = Modifier.fillMaxSize(),
        )

        // Double tap rewind visual indicator (-10s)
        if (rewindNotice) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.35f)
                    .align(Alignment.CenterStart)
                    .background(Color.White.copy(0.18f), shape = CircleShape)
                    .padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Replay10, null, tint = Color.White, modifier = Modifier.size(44.dp))
                    Text("-10s", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        // Double tap forward visual indicator (+10s)
        if (forwardNotice) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.35f)
                    .align(Alignment.CenterEnd)
                    .background(Color.White.copy(0.18f), shape = CircleShape)
                    .padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Forward10, null, tint = Color.White, modifier = Modifier.size(44.dp))
                    Text("+10s", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        // Aspect ratio change toast
        if (resizeModeNotice != null) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 56.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(0.8f))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Text(resizeModeNotice!!, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }

        if ((buffering || controller == null) && !error) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = c.primary)
                    if (reconnecting) {
                        Text(
                            "Reconnecting…",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 12.dp),
                        )
                    }
                }
            }
        }

        if (error) {
            Column(Modifier.fillMaxSize().background(Color.Black.copy(0.8f)).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(vm.t(I18nKey.unablePlay), color = Color.White, fontWeight = FontWeight.Medium)
                Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.weight(1f)) { SecondaryButton(vm.t(I18nKey.back), onBack) }
                    Box(Modifier.weight(1f)) {
                        PrimaryButton(vm.t(I18nKey.retry), {
                            error = false
                            buffering = true
                            controller?.prepare()
                            controller?.play()
                        })
                    }
                }
            }
        }

        // تدرج خفيف أعلى وأسفل الشاشة لتبقى الأزرار واضحة فوق الفيديو
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color.Black.copy(if (controls) 0.65f else 0f),
                        Color.Transparent,
                        Color.Transparent,
                        Color.Black.copy(if (controls) 0.78f else 0f),
                    ),
                ),
            ),
        )

        if (controls) {
            // ── الشريط العلوي ──
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                GlassButton(Icons.AutoMirrored.Filled.ArrowBack, "Back") {
                    // أوقف المشغّل بالكامل قبل الرجوع
                    controller?.stop()
                    controller?.clearMediaItems()
                    onBack()
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        channel.name,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        "${channel.number.toString().padStart(3, '0')} · ${channel.group}",
                        color = Color.White.copy(0.7f),
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                GlassButton(Icons.Filled.Star, "Favorite", tint = if (favorite) c.warn else Color.White) {
                    vm.toggleFavorite(vm.makeFavorite(channel.id, channel.playlistId, channel.kind, channel.name, channel.logo, channel.group))
                }
            }

            // ── أزرار الوسط: -10 | تشغيل/إيقاف | +10 ──
            Row(
                Modifier.align(Alignment.Center),
                horizontalArrangement = Arrangement.spacedBy(28.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlassButton(Icons.Filled.Replay10, "Rewind 10s", size = 52.dp, iconSize = 28.dp) {
                    controller?.let { p ->
                        p.seekTo((p.currentPosition - 10000L).coerceAtLeast(0L))
                        rewindNotice = true
                    }
                }

                Box(
                    Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable {
                            val p = controller ?: return@clickable
                            if (p.isPlaying) p.pause() else p.play()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (playing) "Pause" else "Play",
                        tint = Color(0xFF0B1020),
                        modifier = Modifier.size(42.dp),
                    )
                }

                GlassButton(Icons.Filled.Forward10, "Forward 10s", size = 52.dp, iconSize = 28.dp) {
                    controller?.let { p ->
                        val maxPos = if (p.duration > 0) p.duration else Long.MAX_VALUE
                        p.seekTo((p.currentPosition + 10000L).coerceAtMost(maxPos))
                        forwardNotice = true
                    }
                }
            }

            // ── الشريط السفلي ──
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                if (!live && duration > 0) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(formatTime(position), color = Color.White, fontSize = 12.sp)
                        Slider(
                            value = (position.toFloat() / duration.toFloat()).coerceIn(0f, 1f),
                            onValueChange = { controller?.seekTo((it * duration).toLong()) },
                            colors = SliderDefaults.colors(
                                thumbColor = c.primary,
                                activeTrackColor = c.primary,
                                inactiveTrackColor = Color.White.copy(0.25f),
                            ),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                        )
                        Text(formatTime(duration), color = Color.White.copy(0.7f), fontSize = 12.sp)
                    }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        GlassButton(if (muted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp, "Mute") {
                            muted = !muted
                            controller?.volume = if (muted) 0f else 1f
                        }
                        if (live) {
                            Row(
                                Modifier
                                    .clip(CircleShape)
                                    .background(c.live)
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Box(Modifier.size(6.dp).clip(CircleShape).background(Color.White))
                                Text(vm.t(I18nKey.live), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // نسبة العرض: Fit / Zoom / Fill
                        GlassButton(Icons.Filled.AspectRatio, "Aspect Ratio") {
                            when (resizeMode) {
                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> {
                                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                    resizeModeNotice = "Zoom (Crop)"
                                }
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> {
                                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
                                    resizeModeNotice = "Fill (Stretch)"
                                }
                                else -> {
                                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    resizeModeNotice = "Fit (Original)"
                                }
                            }
                        }

                        // قائمة القنوات
                        GlassButton(Icons.Filled.List, "Channel List", active = showChannelList) {
                            showChannelList = !showChannelList
                        }

                        // صورة داخل صورة
                        if (state.settings.enablePictureInPicture && activity?.isPipSupported() == true && !isInPipMode) {
                            GlassButton(Icons.Filled.PictureInPictureAlt, "Picture in Picture") {
                                activity.enterPictureInPictureMode(controller)
                            }
                        }

                        // ملء الشاشة
                        GlassButton(
                            if (isFullscreen || isLandscape) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                            "Fullscreen",
                        ) {
                            val win = activity?.window
                            val insetsController = win?.let { WindowInsetsControllerCompat(it, it.decorView) }
                            if (isFullscreen || isLandscape) {
                                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                insetsController?.show(WindowInsetsCompat.Type.systemBars())
                                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                                isFullscreen = false
                            } else {
                                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                insetsController?.hide(WindowInsetsCompat.Type.systemBars())
                                insetsController?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                                isFullscreen = true
                            }
                        }
                    }
                }
            }
        }

        // Channel List Overlay - Modern Design with VIEW MODE
        if (showChannelList && !isInPipMode) {
            InPlayerChannelList(
                vm = vm,
                channels = channels,
                currentChannel = channel,
                selectedGroup = selectedGroup,
                onGroupChanged = { selectedGroup = it },
                onChannelSelected = { selectedChannel ->
                    // Switch to the selected channel
                    showChannelList = false
                    
                    controller?.let { player ->
                        player.stop()
                        player.clearMediaItems()
                        
                        val metadata = MediaMetadata.Builder()
                            .setTitle(selectedChannel.name)
                            .setArtist("${selectedChannel.number.toString().padStart(3, '0')} · ${selectedChannel.group}")
                            .setArtworkUri(selectedChannel.logo?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) })
                            .build()

                        val mediaItem = MediaItem.Builder()
                            .setMediaId(selectedChannel.id)
                            .setUri(selectedChannel.url)
                            .setMediaMetadata(metadata)
                            .build()

                        player.setMediaItem(mediaItem)
                        player.prepare()
                        if (state.settings.autoPlay) player.play()
                        
                        // Add to history
                        vm.addHistory(
                            WatchHistory(
                                id = selectedChannel.id,
                                playlistId = selectedChannel.playlistId,
                                channelId = selectedChannel.id,
                                name = selectedChannel.name,
                                logo = selectedChannel.logo,
                                group = selectedChannel.group,
                                kind = selectedChannel.kind,
                                watchedAt = System.currentTimeMillis()
                            )
                        )
                    }
                },
                onClose = { showChannelList = false },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/** زر دائري شبه شفاف يُستعمل في كل أزرار المشغّل. */
@Composable
private fun GlassButton(
    icon: ImageVector,
    description: String,
    size: Dp = 42.dp,
    iconSize: Dp = 22.dp,
    tint: Color = Color.White,
    active: Boolean = false,
    onClick: () -> Unit,
) {
    val c = LocalIptvColors.current
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (active) c.primary.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.14f))
            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(iconSize))
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val sec = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

private fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}


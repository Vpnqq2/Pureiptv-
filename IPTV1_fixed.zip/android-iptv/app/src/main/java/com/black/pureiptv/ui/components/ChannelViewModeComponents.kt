package com.black.pureiptv.ui.components

import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.ui.theme.LocalIptvColors

enum class ChannelViewMode {
    LIST, GRID
}

@Composable
fun ChannelsList(
    channels: List<Channel>,
    viewMode: ChannelViewMode,
    favorites: Set<String>,
    onChannelClick: (String) -> Unit,
    onFavoriteClick: (Channel) -> Unit,
    vm: AppViewModel
) {
    when (viewMode) {
        ChannelViewMode.LIST -> {
            LazyColumn(contentPadding = PaddingValues(top = 4.dp, bottom = 20.dp)) {
                items(channels) { channel ->
                    ChannelRow(
                        channel = channel,
                        favorite = channel.id in favorites,
                        onOpen = { onChannelClick(channel.id) },
                        onToggleFavorite = { onFavoriteClick(channel) }
                    )
                }
            }
        }
        ChannelViewMode.GRID -> {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 150.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = 20.dp)
            ) {
                items(channels) { channel ->
                    ChannelGridCard(
                        channel = channel,
                        isFavorite = channel.id in favorites,
                        onClick = { onChannelClick(channel.id) },
                        onFavorite = { onFavoriteClick(channel) }
                    )
                }
            }
        }
    }
}

@Composable
fun ChannelGridCard(
    channel: Channel,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit
) {
    val c = LocalIptvColors.current
    val shape = RoundedCornerShape(22.dp)
    val (title, quality) = remember(channel.name) { splitQuality(channel.name) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(BorderStroke(1.dp, c.border), shape)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 18.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                Modifier.size(80.dp).clip(RoundedCornerShape(20.dp)).background(c.surface2),
                contentAlignment = Alignment.Center,
            ) { ChannelLogo(channel.name, channel.logo ?: channel.poster, 62.dp) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = title,
                    color = c.fg,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    minLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 19.sp,
                )
                if (quality != null) { Spacer(Modifier.height(6.dp)); QualityPill(quality) }
                Text(
                    text = channel.group.substringBefore(';').substringBefore('|').trim(),
                    color = c.muted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
        }
        // زر المفضلة في الزاوية
        IconButton(
            onClick = onFavorite,
            modifier = Modifier.align(Alignment.TopEnd).size(30.dp),
        ) {
            Icon(
                Icons.Filled.Favorite,
                contentDescription = "Favorite",
                tint = if (isFavorite) c.primary else c.subtle.copy(alpha = 0.6f),
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

package com.black.pureiptv.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.ui.theme.IptvColors
import com.black.pureiptv.ui.theme.LocalIptvColors

private const val ALL_GROUP = "All Channels" // نفس المفتاح المستعمل في PlayerScreen

@Composable
fun InPlayerChannelList(
    vm: AppViewModel,
    channels: List<Channel>,
    currentChannel: Channel,
    selectedGroup: String,
    onGroupChanged: (String) -> Unit,
    onChannelSelected: (Channel) -> Unit,
    modifier: Modifier = Modifier,
    onClose: () -> Unit = {},
) {
    val c = LocalIptvColors.current
    var viewMode by remember { mutableStateOf(ChannelViewMode.LIST) }

    val channelGroups = remember(channels) {
        listOf(ALL_GROUP) + channels.map { it.group }.distinct().sorted()
    }
    val filteredChannels = remember(selectedGroup, channels) {
        if (selectedGroup == ALL_GROUP) channels else channels.filter { it.group == selectedGroup }
    }

    // ظهور اللوحة بحركة انزلاق واحدة عند الفتح
    val visibleState = remember { MutableTransitionState(false).apply { targetState = true } }

    Box(modifier = modifier.fillMaxSize()) {
        // خلفية معتمة: الضغط عليها يغلق القائمة
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.45f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClose,
                ),
        )

        AnimatedVisibility(
            visibleState = visibleState,
            modifier = Modifier.align(Alignment.CenterEnd),
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
        ) {
            Column(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.88f)
                    .widthIn(max = 380.dp)
                    .clip(RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp))
                    .background(c.bgElevated.copy(alpha = 0.97f))
                    .border(
                        BorderStroke(1.dp, c.border),
                        RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp),
                    )
                    // يمنع الضغط داخل اللوحة من إغلاقها
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {},
                    )
                    .statusBarsPadding()
                    .navigationBarsPadding(),
            ) {
                // ── الرأس ──
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 12.dp, top = 16.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Channels",
                            color = c.fg,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            "${filteredChannels.size} available",
                            color = c.muted,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 2.dp),
                        )
                    }

                    ViewModeSwitch(viewMode = viewMode, onChange = { viewMode = it }, c = c)

                    Box(
                        Modifier
                            .padding(start = 8.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(c.surface2)
                            .clickable(onClick = onClose),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Filled.Close, "Close", tint = c.fg, modifier = Modifier.size(18.dp))
                    }
                }

                // ── المجموعات ──
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                ) {
                    items(channelGroups) { group ->
                        GroupPill(
                            label = if (group == ALL_GROUP) "All" else group,
                            selected = group == selectedGroup,
                            onClick = { onGroupChanged(group) },
                            c = c,
                        )
                    }
                }

                // ── القنوات ──
                Box(Modifier.fillMaxSize()) {
                    when (viewMode) {
                        ChannelViewMode.LIST -> ChannelRows(
                            channels = filteredChannels,
                            currentChannel = currentChannel,
                            onSelect = { onChannelSelected(it); onClose() },
                            c = c,
                        )
                        ChannelViewMode.GRID -> ChannelTiles(
                            channels = filteredChannels,
                            currentChannel = currentChannel,
                            onSelect = { onChannelSelected(it); onClose() },
                            c = c,
                        )
                    }
                }
            }
        }
    }
}

// ───────────────────────── عناصر مساعدة ─────────────────────────

@Composable
private fun ViewModeSwitch(viewMode: ChannelViewMode, onChange: (ChannelViewMode) -> Unit, c: IptvColors) {
    Row(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(c.surface2)
            .padding(3.dp),
    ) {
        listOf(ChannelViewMode.LIST to Icons.Filled.List, ChannelViewMode.GRID to Icons.Filled.Apps).forEach { (mode, icon) ->
            val active = viewMode == mode
            Box(
                Modifier
                    .size(width = 36.dp, height = 30.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (active) c.primary else Color.Transparent)
                    .clickable { onChange(mode) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (active) c.primaryFg else c.muted,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
private fun GroupPill(label: String, selected: Boolean, onClick: () -> Unit, c: IptvColors) {
    Text(
        text = label,
        color = if (selected) c.primaryFg else c.muted,
        fontSize = 13.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) c.primary else c.surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
    )
}

/** شعار القناة، وإذا لم يتوفر يظهر أول حرفين من الاسم. */
@Composable
private fun ChannelLogo(channel: Channel, size: androidx.compose.ui.unit.Dp, c: IptvColors) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(c.surface2),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            channel.name.trim().take(2).uppercase(),
            color = c.muted,
            fontSize = (size.value * 0.30f).sp,
            fontWeight = FontWeight.Bold,
        )
        if (!channel.logo.isNullOrBlank()) {
            AsyncImage(
                model = channel.logo,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(6.dp),
            )
        }
    }
}

@Composable
private fun ChannelRows(
    channels: List<Channel>,
    currentChannel: Channel,
    onSelect: (Channel) -> Unit,
    c: IptvColors,
) {
    val state = rememberLazyListState()
    // عند الفتح: انتقل إلى القناة الحالية
    LaunchedEffect(Unit) {
        val i = channels.indexOfFirst { it.id == currentChannel.id }
        if (i > 2) state.scrollToItem(i - 2)
    }
    LazyColumn(
        state = state,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 16.dp),
    ) {
        items(channels) { channel ->
            val selected = channel.id == currentChannel.id
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (selected) c.primary.copy(alpha = 0.16f) else Color.Transparent)
                    .clickable { onSelect(channel) }
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                ChannelLogo(channel, 44.dp, c)
                Column(Modifier.weight(1f)) {
                    Text(
                        channel.name,
                        color = if (selected) c.fg else c.fg.copy(alpha = 0.92f),
                        fontSize = 15.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        channel.group,
                        color = c.muted,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (selected) {
                    Text(
                        "Playing",
                        color = c.primary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                } else {
                    Text(
                        channel.number.toString().padStart(3, '0'),
                        color = c.subtle,
                        fontSize = 12.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelTiles(
    channels: List<Channel>,
    currentChannel: Channel,
    onSelect: (Channel) -> Unit,
    c: IptvColors,
) {
    val state = rememberLazyGridState()
    LaunchedEffect(Unit) {
        val i = channels.indexOfFirst { it.id == currentChannel.id }
        if (i > 3) state.scrollToItem(i - 2)
    }
    LazyVerticalGrid(
        state = state,
        columns = GridCells.Fixed(2),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
    ) {
        items(channels) { channel ->
            val selected = channel.id == currentChannel.id
            Column(
                Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (selected) c.primary.copy(alpha = 0.16f) else c.surface)
                    .border(
                        BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) c.primary else c.border),
                        RoundedCornerShape(16.dp),
                    )
                    .clickable { onSelect(channel) }
                    .padding(horizontal = 10.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ChannelLogo(channel, 56.dp, c)
                Text(
                    channel.name,
                    color = c.fg,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    minLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 16.sp,
                )
            }
        }
    }
}

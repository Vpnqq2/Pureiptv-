package com.black.pureiptv.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.R
import com.black.pureiptv.ui.i18n.I18nKey
import com.black.pureiptv.ui.theme.LocalIptvColors

data class DrawerItem(
    val id: String,
    val titleKey: I18nKey,
    val icon: ImageVector,
    val isSelected: Boolean = false
)

@Composable
fun NavigationDrawerContent(
    vm: AppViewModel,
    currentRoute: String,
    onItemClick: (String) -> Unit
) {
    val colors = LocalIptvColors.current
    
    // قائمة العناصر
    val drawerItems = listOf(
        DrawerItem("home", I18nKey.home, Icons.Default.Home, currentRoute == "home"),
        DrawerItem("live", I18nKey.liveTv, Icons.Default.LiveTv, currentRoute == "live"),
        DrawerItem("favorites", I18nKey.favorites, Icons.Default.Favorite, currentRoute == "favorites"),
        DrawerItem("recent", I18nKey.recent, Icons.Default.History, currentRoute == "recent"),
        DrawerItem("playlists", I18nKey.playlists, Icons.Default.PlaylistPlay, currentRoute == "playlists"),
        DrawerItem("settings", I18nKey.settings, Icons.Default.Settings, currentRoute == "settings"),
        DrawerItem("help", I18nKey.help, Icons.Default.Help, currentRoute == "help"),
        DrawerItem("about", I18nKey.about, Icons.Default.Info, currentRoute == "about"),
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0F1A2E), // لون أغمق في الأعلى
                        Color(0xFF070B16)  // لون الخلفية الأساسي
                    )
                )
            )
    ) {
        // الهيدر مع اللوجو ومعلومات التطبيق
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp, 32.dp, 24.dp, 24.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // اللوجو بدون خلفية
                Image(
                    painter = painterResource(R.drawable.lo_go),
                    contentDescription = null,
                    modifier = Modifier.size(52.dp),
                    contentScale = ContentScale.Fit
                )
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Column {
                    Text(
                        text = "pureiptv",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "v1.0.0",
                        color = Color.White.copy(0.6f),
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // عناصر القائمة
        drawerItems.forEach { item ->
            DrawerMenuItem(
                item = item,
                vm = vm,
                colors = colors,
                onClick = { onItemClick(item.id) }
            )
        }
    }
}

@Composable
private fun DrawerMenuItem(
    item: DrawerItem,
    vm: AppViewModel,
    colors: com.black.pureiptv.ui.theme.IptvColors,
    onClick: () -> Unit
) {
    val backgroundColor = if (item.isSelected) colors.primary.copy(alpha = 0.16f) else Color.Transparent
    val textColor = if (item.isSelected) colors.primary else colors.fg
    val iconColor = if (item.isSelected) colors.primary else colors.muted

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(backgroundColor)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = item.icon,
            contentDescription = null,
            tint = iconColor,
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.width(20.dp))
        
        Text(
            text = vm.t(item.titleKey),
            color = textColor,
            fontSize = 16.sp,
            fontWeight = if (item.isSelected) FontWeight.SemiBold else FontWeight.Medium
        )
    }
}

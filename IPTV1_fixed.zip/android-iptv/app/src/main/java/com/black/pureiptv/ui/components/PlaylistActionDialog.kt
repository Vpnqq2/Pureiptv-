package com.black.pureiptv.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.data.model.Playlist
import com.black.pureiptv.ui.i18n.I18nKey
import com.black.pureiptv.ui.theme.LocalIptvColors

@Composable
fun PlaylistActionDialog(
    playlist: Playlist,
    vm: AppViewModel,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    val c = LocalIptvColors.current
    
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        title = {
            Text(
                text = playlist.name,
                color = c.fg,
                fontWeight = FontWeight.SemiBold,
                fontSize = 18.sp
            )
        },
        text = {
            Column {
                // Rename option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { 
                            onDismiss()
                            onRename() 
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(c.primary.copy(0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = c.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = vm.t(I18nKey.rename),
                        color = c.fg,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Delete option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { 
                            onDismiss()
                            onDelete() 
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(c.danger.copy(0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = c.danger,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = vm.t(I18nKey.delete),
                        color = c.danger,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(vm.t(I18nKey.cancel), color = c.primary)
            }
        }
    )
}

@Composable
fun RenamePlaylistDialog(
    playlist: Playlist,
    vm: AppViewModel,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val c = LocalIptvColors.current
    var name by remember { mutableStateOf(playlist.name) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        title = {
            Text(
                text = vm.t(I18nKey.rename),
                color = c.fg,
                fontWeight = FontWeight.SemiBold
            )
        },
        text = {
            Column {
                Text(
                    text = vm.t(I18nKey.playlistName),
                    color = c.muted,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                AppInput(
                    value = name,
                    onChange = { name = it },
                    placeholder = vm.t(I18nKey.playlistName)
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(vm.t(I18nKey.cancel), color = c.muted)
            }
        },
        confirmButton = {
            TextButton(
                onClick = { 
                    if (name.isNotBlank()) {
                        onConfirm(name.trim())
                        onDismiss()
                    }
                }
            ) {
                Text(vm.t(I18nKey.save), color = c.primary)
            }
        }
    )
}

@Composable
fun DeletePlaylistDialog(
    playlist: Playlist,
    vm: AppViewModel,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val c = LocalIptvColors.current
    
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        title = {
            Text(
                text = vm.t(I18nKey.deleteTitle),
                color = c.fg,
                fontWeight = FontWeight.SemiBold
            )
        },
        text = {
            Text(
                text = vm.t(I18nKey.deleteBody),
                color = c.muted,
                fontSize = 14.sp
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(vm.t(I18nKey.cancel), color = c.muted)
            }
        },
        confirmButton = {
            TextButton(
                onClick = { 
                    onConfirm()
                    onDismiss()
                }
            ) {
                Text(vm.t(I18nKey.delete), color = c.danger)
            }
        }
    )
}

package com.black.pureiptv.ui.nav

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.ads.GlobalInterstitialAdManager
import com.black.pureiptv.ads.GlobalAppOpenAdManager
import kotlinx.coroutines.delay
import com.black.pureiptv.player.PlayerRoute
import com.black.pureiptv.ui.screens.AboutScreen
import com.black.pureiptv.ui.screens.AddPlaylistScreen
import com.black.pureiptv.ui.screens.AppearanceScreen
import com.black.pureiptv.ui.screens.EpgChannelScreen
import com.black.pureiptv.ui.screens.EpgListScreen
import com.black.pureiptv.ui.screens.FavoritesScreen
import com.black.pureiptv.ui.screens.HelpScreen
import com.black.pureiptv.ui.screens.HomeScreen
import com.black.pureiptv.ui.screens.LanguageScreen
import com.black.pureiptv.ui.screens.LiveScreen
import com.black.pureiptv.ui.screens.M3uFileScreen
import com.black.pureiptv.ui.screens.M3uUrlScreen
import com.black.pureiptv.ui.screens.OnboardingScreen
import com.black.pureiptv.ui.screens.PlayerSettingsScreen
import com.black.pureiptv.ui.screens.PlaylistDetailScreen
import com.black.pureiptv.ui.screens.PlaylistsScreen
import com.black.pureiptv.ui.screens.PrivacyPolicyScreen
import com.black.pureiptv.ui.screens.RecentScreen
import com.black.pureiptv.ui.screens.SearchScreen
import com.black.pureiptv.ui.screens.SeriesDetailScreen
import com.black.pureiptv.ui.screens.SeriesListScreen
import com.black.pureiptv.ui.screens.SettingsHomeScreen
import com.black.pureiptv.ui.screens.SplashScreen
import com.black.pureiptv.ui.screens.TabsScaffold
import com.black.pureiptv.ui.screens.TermsOfServiceScreen
import com.black.pureiptv.ui.screens.VodDetailScreen
import com.black.pureiptv.ui.screens.VodScreen
import com.black.pureiptv.ui.screens.XtreamScreen

@Composable
fun AppNav(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val back by nav.currentBackStackEntryAsState()
    val route = back?.destination?.route.orEmpty()
    val tab = when {
        route == "home" -> "home"
        route == "live" -> "live"
        route == "favorites" -> "favorites"
        route == "settings" -> "settings"
        else -> null
    }

    fun go(dest: String) = nav.navigate(dest) { launchSingleTop = true }
    fun tabGo(id: String) {
        nav.navigate(id) {
            popUpTo("home") { inclusive = id == "home" }
            launchSingleTop = true
        }
    }

    Box(Modifier.fillMaxSize()) {
        NavHost(nav, startDestination = "splash") {
            composable("splash") {
                SplashScreen(vm) { done ->
                    nav.navigate(if (done) "home" else "onboarding") { popUpTo("splash") { inclusive = true } }
                }
            }
            composable("onboarding") {
                OnboardingScreen(vm) { nav.navigate("home") { popUpTo("onboarding") { inclusive = true } } }
            }
            composable("home") {
                val context = LocalContext.current
                val activity = context as? com.black.pureiptv.MainActivity
                
                LaunchedEffect(Unit) {
                    // Notify MainActivity that user has entered home screen
                    activity?.onUserEnteredHomeScreen()
                }
                
                TabsScaffold("home", vm, ::tabGo, ::go) { onOpenDrawer ->
                    HomeScreen(
                        vm,
                        onSearch = { go("search") },
                        onAdd = { go("add") },
                        onLive = { tabGo("live") },
                        onPlayer = { go("player/$it") },
                        onPlaylist = { go("playlist/$it") },
                        onNavigate = { dest ->
                            when (dest) {
                                "home", "live", "favorites", "settings" -> tabGo(dest)
                                "about" -> go("about")
                                else -> go(dest)
                            }
                        },
                    )
                }
            }
            composable("live") {
                TabsScaffold("live", vm, ::tabGo, ::go) { onOpenDrawer ->
                    LiveScreen(vm, { nav.popBackStack() }, { go("search") }, { go("player/$it") }, onOpenDrawer)
                }
            }
            composable("favorites") {
                TabsScaffold("favorites", vm, ::tabGo, ::go) { onOpenDrawer ->
                    FavoritesScreen(vm, { go("player/$it") }, onOpenDrawer)
                }
            }
            composable("settings") {
                TabsScaffold("settings", vm, ::tabGo, ::go) { onOpenDrawer ->
                    SettingsHomeScreen(vm, { go("language") }, { go("playerSettings") }, { go("appearance") }, { go("about") }, { go("privacy") }, { go("terms") }, onOpenDrawer)
                }
            }
            composable("add") { AddPlaylistScreen(vm, { nav.popBackStack() }, { go("addFile") }, { go("addM3u") }, { go("addXtream") }) }
            composable("addM3u") { M3uUrlScreen(vm, { nav.popBackStack() }, { go("playlist/$it") }) }
            composable("addFile") { M3uFileScreen(vm, { nav.popBackStack() }, { go("addM3u") }, { go("playlist/$it") }) }
            composable("addXtream") { XtreamScreen(vm, { nav.popBackStack() }, { go("playlist/$it") }) }
            composable("playlists") { PlaylistsScreen(vm, { nav.popBackStack() }, { go("add") }, { go("playlist/$it") }) }
            composable("playlist/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                val id = it.arguments?.getString("id").orEmpty()
                PlaylistDetailScreen(vm, id, { nav.popBackStack() }, { tabGo("live") }, { go("vod") }, { go("series") }, { go("epg") })
            }
            composable("player/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                val context = LocalContext.current
                val state by vm.state.collectAsState()
                val activity = context as? android.app.Activity
                val channelId = it.arguments?.getString("id").orEmpty()
                
                LaunchedEffect(channelId) {
                    // Show interstitial ad when entering a channel (opening player)
                    val interstitialManager = GlobalInterstitialAdManager.getInstance(context)
                    if (interstitialManager.canShowAd() && activity != null) {
                        delay(300) // Small delay to let the screen render first
                        interstitialManager.showAd(
                            activity,
                            adsEnabled = state.settings.adsEnabled,
                            adsFreeUntil = state.settings.adsFreeUntil
                        )
                    }
                }
                
                PlayerRoute(vm, channelId) { nav.popBackStack() }
            }
            composable("vod") { VodScreen(vm, { nav.popBackStack() }, { go("vod/$it") }) }
            composable("vod/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                VodDetailScreen(vm, it.arguments?.getString("id").orEmpty(), { nav.popBackStack() }, { go("player/$it") })
            }
            composable("series") { SeriesListScreen(vm, { nav.popBackStack() }, { go("series/$it") }) }
            composable("series/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                SeriesDetailScreen(vm, it.arguments?.getString("id").orEmpty(), { nav.popBackStack() }, { go("player/$it") })
            }
            composable("epg") { EpgListScreen(vm, { nav.popBackStack() }, { go("epg/$it") }) }
            composable("epg/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                EpgChannelScreen(vm, it.arguments?.getString("id").orEmpty(), { nav.popBackStack() }, { go("player/$it") })
            }
            composable("search") { SearchScreen(vm, { nav.popBackStack() }, { go("player/$it") }) }
            composable("recent") { RecentScreen(vm, { nav.popBackStack() }, { go("player/$it") }, { tabGo("live") }) }
            composable("help") { HelpScreen(vm) { nav.popBackStack() } }
            composable("about") { AboutScreen(vm, { nav.popBackStack() }, { go("privacy") }, { go("terms") }) }
            composable("privacy") { PrivacyPolicyScreen(vm) { nav.popBackStack() } }
            composable("terms") { TermsOfServiceScreen(vm) { nav.popBackStack() } }
            composable("appearance") { AppearanceScreen(vm) { nav.popBackStack() } }
            composable("language") { LanguageScreen(vm) { nav.popBackStack() } }
            composable("playerSettings") { PlayerSettingsScreen(vm) { nav.popBackStack() } }
        }
    }
}


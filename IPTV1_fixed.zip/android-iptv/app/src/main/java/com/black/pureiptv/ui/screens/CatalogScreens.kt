package com.black.pureiptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.data.epg.Xmltv
import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.data.model.ContentKind
import com.black.pureiptv.data.model.EpgProgram
import com.black.pureiptv.data.model.SeriesShow
import com.black.pureiptv.ui.components.AppInput
import com.black.pureiptv.ui.components.ChannelLogo
import com.black.pureiptv.ui.components.Chip
import com.black.pureiptv.ui.components.EmptyState
import com.black.pureiptv.ui.components.PrimaryButton
import com.black.pureiptv.ui.components.Screen
import com.black.pureiptv.ui.components.SpinnerBox
import com.black.pureiptv.ui.components.TopBar
import com.black.pureiptv.ui.i18n.I18nKey
import com.black.pureiptv.ui.theme.LocalIptvColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VodScreen(vm: AppViewModel, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val playlist = vm.activePlaylist()
    var movies by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var cat by remember { mutableStateOf("All") }
    var q by remember { mutableStateOf("") }
    val c = LocalIptvColors.current
    LaunchedEffect(playlist?.id) {
        playlist?.let { movies = vm.repository.loadChannels(it.id, ContentKind.MOVIE) }
    }
    val groups = listOf("All") + movies.map { it.group }.distinct()
    val filtered = movies.filter { (cat == "All" || it.group == cat) && (q.isBlank() || it.name.contains(q, true)) }.take(200)
    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding().padding(horizontal = 20.dp)) {
        TopBar(vm.t(I18nKey.movies), onBack)
        AppInput(q, { q = it }, vm.t(I18nKey.search))
        Spacer(Modifier.height(12.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            groups.forEach { g -> Chip(if (g == "All") vm.t(I18nKey.all) else g, cat == g) { cat = g }; Spacer(Modifier.width(8.dp)) }
        }
        Spacer(Modifier.height(12.dp))
        if (filtered.isEmpty()) EmptyState(vm.t(I18nKey.noChannels))
        else LazyVerticalGrid(GridCells.Fixed(2)) {
            items(filtered, key = { it.id }) { m ->
                Column(Modifier.padding(6.dp).clickable { onOpen(m.id) }) {
                    AsyncImage(m.poster ?: m.logo, null, Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp)).background(c.surface), contentScale = ContentScale.Crop)
                    Spacer(Modifier.height(8.dp))
                    Text(m.name, color = c.fg, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(listOfNotNull(m.year, m.rating).joinToString(" · "), color = c.muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun VodDetailScreen(vm: AppViewModel, id: String, onBack: () -> Unit, onPlay: (String) -> Unit) {
    val state by vm.state.collectAsState()
    var movie by remember { mutableStateOf<Channel?>(null) }
    var loading by remember { mutableStateOf(true) }
    val c = LocalIptvColors.current
    LaunchedEffect(id) { movie = vm.repository.getChannel(id); loading = false }
    if (loading) { Screen { SpinnerBox() }; return }
    val m = movie
    if (m == null) { Screen { EmptyState(vm.t(I18nKey.noChannels)) }; return }
    val fav = state.favorites.any { it.id == id }
    Screen {
        TopBar(m.name, onBack)
        Row {
            ChannelLogo(m.name, m.poster ?: m.logo, 120.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(m.name, color = c.fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text(listOfNotNull(m.year, m.genre).joinToString(" · "), color = c.muted, fontSize = 14.sp)
                m.rating?.let { Text(it, color = c.warn, fontSize = 14.sp) }
            }
        }
        m.plot?.let { Text(it, color = c.muted, fontSize = 14.sp, modifier = Modifier.padding(top = 16.dp)) }
        Spacer(Modifier.height(24.dp))
        Row {
            PrimaryButton(vm.t(I18nKey.watchNow), { onPlay(m.id) }, Modifier.weight(1f))
            IconButton(onClick = { vm.toggleFavorite(vm.makeFavorite(m.id, m.playlistId, ContentKind.MOVIE, m.name, m.poster ?: m.logo, m.group)) }) {
                Icon(Icons.Filled.Star, null, tint = if (fav) c.warn else c.muted)
            }
        }
    }
}

@Composable
fun SeriesListScreen(vm: AppViewModel, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val playlist = vm.activePlaylist()
    var series by remember { mutableStateOf<List<SeriesShow>>(emptyList()) }
    var cat by remember { mutableStateOf("All") }
    val c = LocalIptvColors.current
    LaunchedEffect(playlist?.id) { playlist?.let { series = vm.repository.loadSeries(it.id) } }
    val groups = listOf("All") + series.map { it.categoryName ?: "Series" }.distinct()
    val filtered = series.filter { cat == "All" || (it.categoryName ?: "Series") == cat }.take(200)
    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding().padding(horizontal = 20.dp)) {
        TopBar(vm.t(I18nKey.series), onBack)
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            groups.forEach { g -> Chip(if (g == "All") vm.t(I18nKey.all) else g, cat == g) { cat = g }; Spacer(Modifier.width(8.dp)) }
        }
        Spacer(Modifier.height(12.dp))
        if (filtered.isEmpty()) EmptyState(vm.t(I18nKey.noChannels))
        else LazyVerticalGrid(GridCells.Fixed(2)) {
            items(filtered, key = { it.id }) { s ->
                Column(Modifier.padding(6.dp).clickable { onOpen(s.id) }) {
                    AsyncImage(s.poster, null, Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp)).background(c.surface), contentScale = ContentScale.Crop)
                    Spacer(Modifier.height(8.dp))
                    Text(s.name, color = c.fg, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(listOfNotNull(s.year, s.genre).joinToString(" · "), color = c.muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun SeriesDetailScreen(vm: AppViewModel, id: String, onBack: () -> Unit, onPlay: (String) -> Unit) {
    val playlist = vm.activePlaylist()
    var show by remember { mutableStateOf<SeriesShow?>(null) }
    var episodes by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var season by remember { mutableIntStateOf(1) }
    var loading by remember { mutableStateOf(true) }
    val c = LocalIptvColors.current
    LaunchedEffect(id, playlist?.id) {
        val s = vm.repository.getSeries(id)
        show = s
        if (s != null && playlist != null) {
            episodes = withContext(Dispatchers.IO) { vm.repository.loadSeriesEpisodes(playlist, s) }
            season = episodes.firstOrNull()?.season ?: 1
        }
        loading = false
    }
    if (loading) { Screen { SpinnerBox() }; return }
    val s = show
    if (s == null) { Screen { EmptyState(vm.t(I18nKey.noChannels)) }; return }
    val seasons = episodes.map { it.season ?: 1 }.distinct().sorted()
    val list = episodes.filter { (it.season ?: 1) == season }.sortedBy { it.episode ?: 0 }
    Screen {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            TopBar(s.name, onBack)
            Row {
                ChannelLogo(s.name, s.poster, 120.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(s.name, color = c.fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text(listOfNotNull(s.year, s.genre).joinToString(" · "), color = c.muted, fontSize = 14.sp)
                }
            }
            s.plot?.let { Text(it, color = c.muted, fontSize = 14.sp, modifier = Modifier.padding(top = 16.dp)) }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                seasons.forEach { n -> Chip("${vm.t(I18nKey.season)} $n", season == n) { season = n }; Spacer(Modifier.width(8.dp)) }
            }
            list.forEach { ep ->
                Column(Modifier.fillMaxWidth().clickable { onPlay(ep.id) }.padding(vertical = 12.dp)) {
                    Text("${vm.t(I18nKey.episode)} ${ep.episode ?: ""} · ${ep.name}", color = c.fg, fontWeight = FontWeight.Medium)
                }
            }
            if (list.isEmpty()) EmptyState(vm.t(I18nKey.noChannels))
        }
    }
}

@Composable
fun EpgListScreen(vm: AppViewModel, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val playlist = vm.activePlaylist()
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    val c = LocalIptvColors.current
    LaunchedEffect(playlist?.id) {
        playlist?.let { channels = vm.repository.loadChannels(it.id, ContentKind.LIVE) }
    }
    val withEpg = channels.filter { !it.tvgId.isNullOrBlank() }
    val list = (if (withEpg.isNotEmpty()) withEpg else channels).take(200)
    Screen {
        TopBar(vm.t(I18nKey.epg), onBack)
        if (playlist == null) EmptyState(vm.t(I18nKey.noPlaylists))
        else if (channels.isEmpty()) EmptyState(vm.t(I18nKey.noEpg))
        else Column(Modifier.verticalScroll(rememberScrollState())) {
            list.forEach { ch ->
                Row(Modifier.fillMaxWidth().clickable { onOpen(ch.id) }.padding(vertical = 8.dp)) {
                    ChannelLogo(ch.name, ch.logo)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(ch.name, color = c.fg, fontWeight = FontWeight.Medium)
                        Text(ch.group, color = c.muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun EpgChannelScreen(vm: AppViewModel, channelId: String, onBack: () -> Unit, onPlay: (String) -> Unit) {
    val playlist = vm.activePlaylist()
    var channel by remember { mutableStateOf<Channel?>(null) }
    var programs by remember { mutableStateOf<List<EpgProgram>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val c = LocalIptvColors.current
    LaunchedEffect(channelId, playlist?.epgUrl) {
        val ch = vm.repository.getChannel(channelId)
        channel = ch
        if (ch?.tvgId != null) programs = vm.repository.loadEpg(ch.tvgId)
        if (playlist?.epgUrl != null) {
            runCatching {
                val parsed = withContext(Dispatchers.IO) { vm.repository.fetchEpg(playlist.epgUrl) }
                if (ch?.tvgId != null) {
                    val mine = parsed.filter { it.channelTvgId == ch.tvgId }
                    if (mine.isNotEmpty()) programs = mine
                }
            }
        }
        loading = false
    }
    val (current, next) = Xmltv.nowAndNext(programs)
    val progress = if (current != null && current.end > current.start) {
        ((System.currentTimeMillis() - current.start).toFloat() / (current.end - current.start)).coerceIn(0f, 1f)
    } else 0f
    val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    Screen {
        TopBar(vm.t(I18nKey.epg), onBack)
        if (loading) SpinnerBox()
        else if (channel == null) EmptyState(vm.t(I18nKey.noEpg))
        else {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.card).padding(12.dp)) {
                    ChannelLogo(channel!!.name, channel!!.logo, 52.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(channel!!.name, color = c.fg, fontWeight = FontWeight.SemiBold)
                        Text(channel!!.number.toString().padStart(3, '0'), color = c.muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                if (programs.isEmpty()) EmptyState(vm.t(I18nKey.noEpg))
                else programs.take(40).forEach { p ->
                    val isNow = current?.id == p.id
                    Column(
                        Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (isNow) c.primary else c.card).padding(16.dp),
                    ) {
                        Row {
                            Text(fmt.format(Date(p.start)), color = if (isNow) c.primaryFg else c.fg, fontSize = 14.sp)
                            Spacer(Modifier.weight(1f))
                            if (isNow) Text(vm.t(I18nKey.live), color = c.primaryFg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Text(p.title, color = if (isNow) c.primaryFg else c.fg, fontWeight = FontWeight.Medium)
                    }
                }
                next?.let { Text("${vm.t(I18nKey.nextProgram)}: ${it.title}", color = c.muted, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)) }
                Spacer(Modifier.height(24.dp))
                PrimaryButton(vm.t(I18nKey.watchNow), { onPlay(channel!!.id) })
            }
        }
    }
}

@Composable
fun SearchScreen(vm: AppViewModel, onBack: () -> Unit, onPlayer: (String) -> Unit) {
    val state by vm.state.collectAsState()
    var q by remember { mutableStateOf("") }
    var debounced by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Channel>>(emptyList()) }
    val c = LocalIptvColors.current
    LaunchedEffect(q) { delay(180); debounced = q.trim() }
    LaunchedEffect(debounced) {
        results = if (debounced.isBlank()) emptyList()
        else vm.repository.search(debounced, vm.activePlaylist()?.id)
    }
    Screen {
        TopBar(vm.t(I18nKey.search), onBack)
        AppInput(q, { q = it }, vm.t(I18nKey.search))
        Spacer(Modifier.height(16.dp))
        if (debounced.isBlank() && state.recentSearches.isNotEmpty()) {
            Text(vm.t(I18nKey.recentSearches), color = c.muted, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                state.recentSearches.forEach { s ->
                    Chip(s, false) { q = s }
                    Spacer(Modifier.width(8.dp))
                }
            }
        }
        if (debounced.isNotBlank() && results.isEmpty()) EmptyState(vm.t(I18nKey.noResults))
        val grouped = mapOf(
            I18nKey.channels to results.filter { it.kind == ContentKind.LIVE },
            I18nKey.movies to results.filter { it.kind == ContentKind.MOVIE },
            I18nKey.series to results.filter { it.kind == ContentKind.SERIES },
        )
        grouped.forEach { (label, list) ->
            if (list.isNotEmpty()) {
                Text(vm.t(label), color = c.muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 8.dp))
                list.forEach { ch ->
                    Row(Modifier.fillMaxWidth().clickable { vm.addSearch(q); onPlayer(ch.id) }.padding(vertical = 8.dp)) {
                        ChannelLogo(ch.name, ch.logo ?: ch.poster)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(ch.name, color = c.fg, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(ch.group, color = c.muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RecentScreen(vm: AppViewModel, onBack: () -> Unit, onPlayer: (String) -> Unit, onLive: () -> Unit) {
    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    Screen {
        TopBar(vm.t(I18nKey.recent), onBack) {
            if (state.history.isNotEmpty()) Text(vm.t(I18nKey.clearHistory), color = c.primary, modifier = Modifier.clickable { vm.clearHistory() })
        }
        if (state.history.isEmpty()) {
            EmptyState(vm.t(I18nKey.noRecent))
            PrimaryButton(vm.t(I18nKey.liveTv), onLive)
        } else Column(Modifier.verticalScroll(rememberScrollState())) {
            state.history.forEach { h ->
                Row(Modifier.fillMaxWidth().clickable { onPlayer(h.channelId) }.padding(vertical = 8.dp)) {
                    ChannelLogo(h.name, h.logo)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(h.name, color = c.fg, fontWeight = FontWeight.Medium)
                        Text(h.group.orEmpty(), color = c.muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun HelpScreen(vm: AppViewModel, onBack: () -> Unit) {
    val c = LocalIptvColors.current
    Screen {
        TopBar(vm.t(I18nKey.help), onBack)
        Text(vm.t(I18nKey.helpBody), color = c.fg, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))
        listOf("M3U" to "Paste an HTTP(S) M3U / M3U8 URL, or pick a .m3u file from your device.",
            "Xtream Codes" to "Server URL, username and password are sent only to your IPTV server. The password is stored encrypted on this device.",
            "Playback" to "HLS and MP4 streams play in Media3 ExoPlayer. Live channels hide the seek bar when seeking is not supported.",
        ).forEach { (h, b) ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(c.card).padding(16.dp)) {
                Text(h, color = c.fg, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(b, color = c.muted, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}


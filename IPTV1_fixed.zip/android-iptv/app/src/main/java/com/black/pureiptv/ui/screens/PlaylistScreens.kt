package com.black.pureiptv.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.data.model.ContentKind
import com.black.pureiptv.data.model.ParseStats
import com.black.pureiptv.data.model.Playlist
import com.black.pureiptv.data.model.PlaylistSource
import com.black.pureiptv.data.model.PlaylistType
import com.black.pureiptv.data.model.XtreamUserInfo
import com.black.pureiptv.data.xtream.Xtream
import com.black.pureiptv.ui.components.AppInput
import com.black.pureiptv.ui.components.CardButton
import com.black.pureiptv.ui.components.EmptyState
import com.black.pureiptv.ui.components.Field
import com.black.pureiptv.ui.components.PrimaryButton
import com.black.pureiptv.ui.components.Screen
import com.black.pureiptv.ui.components.SecondaryButton
import com.black.pureiptv.ui.components.SpinnerBox
import com.black.pureiptv.ui.components.TopBar
import com.black.pureiptv.ui.i18n.I18nKey
import com.black.pureiptv.ui.theme.LocalIptvColors
import com.black.pureiptv.ads.NativeAdView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AddPlaylistScreen(vm: AppViewModel, onBack: () -> Unit, onFile: () -> Unit, onM3u: () -> Unit, onXtream: () -> Unit) {
    val state by vm.state.collectAsState()
    Screen {
        TopBar(vm.t(I18nKey.addPlaylistTitle), onBack)
        CardButton(Icons.Filled.Description, vm.t(I18nKey.m3uFile), vm.t(I18nKey.m3uFileDesc), onFile)
        Spacer(Modifier.height(12.dp))
        CardButton(Icons.Filled.Link, vm.t(I18nKey.m3uUrl), vm.t(I18nKey.m3uUrlDesc), onM3u)
        Spacer(Modifier.height(12.dp))
        CardButton(Icons.Filled.Cloud, vm.t(I18nKey.xtream), vm.t(I18nKey.xtreamDesc), onXtream)
        Spacer(Modifier.height(24.dp))
        
        // Native Ad in the bottom half of the screen
        NativeAdView(
            adsEnabled = state.settings.adsEnabled,
            adsFreeUntil = state.settings.adsFreeUntil,
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
        )
    }
}

@Composable
fun M3uUrlScreen(vm: AppViewModel, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("My M3U Playlist") }
    var url by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var stats by remember { mutableStateOf<ParseStats?>(null) }
    var savedId by remember { mutableStateOf<String?>(null) }
    val c = LocalIptvColors.current
    val scope = rememberCoroutineScope()
    fun load(target: String) {
        scope.launch {
            error = null; loading = true; stats = null
            try {
                val (p, st) = withContext(Dispatchers.IO) { vm.importM3uUrl(target, name) }
                savedId = p.id; stats = st
            } catch (e: Exception) {
                error = vm.localizedError(e)
            } finally { loading = false }
        }
    }
    if (loading) {
    if (loading) {
        Screen { SpinnerBox() }
        return
    }
    }
    Screen {
        TopBar(vm.t(I18nKey.m3uUrl), onBack)
        Field(vm.t(I18nKey.playlistName)) { AppInput(name, { name = it }) }
        Field(vm.t(I18nKey.playlistUrl)) { AppInput(url, { url = it }, "https://example.com/playlist.m3u") }
        error?.let { Text(it, color = c.danger, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp)) }
        stats?.let { st ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.card).padding(16.dp)) {
                Text(vm.t(I18nKey.loadedOk), color = c.success, fontWeight = FontWeight.Medium)
                Text("${st.channels} ${vm.t(I18nKey.channels)} · ${st.groups} ${vm.t(I18nKey.groups)}", color = c.muted, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
        }
        PrimaryButton(if (stats != null) vm.t(I18nKey.savePlaylist) else vm.t(I18nKey.next), { load(url) }, enabled = url.isNotBlank())
        Spacer(Modifier.height(12.dp))
        if (stats != null && savedId != null) {
            SecondaryButton(vm.t(I18nKey.open), { onOpen(savedId!!) })
        } else {
            Text(
                vm.t(I18nKey.needSample),
                color = c.primary,
                fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth().clickable {
                    url = "asset://sample-playlist.m3u"
                    name = "Demo Playlist"
                    scope.launch {
                        loading = true
                        try {
                            val text = ctx.assets.open("sample-playlist.m3u").bufferedReader().readText()
                            val (p, st) = withContext(Dispatchers.IO) {
                                vm.importM3uText(text, "Demo Playlist", PlaylistSource.URL, "sample-playlist.m3u")
                            }
                            savedId = p.id; stats = st
                        } catch (e: Exception) { error = vm.localizedError(e) }
                        loading = false
                    }
                }.padding(8.dp),
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(vm.t(I18nKey.supportedFormats), color = c.muted, fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(c.surface).padding(16.dp).fillMaxWidth())
    }
}

@Composable
fun M3uFileScreen(vm: AppViewModel, onBack: () -> Unit, onM3uUrl: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("My M3U Playlist") }
    var fileName by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var stats by remember { mutableStateOf<ParseStats?>(null) }
    var savedId by remember { mutableStateOf<String?>(null) }
    val c = LocalIptvColors.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            loading = true; error = null
            try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
                fileName = uri.lastPathSegment ?: "playlist.m3u"
                val (p, st) = withContext(Dispatchers.IO) {
                    vm.importM3uText(text, name.ifBlank { fileName }, PlaylistSource.FILE, fileName)
                }
                savedId = p.id; stats = st
            } catch (e: Exception) { error = vm.localizedError(e) }
            loading = false
        }
    }
    if (loading) { Screen { SpinnerBox() }; return }
    Screen {
        TopBar("M3U File", onBack)
        Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(80.dp).clip(RoundedCornerShape(24.dp)).background(c.surface), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Description, null, tint = c.primary, modifier = Modifier.size(36.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(vm.t(I18nKey.selectM3u), color = c.muted, fontSize = 14.sp)
        }
        Field(vm.t(I18nKey.playlistName)) { AppInput(name, { name = it }) }
        if (fileName.isNotEmpty()) Text(fileName, color = c.muted, fontSize = 14.sp)
        error?.let { Text(it, color = c.danger, fontSize = 14.sp) }
        stats?.let {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.card).padding(16.dp)) {
                Text(vm.t(I18nKey.loadedOk), color = c.success)
                Text("${it.channels} ${vm.t(I18nKey.channels)} · ${it.groups} ${vm.t(I18nKey.groups)}", color = c.muted, fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        PrimaryButton(vm.t(I18nKey.chooseFile), { picker.launch("*/*") })
        Spacer(Modifier.height(8.dp))
        Text(vm.t(I18nKey.or), color = c.subtle, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
        SecondaryButton(vm.t(I18nKey.enterM3uUrl), onM3uUrl)
        if (savedId != null) {
            Spacer(Modifier.height(8.dp))
            SecondaryButton(vm.t(I18nKey.open), { onOpen(savedId!!) })
        }
    }
}

@Composable
fun XtreamScreen(vm: AppViewModel, onBack: () -> Unit, onOpen: (String) -> Unit) {
    var name by remember { mutableStateOf("Xtream Codes") }
    var server by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<XtreamUserInfo?>(null) }
    var savedId by remember { mutableStateOf<String?>(null) }
    val c = LocalIptvColors.current
    val scope = rememberCoroutineScope()
    if (loading) { Screen { SpinnerBox() }; return }
    Screen {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            TopBar(vm.t(I18nKey.xtream), onBack)
            Field(vm.t(I18nKey.playlistName)) { AppInput(name, { name = it }) }
            Field(vm.t(I18nKey.serverUrl)) { AppInput(server, { server = it }, "http://example.com:8080") }
            Field(vm.t(I18nKey.username)) { AppInput(user, { user = it }) }
            Field(vm.t(I18nKey.password)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { AppInput(pass, { pass = it }) }
                    IconButton(onClick = { show = !show }) {
                        Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null, tint = c.muted)
                    }
                }
            }
            error?.let { Text(it, color = c.danger, fontSize = 14.sp) }
            info?.let { inf ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.card).padding(16.dp)) {
                    Text(vm.t(I18nKey.connected), color = c.success, fontWeight = FontWeight.Medium)
                    Text("${vm.t(I18nKey.username)}: ${inf.username}", color = c.fg, fontSize = 14.sp)
                    Text("${vm.t(I18nKey.status)}: ${inf.status ?: "—"}", color = c.fg, fontSize = 14.sp)
                    Text("${vm.t(I18nKey.expiration)}: ${Xtream.unixToIso(inf.expDate) ?: "—"}", color = c.fg, fontSize = 14.sp)
                    Text("${vm.t(I18nKey.connections)}: ${inf.activeCons ?: "0"} / ${inf.maxCons ?: "—"}", color = c.fg, fontSize = 14.sp)
                }
                Spacer(Modifier.height(12.dp))
            }
            PrimaryButton(
                if (info != null) vm.t(I18nKey.savePlaylist) else vm.t(I18nKey.connect),
                {
                    scope.launch {
                        loading = true; error = null
                        try {
                            val (p, inf) = withContext(Dispatchers.IO) { vm.connectXtream(name, server, user, pass) }
                            info = inf; savedId = p.id
                        } catch (e: Exception) { error = vm.localizedError(e) }
                        loading = false
                    }
                },
                enabled = server.isNotBlank() && user.isNotBlank() && pass.isNotEmpty(),
            )
            if (savedId != null) {
                Spacer(Modifier.height(12.dp))
                SecondaryButton(vm.t(I18nKey.open), { onOpen(savedId!!) })
            }
            Spacer(Modifier.height(12.dp))
            Text(vm.t(I18nKey.xtreamHint), color = c.muted, fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(c.surface).padding(16.dp))
        }
    }
}

@Composable
fun PlaylistsScreen(vm: AppViewModel, onBack: () -> Unit, onAdd: () -> Unit, onOpen: (String) -> Unit) {
    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    val scope = rememberCoroutineScope()
    var deleteId by remember { mutableStateOf<String?>(null) }
    var renameTarget by remember { mutableStateOf<Playlist?>(null) }
    var renameText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Screen {
        TopBar(vm.t(I18nKey.playlists), onBack)
        error?.let { Text(it, color = c.danger, fontSize = 14.sp) }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            state.playlists.forEach { p ->
                var menu by remember { mutableStateOf(false) }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.card).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.weight(1f).clickable { onOpen(p.id) }, verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(16.dp)).background(c.primary.copy(0.15f)), contentAlignment = Alignment.Center) {
                            Icon(if (p.type == PlaylistType.XTREAM) Icons.Filled.Cloud else Icons.Filled.Description, null, tint = c.primary)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(p.name, color = c.fg, fontWeight = FontWeight.SemiBold)
                            Text("${if (p.type == PlaylistType.XTREAM) "Xtream Codes" else "M3U"} · ${p.channelCount} ${vm.t(I18nKey.channels)}", color = c.muted, fontSize = 12.sp)
                        }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null, tint = c.muted) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text(vm.t(I18nKey.open)) }, { menu = false; onOpen(p.id) })
                            DropdownMenuItem({ Text(vm.t(I18nKey.refresh)) }, {
                                menu = false
                                scope.launch {
                                    try { withContext(Dispatchers.IO) { vm.refreshPlaylist(p) } }
                                    catch (e: Exception) { error = vm.localizedError(e) }
                                }
                            })
                            DropdownMenuItem({ Text(vm.t(I18nKey.rename)) }, { menu = false; renameTarget = p; renameText = p.name })
                            DropdownMenuItem({ Text(vm.t(I18nKey.delete)) }, { menu = false; deleteId = p.id })
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
        PrimaryButton(vm.t(I18nKey.addPlaylistTitle), onAdd)
    }
    if (deleteId != null) {
        AlertDialog(
            onDismissRequest = { deleteId = null },
            title = { Text(vm.t(I18nKey.deleteTitle)) },
            text = { Text(vm.t(I18nKey.deleteBody)) },
            confirmButton = { TextButton({ vm.removePlaylist(deleteId!!); deleteId = null }) { Text(vm.t(I18nKey.delete), color = c.danger) } },
            dismissButton = { TextButton({ deleteId = null }) { Text(vm.t(I18nKey.cancel)) } },
        )
    }
    if (renameTarget != null) {
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(vm.t(I18nKey.rename)) },
            text = { AppInput(renameText, { renameText = it }) },
            confirmButton = {
                TextButton({
                    if (renameText.isNotBlank()) vm.renamePlaylist(renameTarget!!.id, renameText.trim())
                    renameTarget = null
                }) { Text(vm.t(I18nKey.save)) }
            },
            dismissButton = { TextButton({ renameTarget = null }) { Text(vm.t(I18nKey.cancel)) } },
        )
    }
}

@Composable
fun PlaylistDetailScreen(vm: AppViewModel, id: String, onBack: () -> Unit, onLive: () -> Unit, onVod: () -> Unit, onSeries: () -> Unit, onEpg: () -> Unit) {
    val state by vm.state.collectAsState()
    val playlist = state.playlists.find { it.id == id }
    var counts by remember { mutableStateOf(Triple(0, 0, 0)) }
    val c = LocalIptvColors.current
    LaunchedEffect(id) {
        playlist?.let {
            vm.setActivePlaylist(it.id)
            val live = vm.repository.countChannels(it.id, ContentKind.LIVE)
            val movies = vm.repository.countChannels(it.id, ContentKind.MOVIE)
            val epCount = vm.repository.countChannels(it.id, ContentKind.SERIES)
            val showCount = vm.repository.loadSeries(it.id).size
            counts = Triple(live, movies, showCount.coerceAtLeast(epCount))
        }
    }
    if (playlist == null) {
        Screen { EmptyState(vm.t(I18nKey.noPlaylists)); PrimaryButton(vm.t(I18nKey.home), onBack) }
        return
    }
    val tiles = listOf(
        Triple(vm.t(I18nKey.liveTv), counts.first, Icons.Filled.Tv) to onLive,
        Triple(vm.t(I18nKey.movies), counts.second, Icons.Filled.Movie) to onVod,
        Triple(vm.t(I18nKey.series), counts.third, Icons.Filled.VideoLibrary) to onSeries,
        Triple(vm.t(I18nKey.epg), -1, Icons.Filled.LiveTv) to onEpg,
    ).filter { it.first.second != 0 }
    Screen {
        TopBar(playlist.name, onBack)
        Text("${if (playlist.type == PlaylistType.XTREAM) "Xtream Codes" else "M3U"} · ${playlist.channelCount} ${vm.t(I18nKey.channels)}", color = c.muted, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { (tile, action) ->
                    Column(
                        Modifier.weight(1f).padding(4.dp).clip(RoundedCornerShape(24.dp)).background(c.card).clickable(onClick = action).padding(16.dp),
                    ) {
                        Icon(tile.third, null, tint = c.primary)
                        Spacer(Modifier.height(16.dp))
                        Text(tile.first, color = c.fg, fontWeight = FontWeight.SemiBold)
                        if (tile.second >= 0) Text("${tile.second} ${tile.first}", color = c.muted, fontSize = 12.sp)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}


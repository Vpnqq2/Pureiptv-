package com.black.pureiptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.ui.components.Screen
import com.black.pureiptv.ui.components.TopBar
import com.black.pureiptv.ui.theme.LocalIptvColors

@Composable
fun PrivacyPolicyScreen(vm: AppViewModel, onBack: () -> Unit) {
    val c = LocalIptvColors.current
    Screen {
        Column(Modifier.fillMaxSize().background(c.bg)) {
            TopBar(vm.t(com.black.pureiptv.ui.i18n.I18nKey.privacyPolicy), onBack)
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)
            ) {
                Text(
                    "Privacy Policy",
                    color = c.fg,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(16.dp))
                
                Text(
                    "Last Updated: September 24, 2026",
                    color = c.muted,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(24.dp))
                
                PolicySection("1. Information Collection", """
                    This IPTV Player application is a media player that allows you to play your own IPTV playlists. We collect the following information:
                    
                    • App usage data and preferences
                    • Playlist information stored locally on your device
                    • Watch history and favorites (stored locally)
                    • Device information for app functionality
                    
                    We do not collect or transmit any content from your playlists to our servers.
                """.trimIndent())
                
                PolicySection("2. Use of Information", """
                    The information we collect is used to:
                    
                    • Provide and improve the app functionality
                    • Remember your preferences and settings
                    • Save your playlists locally
                    • Display relevant content and improve user experience
                    
                    We do not sell, rent, or share your personal information with third parties for their marketing purposes.
                """.trimIndent())
                
                PolicySection("3. Advertising", """
                    This app uses Google AdMob to display advertisements. Google may use cookies to serve ads based on your prior visits to this website or other websites.
                    
                    • AdMob may collect anonymous usage data
                    • AdMob may use device identifiers for ad targeting
                    • You can opt out of personalized ads in your device settings
                    
                    The ads displayed in this app comply with Google's advertising policies and are not related to the content of your playlists.
                """.trimIndent())
                
                PolicySection("4. Data Storage", """
                    Your data is stored locally on your device:
                    
                    • Playlists are stored in app storage
                    • Favorites and watch history are stored locally
                    • Settings and preferences are stored locally
                    
                    We do not have access to your playlists or viewing habits. You remain in full control of your content.
                """.trimIndent())
                
                PolicySection("5. Third-Party Services", """
                    This app uses the following third-party services:
                    
                    • Google AdMob for advertising
                    • Google Play Services for app functionality
                    • OkHttp for network requests
                    
                    Each service has its own privacy policy which we encourage you to review.
                """.trimIndent())
                
                PolicySection("6. Data Security", """
                    We implement reasonable security measures to protect your information:
                    
                    • Local data encryption for sensitive information
                    • Secure network connections
                    • Regular security updates
                    
                    However, no method of transmission over the internet is 100% secure.
                """.trimIndent())
                
                PolicySection("7. Children's Privacy", """
                    This app is not directed to children under 13. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us.
                """.trimIndent())
                
                PolicySection("8. Your Rights", """
                    You have the right to:
                    
                    • Access your data stored in the app
                    • Delete your playlists and watch history
                    • Opt out of personalized advertising
                    • Uninstall the app to remove all data
                    
                    These rights can be exercised through the app settings or device settings.
                """.trimIndent())
                
                PolicySection("9. Changes to This Policy", """
                    We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page and updating the "Last Updated" date.
                    
                    You are advised to review this privacy policy periodically for any changes.
                """.trimIndent())
                
                PolicySection("10. Contact Us", """
                    If you have any questions about this privacy policy, please contact us at:
                    
                    • Email: support@pureiptv.app
                    • Through the app's settings
                    
                    We will respond to your inquiries within a reasonable timeframe.
                """.trimIndent())
                
                Spacer(Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun PolicySection(title: String, content: String) {
    val c = LocalIptvColors.current
    Text(
        title,
        color = c.fg,
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(vertical = 8.dp)
    )
    Text(
        content,
        color = c.muted,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
    Spacer(Modifier.height(16.dp))
}
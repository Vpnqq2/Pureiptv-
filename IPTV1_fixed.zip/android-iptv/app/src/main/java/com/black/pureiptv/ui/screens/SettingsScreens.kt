package com.black.pureiptv.ui.screens

import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import com.black.pureiptv.ads.BannerAdView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.R
import com.black.pureiptv.data.model.AccentId
import com.black.pureiptv.data.model.QualityPref
import com.black.pureiptv.data.model.ThemeMode
import com.black.pureiptv.ui.components.AppLogo
import com.black.pureiptv.ui.components.AppSwitch
import com.black.pureiptv.ui.components.PrimaryButton
import com.black.pureiptv.ui.components.Screen
import com.black.pureiptv.ui.components.TopBar
import com.black.pureiptv.ui.i18n.I18nKey
import com.black.pureiptv.ui.i18n.LANG_LABELS
import com.black.pureiptv.ui.theme.LocalIptvColors
import com.black.pureiptv.ui.theme.accentColor

@Composable
fun SettingsHomeScreen(
    vm: AppViewModel,
    onLanguage: () -> Unit,
    onPlayer: () -> Unit,
    onAppearance: () -> Unit,
    onAbout: () -> Unit,
    onPrivacy: () -> Unit = {},
    onTerms: () -> Unit = {},
    onOpenDrawer: () -> Unit = {},
) {
    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    val scrollState = rememberScrollState()
    val langLabel = LANG_LABELS.find { it.id == state.settings.language }?.label ?: "English"
    Column(
        Modifier
            .fillMaxSize()
            .background(c.bg)
            .statusBarsPadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp)
    ) {
        // Top bar with menu icon
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                vm.t(I18nKey.settings), 
                color = c.fg, 
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onOpenDrawer) { 
                Icon(Icons.Filled.Menu, null, tint = c.fg) 
            }
        }
        Text(vm.t(I18nKey.general), color = c.subtle, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp))) {
            SettingRow(Icons.Filled.Language, vm.t(I18nKey.appLanguage), langLabel, onLanguage)
            SettingRow(Icons.Filled.PlayCircle, vm.t(I18nKey.videoPlayer), "Media3", onPlayer)
            SettingRow(Icons.Filled.Palette, vm.t(I18nKey.cacheSize), "512 MB", null)
        }
        Spacer(Modifier.height(20.dp))
        Text(vm.t(I18nKey.playlists), color = c.subtle, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp))) {
            SwitchRow(vm.t(I18nKey.autoLoadLast), state.settings.autoLoadLast) { vm.patchSettings { copy(autoLoadLast = it) } }
            SwitchRow(vm.t(I18nKey.keepEpg), state.settings.keepEpg) { vm.patchSettings { copy(keepEpg = it) } }
        }
        Spacer(Modifier.height(20.dp))
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp))) {
            SettingRow(Icons.Filled.Palette, vm.t(I18nKey.appearance), null, onAppearance)
            SettingRow(Icons.Filled.Info, vm.t(I18nKey.about), null, onAbout)
            SettingRow(Icons.Filled.Security, vm.t(I18nKey.privacyPolicy), null, onPrivacy)
            SettingRow(Icons.Filled.Description, vm.t(I18nKey.termsOfService), null, onTerms)
        }
        Spacer(Modifier.height(16.dp))
        // Banner Ad at the bottom of settings screen
        BannerAdView(
            adsEnabled = state.settings.adsEnabled,
            adsFreeUntil = state.settings.adsFreeUntil
        )
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun SettingRow(icon: ImageVector, label: String, value: String?, onClick: (() -> Unit)?) {
    val c = LocalIptvColors.current
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(c.surface2), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = c.primary, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.size(12.dp))
        Text(label, color = c.fg, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        if (value != null) Text(value, color = c.muted, fontSize = 14.sp)
        if (onClick != null) {
            Spacer(Modifier.size(4.dp))
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = c.subtle, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalIptvColors.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = c.fg, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        AppSwitch(checked, onChange)
    }
}

@Composable
fun AppearanceScreen(vm: AppViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    val themes = listOf(ThemeMode.DARK to I18nKey.dark, ThemeMode.LIGHT to I18nKey.light, ThemeMode.SYSTEM to I18nKey.system)
    Screen {
        TopBar(vm.t(I18nKey.appearance), onBack)
        Text(vm.t(I18nKey.theme), color = c.muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp))) {
            themes.forEach { (id, key) ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.patchSettings { copy(theme = id) } }.padding(horizontal = 16.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(vm.t(key), color = c.fg, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    Box(
                        Modifier.size(20.dp).clip(CircleShape)
                            .border(2.dp, if (state.settings.theme == id) c.primary else c.borderStrong, CircleShape)
                            .background(if (state.settings.theme == id) c.primary else Color.Transparent),
                    )
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(vm.t(I18nKey.accent), color = c.muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
        Row {
            AccentId.entries.forEach { a ->
                val col = accentColor(a).first
                Box(
                    Modifier.padding(end = 12.dp).size(44.dp).clip(CircleShape)
                        .border(2.dp, if (state.settings.accent == a) c.fg else Color.Transparent, CircleShape)
                        .background(col)
                        .clickable { vm.patchSettings { copy(accent = a) } },
                )
            }
        }
    }
}

@Composable
fun LanguageScreen(vm: AppViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    var selected by remember { mutableStateOf(state.settings.language) }
    val c = LocalIptvColors.current
    Screen {
        TopBar(vm.t(I18nKey.language), onBack)
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp))) {
            LANG_LABELS.forEach { item ->
                Row(
                    Modifier.fillMaxWidth().clickable { selected = item.id }.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(32.dp).clip(CircleShape).background(c.surface2), contentAlignment = Alignment.Center) {
                        Text(item.flag, color = c.muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.size(12.dp))
                    Text(item.label, color = c.fg, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    Box(
                        Modifier.size(20.dp).clip(CircleShape)
                            .border(2.dp, if (selected == item.id) c.primary else c.borderStrong, CircleShape)
                            .background(if (selected == item.id) c.primary else Color.Transparent),
                    )
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        PrimaryButton(vm.t(I18nKey.save), { vm.patchSettings { copy(language = selected) } })
    }
}

@Composable
fun PlayerSettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    val qualities = listOf(QualityPref.AUTO, QualityPref.Q1080, QualityPref.Q720, QualityPref.Q480)
    Screen {
        TopBar(vm.t(I18nKey.videoSettings), onBack)
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp)).padding(vertical = 8.dp)) {
            Text(vm.t(I18nKey.quality), color = c.fg, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            qualities.forEach { q ->
                val label = if (q == QualityPref.AUTO) "${vm.t(I18nKey.auto)} (720p)" else q.name.removePrefix("Q")
                Row(
                    Modifier.fillMaxWidth().clickable { vm.patchSettings { copy(defaultQuality = q) } }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(label, color = c.fg, modifier = Modifier.weight(1f))
                    if (state.settings.defaultQuality == q) Text("●", color = c.primary)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp))) {
            SwitchRow(vm.t(I18nKey.autoPlay), state.settings.autoPlay) { vm.patchSettings { copy(autoPlay = it) } }
            SwitchRow(vm.t(I18nKey.pictureInPicture), state.settings.enablePictureInPicture) { vm.patchSettings { copy(enablePictureInPicture = it) } }
        }
    }
}

@Composable
fun AboutScreen(vm: AppViewModel, onBack: () -> Unit, onPrivacy: () -> Unit = {}, onTerms: () -> Unit = {}) {
    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    val scrollState = rememberScrollState()
    Screen(Modifier.verticalScroll(scrollState)) {
        TopBar(vm.t(I18nKey.about), onBack)
        Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.lo_go),
                contentDescription = null,
                modifier = Modifier.size(72.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(16.dp))
            Text("pureiptv", color = c.fg, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Text("${vm.t(I18nKey.version)} 1.0.0", color = c.muted, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            Text(vm.t(I18nKey.aboutBody), color = c.muted, fontSize = 14.sp)
        }
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp)).clickable(onClick = onPrivacy).padding(16.dp)) {
            Text(vm.t(I18nKey.privacyPolicy), color = c.fg, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(vm.t(I18nKey.privacyBody), color = c.muted, fontSize = 14.sp)
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp)).clickable(onClick = onTerms).padding(16.dp)) {
            Text(vm.t(I18nKey.termsOfService), color = c.fg, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(vm.t(I18nKey.termsBody), color = c.muted, fontSize = 14.sp)
        }
        Spacer(Modifier.height(16.dp))
        // Banner Ad at the bottom of about screen
        BannerAdView(
            adsEnabled = state.settings.adsEnabled,
            adsFreeUntil = state.settings.adsFreeUntil
        )
        Spacer(Modifier.height(32.dp))
    }
}


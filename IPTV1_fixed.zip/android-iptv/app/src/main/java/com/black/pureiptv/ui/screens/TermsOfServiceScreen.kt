package com.black.pureiptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.ui.components.Screen
import com.black.pureiptv.ui.components.TopBar
import com.black.pureiptv.ui.theme.LocalIptvColors

@Composable
fun TermsOfServiceScreen(vm: AppViewModel, onBack: () -> Unit) {
    val c = LocalIptvColors.current
    Screen {
        Column(Modifier.fillMaxSize().background(c.bg)) {
            TopBar(vm.t(com.black.pureiptv.ui.i18n.I18nKey.termsOfService), onBack)
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)
            ) {
                Text(
                    "Terms of Service",
                    color = c.fg,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(16.dp))
                
                Text(
                    "Last Updated: September 24, 2026",
                    color = c.muted,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(24.dp))
                
                PolicySection("1. Acceptance of Terms", """
                    By downloading, installing, or using this IPTV Player application, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use this application.
                """.trimIndent())
                
                PolicySection("2. Nature of the Application", """
                    This application is a media player that allows users to play their own IPTV playlists. It is important to understand:
                    
                    • This app is a PLAYER ONLY - it does not provide any content
                    • Users must add their own playlists from legal sources
                    • The app does not host, stream, or distribute any video content
                    • Users are solely responsible for the content they choose to play
                """.trimIndent())
                
                PolicySection("3. User Responsibilities", """
                    As a user of this application, you agree to:
                    
                    • Only add playlists that you have the legal right to use
                    • Comply with all applicable laws and regulations
                    • Respect copyright and intellectual property rights
                    • Not use this application for any illegal purposes
                    • Accept full responsibility for your playlist content
                """.trimIndent())
                
                PolicySection("4. Content and Copyright", """
                    • This application does not provide any channels, movies, or series
                    • All content is provided by users through their own playlists
                    • We do not control, endorse, or verify user-added content
                    • Users must ensure they have proper rights to access any content
                    • We are not responsible for copyright infringement by users
                """.trimIndent())
                
                PolicySection("5. No Warranty", """
                    This application is provided "as is" without any warranties, express or implied. We do not guarantee:
                    
                    • Uninterrupted or error-free operation
                    • Compatibility with all playlist formats
                    • Quality or availability of user-added content
                    • Security of data stored on your device
                """.trimIndent())
                
                PolicySection("6. Limitation of Liability", """
                    In no event shall we be liable for any damages arising from the use of this application, including but not limited to:
                    
                    • Direct, indirect, incidental, or consequential damages
                    • Loss of data or playlists
                    • Legal issues related to user content
                    • Device malfunctions or data loss
                """.trimIndent())
                
                PolicySection("7. Privacy and Data", """
                    • Your playlists and viewing data are stored locally on your device
                    • We do not have access to your playlists or viewing habits
                    • Some data may be collected for app functionality and advertising
                    • Please refer to our Privacy Policy for detailed information
                """.trimIndent())
                
                PolicySection("8. Advertisements", """
                    • This application may display advertisements
                    • Advertisements are provided by third-party services (e.g., Google AdMob)
                    • We are not responsible for the content of advertisements
                    • Advertisements are not related to the content of your playlists
                """.trimIndent())
                
                PolicySection("9. Termination", """
                    We reserve the right to:
                    
                    • Terminate or suspend access to this application
                    • Modify these terms at any time
                    • Discontinue the application with or without notice
                    • Remove features or functionality
                """.trimIndent())
                
                PolicySection("10. Updates and Modifications", """
                    We may update this application and these terms from time to time. Continued use of the application after changes constitutes acceptance of the modified terms.
                """.trimIndent())
                
                PolicySection("11. Governing Law", """
                    These terms shall be governed by and construed in accordance with applicable laws. Any disputes arising from these terms shall be subject to the jurisdiction of the relevant courts.
                """.trimIndent())
                
                PolicySection("12. Contact Information", """
                    If you have any questions about these Terms of Service, please contact us at:
                    
                    • Email: support@pureiptv.app
                    • Through the app's settings
                    
                    We will respond to your inquiries within a reasonable timeframe.
                """.trimIndent())
                
                Spacer(Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun PolicySection(title: String, content: String) {
    val c = LocalIptvColors.current
    Text(
        title,
        color = c.fg,
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(vertical = 8.dp)
    )
    Text(
        content,
        color = c.muted,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
    Spacer(Modifier.height(16.dp))
}
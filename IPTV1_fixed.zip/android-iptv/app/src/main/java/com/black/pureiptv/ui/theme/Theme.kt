package com.black.pureiptv.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.black.pureiptv.data.model.AccentId
import com.black.pureiptv.data.model.ThemeMode

data class IptvColors(
    val bg: Color,
    val bgElevated: Color,
    val surface: Color,
    val surface2: Color,
    val card: Color,
    val fg: Color,
    val muted: Color,
    val subtle: Color,
    val primary: Color,
    val primaryFg: Color,
    val primaryPress: Color,
    val border: Color,
    val borderStrong: Color,
    val success: Color,
    val danger: Color,
    val warn: Color,
    val live: Color,
)

val LocalIptvColors = staticCompositionLocalOf {
    darkPalette(AccentId.BLUE)
}

fun accentColor(id: AccentId): Pair<Color, Color> = when (id) {
    AccentId.BLUE -> Color(0xFF2F6BFF) to Color(0xFF1E56E6)
    AccentId.TEAL -> Color(0xFF14B8A6) to Color(0xFF0D9488)
    AccentId.GREEN -> Color(0xFF22C55E) to Color(0xFF16A34A)
    AccentId.AMBER -> Color(0xFFFF9F1C) to Color(0xFFE88A00)
}

fun darkPalette(accent: AccentId): IptvColors {
    val (p, press) = accentColor(accent)
    return IptvColors(
        bg = Color(0xFF070B16),
        bgElevated = Color(0xFF0C1324),
        surface = Color(0xFF121A2E),
        surface2 = Color(0xFF18233C),
        card = Color(0xFF141D32),
        fg = Color(0xFFF3F6FF),
        muted = Color(0xFF8B97B8),
        subtle = Color(0xFF5D6B8A),
        primary = p,
        primaryFg = Color.White,
        primaryPress = press,
        border = Color(0xFF1E2A45),
        borderStrong = Color(0xFF2A3B60),
        success = Color(0xFF22C55E),
        danger = Color(0xFFEF4444),
        warn = p,
        live = Color(0xFFFF3B5C),
    )
}

fun lightPalette(accent: AccentId): IptvColors {
    val (p, press) = accentColor(accent)
    return IptvColors(
        bg = Color(0xFFF3F5FB),
        bgElevated = Color.White,
        surface = Color.White,
        surface2 = Color(0xFFEEF1F8),
        card = Color.White,
        fg = Color(0xFF0E1528),
        muted = Color(0xFF5B6784),
        subtle = Color(0xFF7B86A1),
        primary = p,
        primaryFg = Color.White,
        primaryPress = press,
        border = Color(0xFFD8DEEC),
        borderStrong = Color(0xFFC3CCDF),
        success = Color(0xFF22C55E),
        danger = Color(0xFFEF4444),
        warn = p,
        live = Color(0xFFFF3B5C),
    )
}

val RadiusXl = 24.dp
val RadiusLg = 18.dp
val RadiusMd = 14.dp

@Composable
fun IptvTheme(mode: ThemeMode, accent: AccentId, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val colors = if (dark) darkPalette(accent) else lightPalette(accent)
    val scheme = if (dark) {
        darkColorScheme(
            primary = colors.primary,
            onPrimary = colors.primaryFg,
            background = colors.bg,
            onBackground = colors.fg,
            surface = colors.surface,
            onSurface = colors.fg,
            error = colors.danger,
        )
    } else {
        lightColorScheme(
            primary = colors.primary,
            onPrimary = colors.primaryFg,
            background = colors.bg,
            onBackground = colors.fg,
            surface = colors.surface,
            onSurface = colors.fg,
            error = colors.danger,
        )
    }
    CompositionLocalProvider(LocalIptvColors provides colors) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}


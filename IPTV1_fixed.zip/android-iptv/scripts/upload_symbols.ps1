# PowerShell script to generate and upload ProGuard mapping file for Crashlytics
# This script helps you fix the "No deobfuscation file" warning

Write-Host "=== ProGuard Mapping File Generator ===" -ForegroundColor Green
Write-Host ""
Write-Host "This script will:"
Write-Host "1. Build the release APK/App Bundle"
Write-Host "2. Extract the mapping.txt file"
Write-Host "3. Upload it to Firebase Crashlytics"
Write-Host ""

# Check if we're in the project root
if (-not (Test-Path "gradlew.bat")) {
    Write-Host "Error: Please run this script from the project root directory" -ForegroundColor Red
    exit 1
}

# Build release bundle
Write-Host "Building release App Bundle..." -ForegroundColor Yellow
& .\gradlew.bat bundleRelease

# The mapping file will be generated at:
# app/build/outputs/mapping/release/mapping.txt

Write-Host ""
Write-Host "=== Build Complete ===" -ForegroundColor Green
Write-Host "Mapping file location: app\build\outputs\mapping\release\mapping.txt"
Write-Host ""
Write-Host "To upload to Firebase Crashlytics:"
Write-Host "1. Go to Firebase Console > Your Project > Crashlytics"
Write-Host "2. Upload the mapping.txt file from the location above"
Write-Host ""
Write-Host "Or use Firebase CLI to upload automatically:"
Write-Host "firebase crashlytics:symbols:upload --app=your-app-id app\build\outputs\mapping\release"
#!/bin/bash

# Script to generate and upload ProGuard mapping file for Crashlytics
# This script helps you fix the "No deobfuscation file" warning

echo "=== ProGuard Mapping File Generator ==="
echo ""
echo "This script will:"
echo "1. Build the release APK/App Bundle"
echo "2. Extract the mapping.txt file"
echo "3. Upload it to Firebase Crashlytics"
echo ""

# Check if we're in the project root
if [ ! -f "gradlew" ]; then
    echo "Error: Please run this script from the project root directory"
    exit 1
fi

# Build release bundle
echo "Building release App Bundle..."
./gradlew bundleRelease

# The mapping file will be generated at:
# app/build/outputs/mapping/release/mapping.txt

echo ""
echo "=== Build Complete ==="
echo "Mapping file location: app/build/outputs/mapping/release/mapping.txt"
echo ""
echo "To upload to Firebase Crashlytics:"
echo "1. Go to Firebase Console > Your Project > Crashlytics"
echo "2. Upload the mapping.txt file from the location above"
echo ""
echo "Or use Firebase CLI to upload automatically:"
echo "firebase crashlytics:symbols:upload --app=your-app-id app/build/outputs/mapping/release"
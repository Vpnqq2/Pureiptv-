package com.black.pureiptv

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.black.pureiptv.data.model.ContentKind
import com.black.pureiptv.data.model.Favorite
import com.black.pureiptv.data.model.ParseStats
import com.black.pureiptv.data.model.PersistedState
import com.black.pureiptv.data.model.Playlist
import com.black.pureiptv.data.model.PlaylistSource
import com.black.pureiptv.data.model.Settings
import com.black.pureiptv.data.model.WatchHistory
import com.black.pureiptv.data.model.XtreamUserInfo
import com.black.pureiptv.data.parser.IptvException
import com.black.pureiptv.data.repo.IptvRepository
import com.black.pureiptv.data.repo.errorMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as IptvApp).repository

    private val _state = MutableStateFlow(PersistedState())
    val state: StateFlow<PersistedState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repo.state.collect { _state.value = it }
        }
    }

    fun t(key: com.black.pureiptv.ui.i18n.I18nKey) =
        com.black.pureiptv.ui.i18n.t(_state.value.settings.language, key)

    private fun persist(transform: (PersistedState) -> PersistedState) {
        val next = transform(_state.value)
        _state.value = next
        viewModelScope.launch { repo.saveState(next) }
    }

    fun upsertPlaylist(p: Playlist) = persist { s ->
        val idx = s.playlists.indexOfFirst { it.id == p.id }
        val list = if (idx >= 0) s.playlists.map { if (it.id == p.id) p else it } else listOf(p) + s.playlists
        s.copy(playlists = list, activePlaylistId = p.id, settings = s.settings.copy(lastPlaylistId = p.id))
    }

    fun removePlaylist(id: String) {
        viewModelScope.launch { repo.deletePlaylistMedia(id) }
        persist { s ->
            val remaining = s.playlists.filter { it.id != id }
            s.copy(
                playlists = remaining,
                favorites = s.favorites.filter { it.playlistId != id },
                history = s.history.filter { it.playlistId != id },
                activePlaylistId = if (s.activePlaylistId == id) remaining.firstOrNull()?.id else s.activePlaylistId,
            )
        }
    }

    fun setActivePlaylist(id: String?) = persist { s ->
        s.copy(activePlaylistId = id, settings = s.settings.copy(lastPlaylistId = id ?: s.settings.lastPlaylistId))
    }

    fun toggleFavorite(fav: Favorite) = persist { s ->
        val exists = s.favorites.any { it.id == fav.id }
        s.copy(favorites = if (exists) s.favorites.filter { it.id != fav.id } else listOf(fav.copy(addedAt = System.currentTimeMillis())) + s.favorites)
    }

    fun isFavorite(id: String) = _state.value.favorites.any { it.id == id }

    fun addHistory(item: WatchHistory) = persist { s ->
        val rest = s.history.filter { it.channelId != item.channelId }
        s.copy(
            history = (listOf(item.copy(watchedAt = System.currentTimeMillis())) + rest).take(80),
            settings = s.settings.copy(lastChannelId = item.channelId),
        )
    }

    fun clearHistory() = persist { it.copy(history = emptyList()) }
    fun patchSettings(patch: Settings.() -> Settings) = persist { it.copy(settings = it.settings.patch()) }
    fun completeOnboarding() = persist { it.copy(settings = it.settings.copy(onboardingDone = true)) }
    fun addSearch(q: String) = persist { s ->
        val query = q.trim()
        if (query.isEmpty()) s
        else s.copy(recentSearches = (listOf(query) + s.recentSearches.filter { it != query }).take(8))
    }
    fun renamePlaylist(id: String, name: String) = persist { s ->
        s.copy(playlists = s.playlists.map { if (it.id == id) it.copy(name = name, updatedAt = System.currentTimeMillis()) else it })
    }

    val repository get() = repo

    suspend fun importM3uText(content: String, name: String, source: PlaylistSource, fileName: String? = null): Pair<Playlist, ParseStats> {
        val result = repo.importM3uText(content, name, source, fileName = fileName)
        upsertPlaylist(result.first)
        return result
    }

    suspend fun importM3uUrl(url: String, name: String): Pair<Playlist, ParseStats> {
        val result = repo.importM3uUrl(url, name)
        upsertPlaylist(result.first)
        return result
    }

    suspend fun connectXtream(name: String, server: String, user: String, pass: String): Pair<Playlist, XtreamUserInfo> {
        val result = repo.connectXtream(name, server, user, pass)
        upsertPlaylist(result.first)
        return result
    }

    suspend fun refreshPlaylist(p: Playlist) {
        val next = repo.refresh(p)
        upsertPlaylist(next)
    }

    fun localizedError(t: Throwable): String {
        val code = (t as? IptvException)?.code ?: "LOAD_FAILED"
        return errorMessage(code, _state.value.settings.language)
    }

    fun activePlaylist(): Playlist? {
        val s = _state.value
        val id = s.activePlaylistId ?: s.settings.lastPlaylistId
        return s.playlists.find { it.id == id } ?: s.playlists.firstOrNull()
    }

    fun makeFavorite(id: String, playlistId: String, kind: ContentKind, name: String, logo: String?, group: String?) =
        Favorite(id, playlistId, kind, name, logo, group, System.currentTimeMillis())
}


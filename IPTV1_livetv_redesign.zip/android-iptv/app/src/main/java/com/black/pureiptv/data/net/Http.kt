package com.black.pureiptv.data.net

import com.black.pureiptv.data.parser.IptvException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetAddress
import java.net.URI
import java.util.concurrent.TimeUnit

object Http {
    val json = Json { ignoreUnknownKeys = true; isLenient = true }
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(28, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun getText(url: String, maxBytes: Long = 25L * 1024 * 1024): String {
        assertSafeUrl(url)
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "IPTVPlayer/1.0")
            .header("Accept", "*/*")
            .build()
        client.newCall(req).execute().use { res ->
            val body = res.body?.bytes() ?: ByteArray(0)
            if (body.size > maxBytes) throw IptvException("TOO_LARGE")
            val text = body.toString(Charsets.UTF_8)
            if (!res.isSuccessful) throw IptvException("HTTP_${res.code}")
            return text
        }
    }

    fun getJson(url: String): JsonElement {
        val text = getText(url)
        return runCatching { json.parseToJsonElement(text) }.getOrElse { throw IptvException("INVALID_JSON") }
    }

    fun assertSafeUrl(raw: String) {
        val uri = runCatching { URI(raw) }.getOrElse { throw IptvException("INVALID_URL") }
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") throw IptvException("INVALID_URL")
        val host = (uri.host ?: "").lowercase().removePrefix("[").removeSuffix("]")
        if (host in setOf("localhost", "127.0.0.1", "0.0.0.0", "::1") ||
            host.endsWith(".local") || host.endsWith(".internal") || host.endsWith(".localhost")
        ) throw IptvException("BLOCKED_HOST")
        if (isPrivateIpv4(host)) throw IptvException("BLOCKED_HOST")
        runCatching {
            InetAddress.getAllByName(host).forEach { addr ->
                if (addr.isLoopbackAddress || addr.isSiteLocalAddress || addr.isAnyLocalAddress || addr.isLinkLocalAddress) {
                    throw IptvException("BLOCKED_HOST")
                }
            }
        }
    }

    private fun isPrivateIpv4(host: String): Boolean {
        val p = host.split('.').mapNotNull { it.toIntOrNull() }
        if (p.size != 4) return false
        val (a, b) = p
        return a == 10 || a == 127 || a == 0 ||
            (a == 169 && b == 254) ||
            (a == 172 && b in 16..31) ||
            (a == 192 && b == 168) ||
            (a == 100 && b in 64..127)
    }
}


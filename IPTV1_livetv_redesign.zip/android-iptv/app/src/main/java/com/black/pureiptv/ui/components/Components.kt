package com.black.pureiptv.ui.components

import androidx.compose.ui.text.style.TextAlign
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.material.icons.filled.Search
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LiveTv
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.ui.i18n.I18nKey
import com.black.pureiptv.ui.theme.LocalIptvColors
import com.black.pureiptv.ui.theme.RadiusLg
import com.black.pureiptv.ui.theme.RadiusXl

@Composable
fun Screen(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalIptvColors.current
    Column(
        modifier
            .fillMaxSize()
            .background(c.bg)
            .statusBarsPadding()
            .padding(horizontal = 20.dp),
        content = content,
    )
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null, right: @Composable (() -> Unit)? = null) {
    val c = LocalIptvColors.current
    Row(
        Modifier.fillMaxWidth().padding(bottom = 16.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(c.surface)
                    .border(BorderStroke(1.dp, c.border), CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.fg, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
        }
        Text(title, color = c.fg, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        right?.invoke()
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val c = LocalIptvColors.current
    Box(
        modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) c.primary else c.primary.copy(alpha = 0.4f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = c.primaryFg, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalIptvColors.current
    Box(
        modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.matchParentSize().clip(RoundedCornerShape(16.dp)).background(c.borderStrong.copy(alpha = 0.4f)))
        Text(text, color = c.fg, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun AppInput(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String = "",
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null,
) {
    val c = LocalIptvColors.current
    val shape = RoundedCornerShape(20.dp)
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier
            .fillMaxWidth()
            .height(58.dp)
            .clip(shape)
            .background(c.surface)
            .border(BorderStroke(if (focused) 2.dp else 1.dp, if (focused) c.primary else c.borderStrong), shape)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leadingIcon != null) {
            Icon(leadingIcon, null, tint = if (focused) c.primary else c.muted, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
        }
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (value.isEmpty() && placeholder.isNotEmpty()) {
                Text(placeholder, color = c.muted, fontSize = 16.sp)
            }
            BasicTextField(
                value = value,
                onValueChange = onChange,
                textStyle = TextStyle(color = c.fg, fontSize = 16.sp),
                cursorBrush = SolidColor(c.primary),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused },
            )
        }
        if (value.isNotEmpty()) {
            Box(
                Modifier.size(28.dp).clip(CircleShape).background(c.surface2).clickable { onChange("") },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Close, null, tint = c.muted, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun Field(label: String, content: @Composable () -> Unit) {
    val c = LocalIptvColors.current
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
        Text(label, color = c.muted, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(bottom = 8.dp))
        content()
    }
}

@Composable
fun AppSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalIptvColors.current
    Box(
        Modifier
            .width(48.dp)
            .height(28.dp)
            .clip(CircleShape)
            .background(if (checked) c.primary else c.borderStrong)
            .clickable { onChange(!checked) },
    ) {
        Box(
            Modifier
                .padding(2.dp)
                .size(24.dp)
                .align(if (checked) Alignment.CenterEnd else Alignment.CenterStart)
                .clip(CircleShape)
                .background(Color.White),
        )
    }
}

@Composable
fun EmptyState(title: String, body: String? = null, icon: ImageVector = Icons.Filled.PlayArrow) {
    val c = LocalIptvColors.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(72.dp).clip(RoundedCornerShape(24.dp)).background(c.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = c.primary, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text(title, color = c.fg, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        if (body != null) {
            Spacer(Modifier.height(8.dp))
            Text(body, color = c.muted, fontSize = 14.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun SpinnerBox() {
    val c = LocalIptvColors.current
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = c.primary)
    }
}

@Composable
fun AppLogo(size: Dp = 56.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.28f)).background(Color(0xFF2F6BFF)), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun ChannelLogo(name: String, src: String?, size: Dp = 44.dp) {
    val c = LocalIptvColors.current
    var failed by remember(src) { mutableStateOf(false) }
    val hasLogo = !src.isNullOrBlank() && !failed
    val isPoster = size >= 80.dp // الملصقات الكبيرة تُقصّ لتملأ المساحة، أما الشعارات الصغيرة فتُعرض كاملة
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.26f))
            .background(if (hasLogo) c.surface2 else logoColor(name)),
        contentAlignment = Alignment.Center,
    ) {
        if (hasLogo) {
            AsyncImage(
                model = src,
                contentDescription = null,
                onError = { failed = true },
                modifier = Modifier.fillMaxSize().then(if (isPoster) Modifier else Modifier.padding(size * 0.1f)),
                contentScale = if (isPoster) ContentScale.Crop else ContentScale.Fit,
            )
        } else {
            Text(initialsOf(name), color = Color.White, fontSize = (size.value * 0.3f).sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** يفصل الجودة مثل (1080p) أو (HD) عن اسم القناة: "1+1 Ukraina (1080p)" -> ("1+1 Ukraina", "1080p") */
fun splitQuality(name: String): Pair<String, String?> {
    val m = Regex("""\s*[\(\[]\s*((?:\d{3,4}\s*[pi])|4K|UHD|FHD|HD|SD)\s*[\)\]]\s*$""", RegexOption.IGNORE_CASE).find(name)
        ?: return name to null
    return name.removeRange(m.range).trim() to m.groupValues[1].uppercase().replace(" ", "")
}

@Composable
fun QualityPill(text: String) {
    val c = LocalIptvColors.current
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(c.primary.copy(alpha = 0.16f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
        Text(text, color = c.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun ChannelRow(channel: Channel, favorite: Boolean, onOpen: () -> Unit, onToggleFavorite: () -> Unit, showNumber: Boolean = true) {
    val c = LocalIptvColors.current
    val shape = RoundedCornerShape(22.dp)
    val (title, quality) = remember(channel.name) { splitQuality(channel.name) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(shape)
            .background(c.card)
            .border(BorderStroke(1.dp, c.border), shape)
            .clickable(onClick = onOpen)
            .padding(start = 14.dp, top = 14.dp, bottom = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // الشعار في مربع مستقل
        Box(
            Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(c.surface2)
                .border(BorderStroke(1.dp, c.border), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center,
        ) {
            ChannelLogo(channel.name, channel.logo ?: channel.poster, 56.dp)
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // اسم القناة بارز
            Text(
                title,
                color = c.fg,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                lineHeight = 22.sp,
                overflow = TextOverflow.Ellipsis,
            )
            // الرقم + الجودة + التصنيف في سطر ثانوي منفصل
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (showNumber && channel.number > 0) {
                    Text(channel.number.toString().padStart(3, '0'), color = c.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                if (quality != null) QualityPill(quality)
                Text(
                    channel.group,
                    color = c.muted,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
            }
        }
        IconButton(onClick = onToggleFavorite) {
            Icon(
                if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = null,
                tint = if (favorite) c.primary else c.subtle,
                modifier = Modifier.size(26.dp),
            )
        }
    }
}

@Composable
fun CardButton(icon: ImageVector, title: String, description: String, onClick: () -> Unit) {
    val c = LocalIptvColors.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(c.primary.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = c.primary)
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, color = c.fg, fontWeight = FontWeight.SemiBold)
            Text(description, color = c.muted, fontSize = 14.sp)
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalIptvColors.current
    Box(
        Modifier
            .clip(CircleShape)
            .background(if (selected) c.primary else c.surface)
            .border(BorderStroke(1.dp, if (selected) c.primary else c.border), CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
    ) {
        Text(text, color = if (selected) c.primaryFg else c.muted, fontSize = 14.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
    }
}

@Composable
fun BottomNav(current: String, onSelect: (String) -> Unit, label: (I18nKey) -> String) {
    val c = LocalIptvColors.current
    val items = listOf(
        Triple("home", I18nKey.home, Icons.Outlined.Home to Icons.Filled.Home),
        Triple("live", I18nKey.liveTv, Icons.Outlined.LiveTv to Icons.Filled.LiveTv),
        Triple("favorites", I18nKey.favorites, Icons.Outlined.FavoriteBorder to Icons.Filled.Favorite),
        Triple("settings", I18nKey.settings, Icons.Outlined.Settings to Icons.Filled.Settings),
    )
    Column(Modifier.fillMaxWidth().background(c.bgElevated)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.border))
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().height(68.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEach { (id, key, icons) ->
                val active = current == id
                Column(
                    Modifier.weight(1f).fillMaxSize().clickable { onSelect(id) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    // خط برتقالي صغير فوق العنصر النشط بدل الخلفية الكبيرة
                    Box(
                        Modifier
                            .width(28.dp)
                            .height(3.dp)
                            .clip(RoundedCornerShape(bottomStart = 3.dp, bottomEnd = 3.dp))
                            .background(if (active) c.primary else Color.Transparent),
                    )
                    Spacer(Modifier.height(9.dp))
                    Icon(
                        if (active) icons.second else icons.first,
                        null,
                        tint = if (active) c.primary else c.muted,
                        modifier = Modifier.size(25.dp),
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        label(key),
                        color = if (active) c.primary else c.muted,
                        fontSize = 11.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}

private fun initialsOf(name: String): String {
    val parts = name.replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (parts.isEmpty()) return "TV"
    if (parts.size == 1) return parts[0].take(2).uppercase()
    return (parts[0].first().toString() + parts[1].first()).uppercase()
}

private fun logoColor(seed: String): Color {
    var h = 0
    seed.forEach { h = h * 31 + it.code }
    val hues = listOf(210f, 222f, 232f, 198f, 190f, 250f, 265f)
    val hue = hues[kotlin.math.abs(h) % hues.size]
    return Color.hsl(hue, 0.55f, 0.38f)
}


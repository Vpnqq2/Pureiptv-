package com.black.pureiptv.ui.screens

import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.black.pureiptv.AppViewModel
import com.black.pureiptv.R
import com.black.pureiptv.data.model.Channel
import com.black.pureiptv.data.model.ContentKind
import com.black.pureiptv.data.model.PlaylistType
import com.black.pureiptv.ui.components.AppInput
import com.black.pureiptv.ui.components.AppLogo
import com.black.pureiptv.ui.components.BottomNav
import com.black.pureiptv.ui.components.ChannelLogo
import com.black.pureiptv.ui.components.ChannelRow
import com.black.pureiptv.ui.components.ChannelViewMode
import com.black.pureiptv.ui.components.ChannelsList
import com.black.pureiptv.ui.components.Chip
import com.black.pureiptv.ui.components.EmptyState
import com.black.pureiptv.ui.components.PrimaryButton
import com.black.pureiptv.ui.components.Screen
import com.black.pureiptv.ui.components.TopBar
import com.black.pureiptv.ui.components.DeletePlaylistDialog
import com.black.pureiptv.ui.components.PlaylistActionDialog
import com.black.pureiptv.ui.components.RenamePlaylistDialog
import com.black.pureiptv.ui.i18n.I18nKey
import com.black.pureiptv.ui.theme.LocalIptvColors
import com.black.pureiptv.ads.GlobalInterstitialAdManager
import coil.compose.rememberAsyncImagePainter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(vm: AppViewModel, onDone: (Boolean) -> Unit) {
    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    val context = androidx.compose.ui.platform.LocalContext.current
    
    LaunchedEffect(state.settings.onboardingDone) {
        delay(1100)
        
        // Preload interstitial ad for later use (when opening player)
        if (state.settings.onboardingDone) {
            val interstitialManager = GlobalInterstitialAdManager.getInstance(context)
            interstitialManager.loadAd(
                adsEnabled = state.settings.adsEnabled,
                adsFreeUntil = state.settings.adsFreeUntil
            )
        }
        
        onDone(state.settings.onboardingDone)
    }
    Column(
        Modifier.fillMaxSize().background(c.bg),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.lo_go),
            contentDescription = null,
            modifier = Modifier.size(88.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(24.dp))
        Text("pureiptv", color = c.fg, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(vm.t(I18nKey.tagline), color = c.muted, fontSize = 14.sp)
        Spacer(Modifier.height(40.dp))
        CircularProgressIndicator(color = c.primary, modifier = Modifier.size(40.dp), strokeWidth = 3.dp)
        Spacer(Modifier.height(12.dp))
        Text(vm.t(I18nKey.loading), color = c.subtle, fontSize = 12.sp)
    }
}

@Composable
fun OnboardingScreen(vm: AppViewModel, onDone: () -> Unit) {
    val c = LocalIptvColors.current
    var page by remember { mutableIntStateOf(0) }
    val slides = listOf(
        Triple(vm.t(I18nKey.onboard1Title), vm.t(I18nKey.onboard1Sub), vm.t(I18nKey.onboard1Body)),
        Triple(vm.t(I18nKey.onboard2Title), "", vm.t(I18nKey.onboard2Body)),
        Triple(vm.t(I18nKey.onboard3Title), "", vm.t(I18nKey.onboard3Body)),
        Triple("Important Notice", "", "This app is a PLAYER ONLY. You must add your own legal playlists. You are responsible for the content you choose to play."),
    )
    val (title, sub, body) = slides[page]
    val imageAssets = listOf("file:///android_asset/images/onboard-1.jpg", "file:///android_asset/images/onboard-2.jpg", "file:///android_asset/images/onboard-3.jpg", "file:///android_asset/images/onboard-1.jpg")
    
    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding().padding(24.dp)) {
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(24.dp)).background(c.surface), contentAlignment = Alignment.Center) {
                // استخدام الصور من assets فقط
                Image(
                    painter = rememberAsyncImagePainter(imageAssets[page]),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // إضافة overlay للنص
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(0.7f))
                        )
                    )
                )
            }
            Spacer(Modifier.height(24.dp))
            Text(title, color = c.fg, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            if (sub.isNotEmpty()) Text(sub, color = c.primary, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            Text(body, color = c.muted, fontSize = 14.sp)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 20.dp), horizontalArrangement = Arrangement.Center) {
            slides.indices.forEach { i ->
                Box(
                    Modifier.padding(4.dp).height(8.dp).width(if (i == page) 24.dp else 8.dp)
                        .clip(CircleShape).background(if (i == page) c.primary else c.borderStrong),
                )
            }
        }
        PrimaryButton(
            text = if (page == slides.lastIndex) vm.t(I18nKey.getStarted) else if (page == 0) vm.t(I18nKey.getStarted) else vm.t(I18nKey.next),
            onClick = {
                if (page == slides.lastIndex) {
                    vm.completeOnboarding()
                    onDone()
                } else page++
            },
        )
    }
}

@Composable
fun TabsScaffold(
    current: String, 
    vm: AppViewModel, 
    onTab: (String) -> Unit, 
    onNavigate: (String) -> Unit,
    content: @Composable (onOpenDrawer: () -> Unit) -> Unit
) {
    val c = LocalIptvColors.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    
    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = c.bg,
                modifier = Modifier.width(300.dp)
            ) {
                com.black.pureiptv.ui.components.NavigationDrawerContent(
                    vm = vm,
                    currentRoute = current,
                    onItemClick = { route ->
                        scope.launch { drawer.close() }
                        when (route) {
                            "home", "live", "favorites", "settings" -> onTab(route)
                            else -> onNavigate(route)
                        }
                    }
                )
            }
        }
    ) {
        Column(Modifier.fillMaxSize().background(c.bg)) {
            Box(Modifier.weight(1f)) { 
                content { scope.launch { drawer.open() } }
            }
            BottomNav(current, onTab) { vm.t(it) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    vm: AppViewModel,
    onSearch: () -> Unit,
    onAdd: () -> Unit,
    onLive: () -> Unit,
    onPlayer: (String) -> Unit,
    onPlaylist: (String) -> Unit,
    onNavigate: (String) -> Unit,
) {
    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    
    // Dialog states for playlist management
    var selectedPlaylist by remember { mutableStateOf<com.black.pureiptv.data.model.Playlist?>(null) }
    var showActionDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = c.bg,
                modifier = Modifier.width(300.dp)
            ) {
                com.black.pureiptv.ui.components.NavigationDrawerContent(
                    vm = vm,
                    currentRoute = "home",
                    onItemClick = { route ->
                        scope.launch { drawer.close() }
                        onNavigate(route)
                    }
                )
            }
        },
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.lo_go),
                    contentDescription = null,
                    modifier = Modifier.size(28.dp),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.width(8.dp))
                Text("pureiptv", color = c.fg, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                RoundIconButton(Icons.Filled.Search, onSearch)
                Spacer(Modifier.width(8.dp))
                RoundIconButton(Icons.Filled.Menu, { scope.launch { drawer.open() } })
            }
            Box(
                Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(28.dp)).clickable(onClick = onLive).background(c.surface),
            ) {
                // استخدام صورة hero للقنوات المباشرة
                Image(
                    painter = rememberAsyncImagePainter("file:///android_asset/images/hero-live.jpg"),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // إضافة overlay للنص
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(0.05f), Color.Black.copy(0.8f)))))
                Row(
                    Modifier.align(Alignment.TopStart).padding(16.dp).clip(CircleShape).background(c.live).padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(Color.White))
                    Spacer(Modifier.width(6.dp))
                    Text(vm.t(I18nKey.live), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                    Text(vm.t(I18nKey.heroTitle), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(vm.t(I18nKey.heroSub), color = Color.White.copy(0.8f), fontSize = 14.sp)
                    Text(vm.t(I18nKey.heroTag), color = Color.White.copy(0.7f), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(20.dp))
            PrimaryButton(vm.t(I18nKey.addPlaylistTitle), onAdd)
            if (state.history.isNotEmpty()) {
                Spacer(Modifier.height(24.dp))
                SectionTitle(vm.t(I18nKey.continueWatching))
                Spacer(Modifier.height(12.dp))
                state.history.take(3).forEach { h ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.card).border(BorderStroke(1.dp, c.border), RoundedCornerShape(16.dp)).clickable { onPlayer(h.channelId) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        ChannelLogo(h.name, h.logo)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.name, color = c.fg, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(h.group.orEmpty(), color = c.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Box(Modifier.size(34.dp).clip(CircleShape).background(c.primary.copy(0.16f)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.PlayArrow, null, tint = c.primary, modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            if (state.favorites.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                SectionTitle(vm.t(I18nKey.favorites))
                Spacer(Modifier.height(12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    state.favorites.take(12).forEach { f ->
                        Column(Modifier.width(76.dp).clickable { onPlayer(f.id) }.padding(end = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            ChannelLogo(f.name, f.logo, 60.dp)
                            Text(f.name, color = c.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            SectionTitle(vm.t(I18nKey.myPlaylists))
            Spacer(Modifier.height(12.dp))
            if (state.playlists.isEmpty()) {
                EmptyState(vm.t(I18nKey.noPlaylists), vm.t(I18nKey.noPlaylistsHint))
            } else {
                state.playlists.forEach { p ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(c.card)
                            .border(BorderStroke(1.dp, c.border), RoundedCornerShape(16.dp))
                            .combinedClickable(
                                onClick = { onPlaylist(p.id) },
                                onLongClick = {
                                    selectedPlaylist = p
                                    showActionDialog = true
                                }
                            )
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(16.dp)).background(c.primary.copy(0.15f)), contentAlignment = Alignment.Center) {
                            Icon(if (p.type == PlaylistType.XTREAM) Icons.Filled.LiveTv else Icons.Filled.PlaylistPlay, null, tint = c.primary)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, color = c.fg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${if (p.type == PlaylistType.XTREAM) "Xtream Codes" else "M3U"} · ${p.channelCount} ${vm.t(I18nKey.channels)}", color = c.muted, fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(c.success))
                            Spacer(Modifier.width(6.dp))
                            Text(vm.t(I18nKey.connected), color = c.success, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
            Spacer(Modifier.height(24.dp))
        }
        
        // Dialog for playlist actions
        selectedPlaylist?.let { playlist ->
            if (showActionDialog) {
                PlaylistActionDialog(
                    playlist = playlist,
                    vm = vm,
                    onDismiss = { showActionDialog = false },
                    onRename = { showRenameDialog = true },
                    onDelete = { showDeleteDialog = true }
                )
            }
            
            if (showRenameDialog) {
                RenamePlaylistDialog(
                    playlist = playlist,
                    vm = vm,
                    onDismiss = { showRenameDialog = false },
                    onConfirm = { newName ->
                        vm.renamePlaylist(playlist.id, newName)
                    }
                )
            }
            
            if (showDeleteDialog) {
                DeletePlaylistDialog(
                    playlist = playlist,
                    vm = vm,
                    onDismiss = { showDeleteDialog = false },
                    onConfirm = {
                        vm.removePlaylist(playlist.id)
                    }
                )
            }
        }
    }
}

@Composable
fun LiveScreen(vm: AppViewModel, onBack: () -> Unit, onSearch: () -> Unit, onPlayer: (String) -> Unit, onOpenDrawer: () -> Unit = {}) {
    val state by vm.state.collectAsState()
    val playlist = vm.activePlaylist()
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    // null = شاشة التصنيفات (كلها في مكان واحد) ، غير ذلك = قنوات التصنيف المختار
    var cat by remember { mutableStateOf<String?>(null) }
    var favOnly by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var viewMode by remember { mutableStateOf(ChannelViewMode.LIST) }
    val c = LocalIptvColors.current
    LaunchedEffect(playlist?.id) {
        playlist?.let {
            vm.setActivePlaylist(it.id)
            channels = vm.repository.loadChannels(it.id).filter { ch -> ch.kind == ContentKind.LIVE }
        }
    }
    val groupCounts = remember(channels) { channels.groupingBy { it.group }.eachCount().toSortedMap() }
    val favSet = state.favorites.map { it.id }.toSet()
    val showCategories = cat == null && q.isBlank() && !favOnly
    val filtered = if (showCategories) emptyList() else channels.filter {
        (cat == null || cat == "All" || it.group == cat) &&
            (!favOnly || it.id in favSet) &&
            (q.isBlank() || it.name.contains(q, true))
    }.take(400)
    if (playlist == null) {
        Screen { EmptyState(vm.t(I18nKey.noPlaylists), vm.t(I18nKey.noPlaylistsHint)) }
        return
    }
    // زر الرجوع يعيد المستخدم لشاشة التصنيفات بدل الخروج
    BackHandler(enabled = cat != null || favOnly || q.isNotBlank()) {
        when {
            q.isNotBlank() -> q = ""
            favOnly -> favOnly = false
            else -> cat = null
        }
    }
    val title = when {
        cat != null && cat != "All" -> cat!!
        else -> vm.t(I18nKey.liveTv)
    }
    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding().padding(horizontal = 20.dp)) {
        TopBar(title, if (cat != null) ({ cat = null }) else onBack) {
            if (!showCategories) {
                IconButton(
                    onClick = { viewMode = if (viewMode == ChannelViewMode.LIST) ChannelViewMode.GRID else ChannelViewMode.LIST },
                    modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(c.primary.copy(0.15f))
                ) {
                    Icon(
                        if (viewMode == ChannelViewMode.LIST) Icons.Filled.Apps else Icons.Filled.List,
                        contentDescription = null,
                        tint = c.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(Modifier.width(4.dp))
            }
            IconButton(onClick = { favOnly = !favOnly }) {
                Icon(Icons.Filled.Star, null, tint = if (favOnly) c.primary else c.fg)
            }
            IconButton(onClick = onOpenDrawer) { Icon(Icons.Filled.Menu, null, tint = c.fg) }
        }
        AppInput(q, { q = it }, vm.t(I18nKey.search), leadingIcon = Icons.Filled.Search)
        Spacer(Modifier.height(20.dp))
        if (showCategories) {
            val allLabel = vm.t(I18nKey.all)
            val chLabel = vm.t(I18nKey.channels)
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                item(key = "__all") { CategoryCard(allLabel, channels.size, chLabel, highlighted = true) { cat = "All" } }
                gridItems(groupCounts.entries.toList(), key = { it.key }) { e ->
                    CategoryCard(e.key, e.value, chLabel) { cat = e.key }
                }
            }
        } else if (filtered.isEmpty()) {
            EmptyState(vm.t(I18nKey.noChannels), vm.t(I18nKey.emptyCategory))
        } else {
            ChannelsList(
                channels = filtered,
                viewMode = viewMode,
                favorites = favSet,
                onChannelClick = onPlayer,
                onFavoriteClick = { channel ->
                    vm.toggleFavorite(vm.makeFavorite(channel.id, channel.playlistId, channel.kind, channel.name, channel.logo, channel.group))
                },
                vm = vm
            )
        }
    }
}

@Composable
private fun CategoryCard(name: String, count: Int, channelsLabel: String, highlighted: Boolean = false, onClick: () -> Unit) {
    val c = LocalIptvColors.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 104.dp)
            .clip(shape)
            .background(if (highlighted) c.primary.copy(alpha = 0.14f) else c.card)
            .border(BorderStroke(if (highlighted) 1.5.dp else 1.dp, if (highlighted) c.primary else c.border), shape)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            name,
            color = c.fg,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 21.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(10.dp))
        Text("$count $channelsLabel", color = if (highlighted) c.primary else c.muted, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun FavoritesScreen(vm: AppViewModel, onPlayer: (String) -> Unit, onOpenDrawer: () -> Unit = {}) {
    val state by vm.state.collectAsState()
    val c = LocalIptvColors.current
    var tab by remember { mutableStateOf(ContentKind.LIVE) }
    val list = state.favorites.filter { it.kind == tab }
    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding().padding(horizontal = 20.dp)) {
        // Top bar with menu icon
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                vm.t(I18nKey.favorites), 
                color = c.fg, 
                fontSize = 20.sp, 
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onOpenDrawer) { 
                Icon(Icons.Filled.Menu, null, tint = c.fg) 
            }
        }
        Row {
            listOf(ContentKind.LIVE to I18nKey.channels, ContentKind.MOVIE to I18nKey.movies, ContentKind.SERIES to I18nKey.series).forEach { (k, label) ->
                Chip(vm.t(label), tab == k) { tab = k }
                Spacer(Modifier.width(8.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) EmptyState(vm.t(I18nKey.noFavorites))
        else LazyColumn {
            items(list, key = { it.id }) { f ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(16.dp)).background(c.card)
                        .border(BorderStroke(1.dp, c.border), RoundedCornerShape(16.dp)).padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(Modifier.weight(1f).clickable { onPlayer(f.id) }, verticalAlignment = Alignment.CenterVertically) {
                        ChannelLogo(f.name, f.logo, 48.dp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(f.name, color = c.fg, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(f.group.orEmpty(), color = c.muted, fontSize = 12.sp)
                        }
                    }
                    IconButton(onClick = { vm.toggleFavorite(f) }) {
                        Icon(Icons.Filled.Star, null, tint = c.warn)
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundIconButton(icon: ImageVector, onClick: () -> Unit) {
    val c = LocalIptvColors.current
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(c.surface)
            .border(BorderStroke(1.dp, c.border), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = c.fg, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun SectionTitle(text: String) {
    val c = LocalIptvColors.current
    Text(text, color = c.fg, fontWeight = FontWeight.Bold, fontSize = 18.sp)
}

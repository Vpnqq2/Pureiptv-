package com.walliverse.app.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.walliverse.app.ui.components.Wordmark
import com.walliverse.app.ui.theme.WalliColors
import kotlinx.coroutines.delay

/** Branded intro: the W logo draws itself in neon pink, then the wordmark and tagline fade in. */
@Composable
fun SplashOverlay(onFinished: () -> Unit) {
    val draw = remember { Animatable(0f) }
    val text = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        draw.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        text.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
        delay(450)
        onFinished()
    }

    Box(
        Modifier.fillMaxSize().background(WalliColors.Background).pointerInput(Unit) {
            awaitPointerEventScope { while (true) awaitPointerEvent().changes.forEach { it.consume() } }
        },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Canvas(Modifier.size(120.dp)) {
                val w = size.width
                val h = size.height
                val path = Path().apply {
                    moveTo(0.14f * w, 0.20f * h)
                    lineTo(0.32f * w, 0.80f * h)
                    lineTo(0.50f * w, 0.42f * h)
                    lineTo(0.68f * w, 0.80f * h)
                    lineTo(0.86f * w, 0.20f * h)
                }
                val measure = PathMeasure()
                measure.setPath(path, false)
                val partial = Path()
                measure.getSegment(0f, measure.length * draw.value, partial, true)
                drawPath(partial, WalliColors.Pink.copy(alpha = 0.22f), style = Stroke(26.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(partial, WalliColors.Pink, style = Stroke(12.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            Spacer(Modifier.height(28.dp))
            Wordmark(Modifier.graphicsLayer { alpha = text.value; translationY = (1f - text.value) * 24.dp.toPx() })
            Spacer(Modifier.height(8.dp))
            Text(
                "Infinite Wallpapers for Your World",
                color = WalliColors.TextSecondary,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = text.value * 0.9f },
            )
        }
    }
}

package com.walliverse.app

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.walliverse.app.ui.components.EmptyState
import com.walliverse.app.ui.components.ErrorState
import com.walliverse.app.ui.theme.WalliverseTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class StatesTest {
    @get:Rule val rule = createComposeRule()

    @Test fun emptyFavoritesStateIsShown() {
        rule.setContent {
            WalliverseTheme { EmptyState(Icons.Outlined.FavoriteBorder, "No favorites yet", "Tap the heart on any wallpaper to save it here.") }
        }
        rule.onNodeWithText("No favorites yet").assertExists()
    }

    @Test fun errorStateRetryInvokesCallback() {
        var retried = false
        rule.setContent { WalliverseTheme { ErrorState("No internet connection.", { retried = true }) } }
        rule.onNodeWithText("Try again").performClick()
        assertTrue(retried)
    }
}

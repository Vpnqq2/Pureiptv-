package com.walliverse.app

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.walliverse.app.data.local.ThemeMode
import com.walliverse.app.navigation.WalliverseNavHost
import com.walliverse.app.ui.ActionsViewModel
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.splash.SplashOverlay
import com.walliverse.app.ui.theme.DarkPalette
import com.walliverse.app.ui.theme.LightPalette
import com.walliverse.app.ui.theme.WalliverseTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    private val container by lazy { (application as WalliverseApp).container }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen() // system splash (same colour as the in-app intro, so the hand-off is seamless)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        // Tiny local read so the first frame already has the saved theme (no dark -> light flash).
        val initialMode = runBlocking { container.settings.themeMode.first() }

        setContent {
            val mode by container.settings.themeMode.collectAsStateWithLifecycle(initialValue = initialMode)
            val systemDark = isSystemInDarkTheme()
            val dark = when (mode) {
                ThemeMode.Dark -> true
                ThemeMode.Light -> false
                ThemeMode.System -> systemDark
            }
            val scope = rememberCoroutineScope()
            var splashDone by rememberSaveable { mutableStateOf(false) }

            // While the (always dark) intro is visible keep light status-bar icons, then follow the theme.
            SystemBarsEffect(
                darkBars = dark || !splashDone,
                windowBackground = (if (dark) DarkPalette else LightPalette).background.toArgb(),
            )

            WalliverseTheme(darkTheme = dark) {
                val appVm: AppViewModel = viewModel(
                    factory = viewModelFactory { initializer { AppViewModel(container.repository) } }
                )
                val actionsVm: ActionsViewModel = viewModel(
                    factory = viewModelFactory {
                        initializer { ActionsViewModel(container.downloader, container.setter) }
                    }
                )
                Box(Modifier.fillMaxSize()) {
                    WalliverseNavHost(
                        vm = appVm,
                        actions = actionsVm,
                        ads = container.ads,
                        themeMode = mode,
                        onThemeChange = { m -> scope.launch { container.settings.setThemeMode(m) } },
                    )
                    AnimatedVisibility(visible = !splashDone, exit = fadeOut(tween(450))) {
                        SplashOverlay(onFinished = {
                            splashDone = true
                            container.ads.showAppOpenIfAvailable()
                        })
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        container.ads.attach(this)
    }

    override fun onStop() {
        container.ads.detach(this)
        super.onStop()
    }
}

@Composable
private fun SystemBarsEffect(darkBars: Boolean, windowBackground: Int) {
    val activity = LocalContext.current as ComponentActivity
    DisposableEffect(darkBars, windowBackground) {
        val style = if (darkBars) {
            SystemBarStyle.dark(Color.TRANSPARENT)
        } else {
            SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        }
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        activity.window.setBackgroundDrawable(ColorDrawable(windowBackground))
        onDispose { }
    }
}

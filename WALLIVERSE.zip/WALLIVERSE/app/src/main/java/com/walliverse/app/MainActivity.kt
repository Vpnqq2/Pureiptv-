package com.walliverse.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.walliverse.app.navigation.WalliverseNavHost
import com.walliverse.app.ui.ActionsViewModel
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.theme.WalliverseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        val container = (application as WalliverseApp).container
        setContent {
            WalliverseTheme {
                val appVm: AppViewModel = viewModel(
                    factory = viewModelFactory { initializer { AppViewModel(container.repository) } }
                )
                val actionsVm: ActionsViewModel = viewModel(
                    factory = viewModelFactory {
                        initializer { ActionsViewModel(container.downloader, container.setter) }
                    }
                )
                WalliverseNavHost(appVm, actionsVm)
            }
        }
    }
}

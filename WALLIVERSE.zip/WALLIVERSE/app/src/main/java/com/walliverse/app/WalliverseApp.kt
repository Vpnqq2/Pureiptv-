package com.walliverse.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.walliverse.app.core.AppConfig
import com.walliverse.app.data.local.FavoritesStore
import com.walliverse.app.data.local.FileCatalogCache
import com.walliverse.app.data.local.walliverseDataStore
import com.walliverse.app.data.remote.HttpCatalogSource
import com.walliverse.app.data.repository.WallpaperRepository
import com.walliverse.app.util.WallpaperDownloader
import com.walliverse.app.util.WallpaperSetter
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.TimeUnit

/** Hand-rolled dependency container (no DI framework needed for an app this size). */
class AppContainer(app: Application) {
    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            chain.proceed(chain.request().newBuilder().header("User-Agent", AppConfig.USER_AGENT).build())
        }
        .build()

    val repository = WallpaperRepository(
        source = HttpCatalogSource(httpClient, AppConfig.WALLPAPERS_JSON_URL),
        cache = FileCatalogCache(File(app.filesDir, "wallpapers_cache.json")),
        favorites = FavoritesStore(app.walliverseDataStore),
    )
    val downloader = WallpaperDownloader(app, httpClient)
    val setter = WallpaperSetter(app, httpClient)
}

class WalliverseApp : Application(), ImageLoaderFactory {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }

    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .okHttpClient(container.httpClient)
        .crossfade(true)
        .respectCacheHeaders(false)
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
        .diskCache {
            DiskCache.Builder()
                .directory(File(cacheDir, "image_cache"))
                .maxSizeBytes(400L * 1024 * 1024)
                .build()
        }
        .build()
}

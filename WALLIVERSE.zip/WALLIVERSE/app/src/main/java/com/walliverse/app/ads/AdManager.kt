package com.walliverse.app.ads

import android.app.Activity
import android.app.Application
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.walliverse.app.BuildConfig
import com.walliverse.app.core.AppConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.ref.WeakReference

/**
 * Interstitial + App Open ads. Everything runs on the main thread except SDK init.
 * Blank ad-unit ids disable the corresponding ad (release builds without ADMOB_* properties show no ads).
 */
class AdManager(private val app: Application) {
    private val main = Handler(Looper.getMainLooper())
    private var activityRef: WeakReference<Activity>? = null

    private val interstitialId = BuildConfig.ADMOB_INTERSTITIAL_ID
    private val appOpenId = BuildConfig.ADMOB_APP_OPEN_ID

    private var interstitial: InterstitialAd? = null
    private var interstitialLoading = false
    private var lastInterstitialAt = -AppConfig.INTERSTITIAL_COOLDOWN_MS

    private var appOpen: AppOpenAd? = null
    private var appOpenLoading = false
    private var appOpenLoadedAt = 0L
    private var lastAppOpenAt = -AppConfig.APP_OPEN_COOLDOWN_MS

    private var fullScreenShowing = false
    private var firstForeground = true
    private var initialized = false

    private val foregroundObserver = object : DefaultLifecycleObserver {
        override fun onStart(owner: LifecycleOwner) {
            // The very first start is handled by the splash hand-off in MainActivity.
            if (firstForeground) {
                firstForeground = false
                return
            }
            showAppOpenIfAvailable()
        }
    }

    fun attach(activity: Activity) { activityRef = WeakReference(activity) }
    fun detach(activity: Activity) { if (activityRef?.get() === activity) activityRef = null }

    /** Call once from Application.onCreate (main thread). */
    fun initialize() {
        if (initialized) return
        initialized = true
        if (interstitialId.isBlank() && appOpenId.isBlank()) return
        ProcessLifecycleOwner.get().lifecycle.addObserver(foregroundObserver)
        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(app) {
                main.post {
                    loadInterstitial()
                    loadAppOpen()
                }
            }
        }
    }

    // ------------------------------------------------------------ interstitial

    private fun loadInterstitial() {
        if (interstitialId.isBlank() || interstitial != null || interstitialLoading) return
        interstitialLoading = true
        InterstitialAd.load(
            app, interstitialId, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    interstitialLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    interstitialLoading = false
                }
            },
        )
    }

    /** Shows an interstitial if one is ready, the cooldown has passed and nothing else is on screen. */
    fun showInterstitial() {
        val activity = activityRef?.get() ?: return
        val ad = interstitial
        if (ad == null) {
            loadInterstitial()
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (fullScreenShowing || now - lastInterstitialAt < AppConfig.INTERSTITIAL_COOLDOWN_MS) return
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                lastInterstitialAt = SystemClock.elapsedRealtime()
            }

            override fun onAdDismissedFullScreenContent() {
                fullScreenShowing = false
                interstitial = null
                loadInterstitial()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                fullScreenShowing = false
                interstitial = null
                loadInterstitial()
            }
        }
        fullScreenShowing = true
        ad.show(activity)
    }

    // ------------------------------------------------------------ app open

    private fun appOpenFresh(): Boolean =
        appOpen != null && SystemClock.elapsedRealtime() - appOpenLoadedAt < FOUR_HOURS_MS

    private fun loadAppOpen() {
        if (appOpenId.isBlank() || appOpenLoading || appOpenFresh()) return
        appOpenLoading = true
        AppOpenAd.load(
            app, appOpenId, AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpen = ad
                    appOpenLoadedAt = SystemClock.elapsedRealtime()
                    appOpenLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    appOpenLoading = false
                }
            },
        )
    }

    fun showAppOpenIfAvailable() {
        val activity = activityRef?.get() ?: return
        if (!appOpenFresh()) {
            appOpen = null
            loadAppOpen()
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (fullScreenShowing || now - lastAppOpenAt < AppConfig.APP_OPEN_COOLDOWN_MS) return
        val ad = appOpen ?: return
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                lastAppOpenAt = SystemClock.elapsedRealtime()
            }

            override fun onAdDismissedFullScreenContent() {
                fullScreenShowing = false
                appOpen = null
                loadAppOpen()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                fullScreenShowing = false
                appOpen = null
                loadAppOpen()
            }
        }
        fullScreenShowing = true
        ad.show(activity)
    }

    private companion object {
        const val FOUR_HOURS_MS = 4 * 60 * 60 * 1000L
    }
}

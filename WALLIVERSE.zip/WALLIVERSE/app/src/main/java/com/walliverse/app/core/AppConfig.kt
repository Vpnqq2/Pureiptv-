package com.walliverse.app.core

/** Central configuration. Change values here only. */
object AppConfig {
    /** Direct RAW GitHub URL of wallpapers.json (supplied by the project owner). */
    const val WALLPAPERS_JSON_URL =
        "https://raw.githubusercontent.com/qatarvpn/pngm/refs/heads/main/wallpapers.json"

    /** Set to your privacy policy page. When blank the Settings row explains it is not configured. */
    const val PRIVACY_POLICY_URL = ""

    /** Some image hosts reject requests without a browser-like User-Agent. */
    const val USER_AGENT = "Mozilla/5.0 (Linux; Android 14) WALLIVERSE/1.0"

    /** Incremental rendering page size for wallpaper grids. */
    const val PAGE_SIZE = 40

    const val DOWNLOAD_FOLDER = "WALLIVERSE"
}

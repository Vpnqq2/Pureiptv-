package com.walliverse.app.data.local

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

interface CatalogCache {
    suspend fun read(): String?
    suspend fun write(json: String)
}

/** Persists the last good wallpapers.json so the app works offline after the first successful load. */
class FileCatalogCache(private val file: File) : CatalogCache {
    override suspend fun read(): String? = withContext(Dispatchers.IO) {
        runCatching { if (file.exists()) file.readText() else null }.getOrNull()
    }

    override suspend fun write(json: String) {
        withContext(Dispatchers.IO) {
            runCatching {
                val tmp = File(file.parentFile, file.name + ".tmp")
                tmp.writeText(json)
                if (!tmp.renameTo(file)) {
                    file.writeText(json)
                    tmp.delete()
                }
            }
        }
    }
}

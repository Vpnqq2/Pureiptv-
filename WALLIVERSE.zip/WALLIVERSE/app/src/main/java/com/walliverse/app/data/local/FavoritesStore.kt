package com.walliverse.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.walliverseDataStore: DataStore<Preferences> by preferencesDataStore(name = "walliverse")

/** Favorites persisted as a set of stable wallpaper IDs. */
class FavoritesStore(private val dataStore: DataStore<Preferences>) {

    val favoriteIds: Flow<Set<String>> = dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it[KEY] ?: emptySet() }

    suspend fun toggle(id: String) {
        dataStore.edit { prefs ->
            val current = prefs[KEY]?.toMutableSet() ?: mutableSetOf()
            if (!current.add(id)) current.remove(id)
            prefs[KEY] = current
        }
    }

    private companion object {
        val KEY = stringSetPreferencesKey("favorite_ids")
    }
}

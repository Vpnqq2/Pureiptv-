package com.walliverse.app.data.model

import java.util.Locale

/**
 * One wallpaper record. [id], [title], [category] and [imageUrl] are the original values from the JSON
 * and are never altered. Everything else is derived for display / matching.
 */
data class Wallpaper(
    val id: String,
    val title: String,
    val category: String,
    val imageUrl: String,
    /** [imageUrl] percent-encoded and validated (https only). Null when the link is unusable. */
    val loadUrl: String?,
) {
    val categoryKey: String = category.trim().lowercase(Locale.ROOT).ifEmpty { "other" }
    val categoryLabel: String = category.trim().ifEmpty { "Other" }.replaceFirstChar { it.uppercase() }
    val displayTitle: String = title.trim().let {
        if (it.isEmpty() || it.equals("unknown", ignoreCase = true)) "$categoryLabel #$id" else it
    }

    /** True only when the record's title is literally "4k" (metadata, not a verified resolution). */
    val hasFourKTag: Boolean = title.trim().equals("4k", ignoreCase = true)
    val numericId: Long = id.toLongOrNull() ?: Long.MIN_VALUE
    val searchText: String = "$title $category".lowercase(Locale.ROOT)
}

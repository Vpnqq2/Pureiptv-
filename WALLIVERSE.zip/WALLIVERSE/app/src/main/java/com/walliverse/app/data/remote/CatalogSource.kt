package com.walliverse.app.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

interface CatalogSource {
    suspend fun fetch(): String
}

class HttpCatalogSource(
    private val client: OkHttpClient,
    private val url: String,
) : CatalogSource {
    override suspend fun fetch(): String = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url).header("Accept", "application/json").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            response.body?.string() ?: throw IOException("Empty response")
        }
    }
}

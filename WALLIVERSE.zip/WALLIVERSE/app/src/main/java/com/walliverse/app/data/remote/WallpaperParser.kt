package com.walliverse.app.data.remote

import com.walliverse.app.data.model.Wallpaper
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/**
 * Tolerant parser: one malformed record never breaks the list. Throws [SerializationException]
 * only when the document itself is not JSON / not an array.
 */
object WallpaperParser {

    fun parse(json: String): List<Wallpaper> {
        val root = Json.parseToJsonElement(json)
        val array: JsonArray = when (root) {
            is JsonArray -> root
            is JsonObject -> root["wallpapers"] as? JsonArray
                ?: throw SerializationException("Expected a JSON array of wallpapers")
            else -> throw SerializationException("Expected a JSON array of wallpapers")
        }
        val usedIds = HashSet<String>()
        val result = ArrayList<Wallpaper>(array.size)
        array.forEachIndexed { index, element ->
            val obj = element as? JsonObject ?: return@forEachIndexed
            val rawUrl = obj.string("imageUrl").orEmpty().trim()
            var id = obj.string("id")?.trim().orEmpty().ifEmpty { "item_${index + 1}" }
            if (!usedIds.add(id)) {
                id = "${id}_${index + 1}"
                usedIds.add(id)
            }
            result.add(
                Wallpaper(
                    id = id,
                    title = obj.string("title").orEmpty(),
                    category = obj.string("category").orEmpty(),
                    imageUrl = rawUrl,
                    loadUrl = normalizeUrl(rawUrl),
                )
            )
        }
        return result
    }

    /** Percent-encodes spaces / non-ASCII characters and rejects anything that is not valid https. */
    fun normalizeUrl(raw: String): String? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null
        val url = trimmed.toHttpUrlOrNull() ?: return null
        return if (url.isHttps) url.toString() else null
    }

    private fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull
}

package com.walliverse.app.data.repository

import com.walliverse.app.data.local.CatalogCache
import com.walliverse.app.data.local.FavoritesStore
import com.walliverse.app.data.model.Wallpaper
import com.walliverse.app.data.remote.CatalogSource
import com.walliverse.app.data.remote.WallpaperParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow

class WallpaperRepository(
    private val source: CatalogSource,
    private val cache: CatalogCache,
    private val favorites: FavoritesStore,
) {
    data class LoadResult(
        val items: List<Wallpaper>,
        /** True when the network failed and saved data was returned instead. */
        val fromCache: Boolean,
        val error: Throwable?,
    )

    private var memory: List<Wallpaper>? = null

    val favoriteIds: Flow<Set<String>> = favorites.favoriteIds

    suspend fun toggleFavorite(id: String) = favorites.toggle(id)

    suspend fun load(forceRefresh: Boolean = false): LoadResult {
        if (!forceRefresh) memory?.let { return LoadResult(it, fromCache = false, error = null) }
        return try {
            val text = source.fetch()
            val items = WallpaperParser.parse(text)
            cache.write(text)
            memory = items
            LoadResult(items, fromCache = false, error = null)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val fallback = memory ?: cache.read()?.let { runCatching { WallpaperParser.parse(it) }.getOrNull() }
            if (fallback != null) {
                memory = fallback
                LoadResult(fallback, fromCache = true, error = e)
            } else {
                LoadResult(emptyList(), fromCache = false, error = e)
            }
        }
    }
}

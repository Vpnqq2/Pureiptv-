package com.walliverse.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.walliverse.app.data.model.Wallpaper
import com.walliverse.app.util.DownloadResult
import com.walliverse.app.util.SetResult
import com.walliverse.app.util.WallpaperDownloader
import com.walliverse.app.util.WallpaperSetter
import com.walliverse.app.util.WallpaperTarget
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ActionState(
    val busy: Boolean = false,
    val label: String? = null,
    /** 0..1, or null for indeterminate. */
    val progress: Float? = null,
)

/** Owns downloads / set-wallpaper work so it survives rotation and screen changes. One job at a time. */
class ActionsViewModel(
    private val downloader: WallpaperDownloader,
    private val setter: WallpaperSetter,
) : ViewModel() {

    private val _state = MutableStateFlow(ActionState())
    val state: StateFlow<ActionState> = _state.asStateFlow()

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    /** Emits when an interstitial should be offered (download tapped / wallpaper applied). */
    private val _adEvents = Channel<Unit>(Channel.CONFLATED)
    val adEvents: Flow<Unit> = _adEvents.receiveAsFlow()

    private fun tryStart(label: String): Boolean {
        if (_state.value.busy) return false
        _state.value = ActionState(busy = true, label = label, progress = null)
        return true
    }

    private fun finish() {
        _state.value = ActionState()
    }

    fun download(wallpaper: Wallpaper) {
        if (!tryStart("Downloading…")) return
        _adEvents.trySend(Unit) // ad shows on top while the download runs in the background
        viewModelScope.launch {
            val result = downloader.download(wallpaper) { p -> _state.update { it.copy(progress = p) } }
            finish()
            _messages.send(
                when (result) {
                    is DownloadResult.Saved -> "Saved to Pictures/WALLIVERSE (${result.name})"
                    is DownloadResult.AlreadyExists -> "Already downloaded: ${result.name}"
                    is DownloadResult.Failed -> "Download failed: ${result.message}"
                }
            )
        }
    }

    fun setWallpaper(wallpaper: Wallpaper, target: WallpaperTarget) {
        if (!tryStart("Setting wallpaper…")) return
        viewModelScope.launch {
            val result = setter.set(wallpaper, target) { p -> _state.update { it.copy(progress = p) } }
            finish()
            if (result is SetResult.Success) _adEvents.trySend(Unit)
            _messages.send(
                when (result) {
                    SetResult.Success -> "Wallpaper set for: ${target.label}"
                    is SetResult.Failed -> "Couldn't set wallpaper: ${result.message}"
                }
            )
        }
    }
}

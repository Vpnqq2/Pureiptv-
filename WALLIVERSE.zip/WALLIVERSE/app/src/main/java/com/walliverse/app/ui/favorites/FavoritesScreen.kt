package com.walliverse.app.ui.favorites

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.components.EmptyState
import com.walliverse.app.ui.components.ErrorState
import com.walliverse.app.ui.components.LoadingGrid
import com.walliverse.app.ui.components.WallpaperGrid

@Composable
fun FavoritesScreen(vm: AppViewModel, onOpenWallpaper: (String) -> Unit) {
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val ids by vm.favoriteIds.collectAsStateWithLifecycle()
    val favorites = remember(catalog.items, ids) { catalog.items.filter { it.id in ids } }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Favorites", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp))
        when {
            catalog.loading && catalog.items.isEmpty() -> LoadingGrid(Modifier.weight(1f))
            catalog.items.isEmpty() && catalog.error != null && ids.isNotEmpty() ->
                ErrorState(catalog.error.orEmpty(), vm::retry, Modifier.weight(1f))
            favorites.isEmpty() -> EmptyState(
                icon = Icons.Outlined.FavoriteBorder,
                title = "No favorites yet",
                message = "Tap the heart on any wallpaper to save it here.",
                modifier = Modifier.weight(1f),
            )
            else -> WallpaperGrid(favorites, ids, onOpenWallpaper, vm::toggleFavorite, Modifier.weight(1f))
        }
    }
}

package com.walliverse.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.walliverse.app.domain.CategoryInfo
import com.walliverse.app.domain.SortOrder
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.components.EmptyState
import com.walliverse.app.ui.components.ErrorState
import com.walliverse.app.ui.components.LoadingGrid
import com.walliverse.app.ui.components.SearchBarButton
import com.walliverse.app.ui.components.SectionHeader
import com.walliverse.app.ui.components.WallpaperGrid
import com.walliverse.app.ui.components.WallpaperImage
import com.walliverse.app.ui.components.Wordmark
import com.walliverse.app.ui.components.fullSpanItem
import com.walliverse.app.ui.theme.WalliColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: AppViewModel,
    onOpenWallpaper: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenCategory: (String) -> Unit,
) {
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val items by vm.homeItems.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val favorites by vm.favoriteIds.collectAsStateWithLifecycle()
    val sort by vm.sort.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        when {
            catalog.loading && catalog.items.isEmpty() -> {
                HomeTop(sort, vm::setSort, onOpenSearch)
                LoadingGrid(Modifier.weight(1f))
            }
            catalog.items.isEmpty() && catalog.error != null ->
                ErrorState(catalog.error.orEmpty(), vm::retry, Modifier.weight(1f))
            catalog.items.isEmpty() -> EmptyState(
                icon = Icons.Outlined.Image,
                title = "No wallpapers yet",
                message = "The wallpaper list is empty. Pull down to refresh.",
                modifier = Modifier.weight(1f),
                actionLabel = "Refresh",
                onAction = vm::refresh,
            )
            else -> PullToRefreshBox(
                isRefreshing = catalog.refreshing,
                onRefresh = vm::refresh,
                modifier = Modifier.weight(1f),
            ) {
                WallpaperGrid(
                    items = items,
                    favoriteIds = favorites,
                    onOpen = onOpenWallpaper,
                    onToggleFavorite = vm::toggleFavorite,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    header = {
                        fullSpanItem("top") {
                            Column {
                                HomeTop(sort, vm::setSort, onOpenSearch, Modifier.padding(horizontal = 0.dp))
                                if (catalog.fromCache) OfflineBanner(vm::retry)
                            }
                        }
                        fullSpanItem("featured") {
                            FeaturedPager(categories.take(5), onOpenWallpaper, onOpenCategory)
                        }
                        fullSpanItem("latest-header") { SectionHeader("Wallpapers") }
                    },
                )
            }
        }
    }
}

@Composable
private fun HomeTop(
    sort: SortOrder,
    onSort: (SortOrder) -> Unit,
    onOpenSearch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Column(modifier.padding(horizontal = 16.dp).padding(top = 8.dp, bottom = 12.dp)) {
        Wordmark(Modifier.padding(vertical = 8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            SearchBarButton(onOpenSearch, Modifier.weight(1f))
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Outlined.Tune, contentDescription = "Sort wallpapers")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }, modifier = Modifier.background(WalliColors.Elevated)) {
                    SortOrder.entries.forEach { order ->
                        DropdownMenuItem(
                            text = {
                                Text(order.label, color = if (order == sort) WalliColors.Pink else Color.White)
                            },
                            onClick = { onSort(order); menuOpen = false },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OfflineBanner(onRetry: () -> Unit) {
    Row(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(WalliColors.Elevated)
            .padding(start = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text("Offline — showing saved wallpapers", color = WalliColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = onRetry) { Text("Retry", color = WalliColors.Pink) }
    }
}

/** One featured card per category (cover = first wallpaper of that category). No popularity is implied. */
@Composable
private fun FeaturedPager(
    featured: List<CategoryInfo>,
    onOpenWallpaper: (String) -> Unit,
    onOpenCategory: (String) -> Unit,
) {
    if (featured.isEmpty()) return
    val pagerState = rememberPagerState { featured.size }
    Column(Modifier.padding(bottom = 8.dp)) {
        HorizontalPager(state = pagerState, pageSpacing = 12.dp) { page ->
            val info = featured[page]
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.75f)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable(onClickLabel = "Open wallpaper") { onOpenWallpaper(info.cover.id) }
            ) {
                WallpaperImage(info.cover.loadUrl, "Featured ${info.label} wallpaper", Modifier.fillMaxSize())
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC101010)))
                    )
                )
                Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                    Text("Featured", color = WalliColors.TextSecondary, style = MaterialTheme.typography.labelMedium)
                    Text(info.label, style = MaterialTheme.typography.titleLarge)
                    Text("${info.count} wallpapers", color = WalliColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(
                    onClick = { onOpenCategory(info.key) },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                        .size(40.dp).background(WalliColors.Pink, CircleShape),
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Browse ${info.label}", tint = Color.White)
                }
            }
        }
        if (featured.size > 1) {
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center,
            ) {
                repeat(featured.size) { i ->
                    Box(
                        Modifier.padding(horizontal = 3.dp).size(if (i == pagerState.currentPage) 8.dp else 6.dp)
                            .background(if (i == pagerState.currentPage) WalliColors.Pink else WalliColors.Border, CircleShape)
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}

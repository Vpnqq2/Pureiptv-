package com.walliverse.app.ui.home

import androidx.compose.foundation.Image
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.util.lerp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.walliverse.app.data.model.Wallpaper
import kotlinx.coroutines.delay
import kotlin.math.absoluteValue
import androidx.compose.ui.res.painterResource
import com.walliverse.app.R
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.walliverse.app.domain.CategoryInfo
import com.walliverse.app.domain.SortOrder
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.components.EmptyState
import com.walliverse.app.ui.components.ErrorState
import com.walliverse.app.ui.components.LoadingGrid
import com.walliverse.app.ui.components.SearchBarButton
import com.walliverse.app.ui.components.SectionHeader
import com.walliverse.app.ui.components.WallpaperGrid
import com.walliverse.app.ui.components.WallpaperImage
import com.walliverse.app.ui.components.Wordmark
import com.walliverse.app.ui.components.fadeSlideIn
import com.walliverse.app.ui.components.fullSpanItem
import com.walliverse.app.ui.theme.WalliColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: AppViewModel,
    onOpenWallpaper: (String) -> Unit,
    onOpenSearch: () -> Unit,
) {
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val items by vm.homeItems.collectAsStateWithLifecycle()
    val featured by vm.featured.collectAsStateWithLifecycle()
    val favorites by vm.favoriteIds.collectAsStateWithLifecycle()
    val sort by vm.sort.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        when {
            catalog.loading && catalog.items.isEmpty() -> {
                HomeTop(sort, vm::setSort, onOpenSearch)
                LoadingGrid(Modifier.weight(1f))
            }
            catalog.items.isEmpty() && catalog.error != null ->
                ErrorState(catalog.error.orEmpty(), vm::retry, Modifier.weight(1f))
            catalog.items.isEmpty() -> EmptyState(
                icon = Icons.Outlined.Image,
                title = "No wallpapers yet",
                message = "The wallpaper list is empty. Pull down to refresh.",
                modifier = Modifier.weight(1f),
                actionLabel = "Refresh",
                onAction = vm::refresh,
            )
            else -> PullToRefreshBox(
                isRefreshing = catalog.refreshing,
                onRefresh = vm::refresh,
                modifier = Modifier.weight(1f),
            ) {
                WallpaperGrid(
                    items = items,
                    favoriteIds = favorites,
                    onOpen = onOpenWallpaper,
                    onToggleFavorite = vm::toggleFavorite,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    header = {
                        fullSpanItem("top") {
                            Column {
                                HomeTop(sort, vm::setSort, onOpenSearch, Modifier.padding(horizontal = 0.dp))
                                if (catalog.fromCache) OfflineBanner(vm::retry)
                            }
                        }
                        fullSpanItem("featured") {
                            FeaturedPager(featured, onOpenWallpaper)
                        }
                        fullSpanItem("latest-header") { SectionHeader("Wallpapers", Modifier.fadeSlideIn(240, 16.dp)) }
                    },
                )
            }
        }
    }
}

@Composable
private fun HomeTop(
    sort: SortOrder,
    onSort: (SortOrder) -> Unit,
    onOpenSearch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Column(modifier.padding(horizontal = 16.dp).padding(top = 8.dp, bottom = 12.dp)) {
        Row(Modifier.padding(vertical = 8.dp).fadeSlideIn(0, 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.logo_art), contentDescription = null, modifier = Modifier.size(34.dp))
            Spacer(Modifier.size(10.dp))
            Wordmark()
        }
        Row(Modifier.fadeSlideIn(80), verticalAlignment = Alignment.CenterVertically) {
            SearchBarButton(onOpenSearch, Modifier.weight(1f))
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Outlined.Tune, contentDescription = "Sort wallpapers")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }, modifier = Modifier.background(WalliColors.Elevated)) {
                    SortOrder.entries.forEach { order ->
                        DropdownMenuItem(
                            text = {
                                Text(order.label, color = if (order == sort) WalliColors.Pink else WalliColors.TextPrimary)
                            },
                            onClick = { onSort(order); menuOpen = false },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OfflineBanner(onRetry: () -> Unit) {
    Row(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(WalliColors.Elevated)
            .padding(start = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text("Offline — showing saved wallpapers", color = WalliColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = onRetry) { Text("Retry", color = WalliColors.Pink) }
    }
}

private const val SLIDE_INTERVAL_MS = 4000L
private const val VIRTUAL_PAGES = 10_000

/**
 * Auto-playing slideshow of random wallpapers. Slides glide with a parallax + scale/fade effect, loop endlessly,
 * pause while the user drags or the app is in the background, and open the wallpaper when tapped.
 */
@Composable
private fun FeaturedPager(featured: List<Wallpaper>, onOpenWallpaper: (String) -> Unit) {
    if (featured.isEmpty()) return
    val size = featured.size
    val pageCount = if (size > 1) VIRTUAL_PAGES else 1
    val startPage = if (size > 1) (VIRTUAL_PAGES / 2) - ((VIRTUAL_PAGES / 2) % size) else 0
    val pagerState = rememberPagerState(initialPage = startPage) { pageCount }
    val dragged by pagerState.interactionSource.collectIsDraggedAsState()
    val lifecycleOwner = LocalLifecycleOwner.current
    val settled = pagerState.settledPage

    // Restarts after every settled page / drag, so the timer always counts from the last interaction.
    LaunchedEffect(featured, dragged, settled) {
        if (size < 2 || dragged) return@LaunchedEffect
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            delay(SLIDE_INTERVAL_MS)
            pagerState.animateScrollToPage(
                page = pagerState.settledPage + 1,
                animationSpec = tween(800, easing = FastOutSlowInEasing),
            )
        }
    }

    Column(Modifier.padding(bottom = 8.dp).fadeSlideIn(160, 32.dp)) {
        HorizontalPager(
            state = pagerState,
            pageSpacing = 12.dp,
            beyondViewportPageCount = 1, // next slide is already loaded when it glides in
        ) { page ->
            val wallpaper = featured[page % size]
            fun signedOffset() = (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.75f)
                    .graphicsLayer {
                        val far = signedOffset().absoluteValue.coerceIn(0f, 1f)
                        val s = lerp(0.9f, 1f, 1f - far)
                        scaleX = s
                        scaleY = s
                        alpha = lerp(0.55f, 1f, 1f - far)
                    }
                    .clip(RoundedCornerShape(20.dp))
                    .clickable(onClickLabel = "Open wallpaper") { onOpenWallpaper(wallpaper.id) }
            ) {
                WallpaperImage(
                    wallpaper.loadUrl,
                    "Featured wallpaper: ${wallpaper.displayTitle}",
                    Modifier.fillMaxSize().graphicsLayer {
                        translationX = signedOffset() * this.size.width * 0.12f // parallax
                        scaleX = 1.25f
                        scaleY = 1.25f
                    },
                )
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC101010)))
                    )
                )
                Column(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                        .graphicsLayer { alpha = 1f - (signedOffset().absoluteValue * 1.5f).coerceIn(0f, 1f) }
                ) {
                    Text(
                        "Featured · ${wallpaper.categoryLabel}",
                        color = WalliColors.OnImageMuted,
                        style = MaterialTheme.typography.labelMedium,
                    )
                    Text(
                        wallpaper.displayTitle,
                        color = WalliColors.OnImage,
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                    )
                }
            }
        }
        if (size > 1) {
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.Center,
            ) {
                val current = pagerState.currentPage % size
                repeat(size) { i ->
                    val active = current == i
                    val dotWidth by animateDpAsState(if (active) 20.dp else 6.dp, tween(300), label = "dotWidth")
                    val dotColor by animateColorAsState(if (active) WalliColors.Pink else WalliColors.Border, tween(300), label = "dotColor")
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .height(6.dp)
                            .width(dotWidth)
                            .background(dotColor, CircleShape)
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}

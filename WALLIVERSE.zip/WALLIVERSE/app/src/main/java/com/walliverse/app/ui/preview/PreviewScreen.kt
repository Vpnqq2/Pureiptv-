package com.walliverse.app.ui.preview

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.walliverse.app.ui.ActionsViewModel
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.components.EmptyState
import com.walliverse.app.ui.components.FavoriteButton
import com.walliverse.app.ui.components.WallpaperImage
import com.walliverse.app.ui.theme.WalliColors
import com.walliverse.app.util.WallpaperTarget
import com.walliverse.app.util.findActivity

@Composable
fun PreviewScreen(vm: AppViewModel, actions: ActionsViewModel, id: String, onBack: () -> Unit) {
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val favorites by vm.favoriteIds.collectAsStateWithLifecycle()
    val action by actions.state.collectAsStateWithLifecycle()
    val wallpaper = remember(catalog.items, id) { catalog.items.firstOrNull { it.id == id } }
    var immersive by rememberSaveable { mutableStateOf(false) }
    var showSetDialog by rememberSaveable { mutableStateOf(false) }

    ImmersiveEffect(immersive)

    if (wallpaper == null) {
        Box(Modifier.fillMaxSize().statusBarsPadding(), contentAlignment = Alignment.Center) {
            if (catalog.loading) CircularProgressIndicator(color = WalliColors.Pink)
            else EmptyState(Icons.Outlined.Image, "Wallpaper not found", "This wallpaper is no longer in the list.", actionLabel = "Go back", onAction = onBack)
        }
        return
    }
    val isFavorite = wallpaper.id in favorites

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { immersive = !immersive }
    ) {
        WallpaperImage(wallpaper.loadUrl, wallpaper.displayTitle, Modifier.fillMaxSize())

        AnimatedVisibility(visible = !immersive, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize()) {
                Row(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onBack) {
                        Box(Modifier.size(36.dp).background(Color(0x99000000), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                    FavoriteButton(isFavorite, { vm.toggleFavorite(wallpaper.id) })
                }

                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6101010))))
                        .navigationBarsPadding()
                        .padding(start = 20.dp, end = 20.dp, top = 56.dp, bottom = 20.dp)
                ) {
                    Text(wallpaper.displayTitle, style = MaterialTheme.typography.headlineSmall, maxLines = 2)
                    Text(
                        buildString {
                            append(wallpaper.categoryLabel)
                            if (wallpaper.hasFourKTag) append(" · Tagged 4K")
                        },
                        color = WalliColors.TextSecondary,
                        modifier = Modifier.padding(top = 2.dp, bottom = 14.dp),
                    )
                    if (action.busy) {
                        Text(action.label.orEmpty(), color = WalliColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                        val p = action.progress
                        if (p != null) {
                            LinearProgressIndicator(
                                progress = { p },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                color = WalliColors.Pink,
                                trackColor = WalliColors.Border,
                            )
                        } else {
                            LinearProgressIndicator(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                color = WalliColors.Pink,
                                trackColor = WalliColors.Border,
                            )
                        }
                    }
                    Button(
                        onClick = { actions.download(wallpaper) },
                        enabled = !action.busy,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WalliColors.Pink, contentColor = Color.White),
                    ) {
                        Icon(Icons.Outlined.Download, null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.size(8.dp))
                        Text("Download")
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { showSetDialog = true },
                            enabled = !action.busy,
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            border = BorderStroke(1.dp, WalliColors.Pink),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = WalliColors.Pink),
                        ) {
                            Icon(Icons.Outlined.Image, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("Set as Wallpaper")
                        }
                        OutlinedButton(
                            onClick = { vm.toggleFavorite(wallpaper.id) },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            border = BorderStroke(1.dp, WalliColors.Pink),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = WalliColors.Pink),
                        ) {
                            Icon(if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text(if (isFavorite) "Saved" else "Favorite")
                        }
                    }
                }
            }
        }
    }

    if (showSetDialog) {
        AlertDialog(
            onDismissRequest = { showSetDialog = false },
            containerColor = WalliColors.Elevated,
            title = { Text("Set wallpaper") },
            text = {
                Column {
                    Text(
                        "The full-resolution image is downloaded first. Your device may not support every option.",
                        color = WalliColors.TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                    WallpaperTarget.entries.forEach { target ->
                        TextButton(
                            onClick = { showSetDialog = false; actions.setWallpaper(wallpaper, target) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(target.label, modifier = Modifier.fillMaxWidth(), color = Color.White)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showSetDialog = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ImmersiveEffect(immersive: Boolean) {
    val view = LocalView.current
    DisposableEffect(immersive) {
        val window = view.context.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (immersive) controller?.hide(WindowInsetsCompat.Type.systemBars())
        else controller?.show(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
}

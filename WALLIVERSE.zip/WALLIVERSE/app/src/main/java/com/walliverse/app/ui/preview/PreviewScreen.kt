package com.walliverse.app.ui.preview

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import com.walliverse.app.ui.components.WalliButton
import com.walliverse.app.ui.components.fadeSlideIn
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.material3.LocalContentColor
import com.walliverse.app.ui.theme.DarkPalette
import com.walliverse.app.ui.theme.LocalPalette
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.walliverse.app.ui.ActionsViewModel
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.components.EmptyState
import com.walliverse.app.ui.components.FavoriteButton
import com.walliverse.app.ui.components.WallpaperImage
import com.walliverse.app.ui.theme.WalliColors
import com.walliverse.app.util.WallpaperTarget
import com.walliverse.app.util.findActivity

@Composable
fun PreviewScreen(vm: AppViewModel, actions: ActionsViewModel, id: String, onBack: () -> Unit) {
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val favorites by vm.favoriteIds.collectAsStateWithLifecycle()
    val action by actions.state.collectAsStateWithLifecycle()
    val wallpaper = remember(catalog.items, id) { catalog.items.firstOrNull { it.id == id } }
    var immersive by rememberSaveable { mutableStateOf(false) }
    var showSetDialog by rememberSaveable { mutableStateOf(false) }

    ImmersiveEffect(immersive)

    if (wallpaper == null) {
        Box(Modifier.fillMaxSize().statusBarsPadding(), contentAlignment = Alignment.Center) {
            if (catalog.loading) CircularProgressIndicator(color = WalliColors.Pink)
            else EmptyState(Icons.Outlined.Image, "Wallpaper not found", "This wallpaper is no longer in the list.", actionLabel = "Go back", onAction = onBack)
        }
        return
    }
    val isFavorite = wallpaper.id in favorites
    val downloading = action.busy && action.label?.startsWith("Downloading") == true
    val zoom = remember { Animatable(1.08f) }
    LaunchedEffect(Unit) { zoom.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }

    CompositionLocalProvider(LocalPalette provides DarkPalette, LocalContentColor provides Color.White) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { immersive = !immersive }
    ) {
        WallpaperImage(
            wallpaper.loadUrl, wallpaper.displayTitle,
            Modifier.fillMaxSize().graphicsLayer { scaleX = zoom.value; scaleY = zoom.value },
        )

        AnimatedVisibility(
            visible = !immersive,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(300)) + slideInVertically(tween(380, easing = FastOutSlowInEasing)) { -it },
            exit = fadeOut(tween(180)) + slideOutVertically(tween(220)) { -it },
        ) {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    Box(Modifier.size(36.dp).background(Color(0x99000000), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
                FavoriteButton(isFavorite, { vm.toggleFavorite(wallpaper.id) })
            }
        }

        AnimatedVisibility(
            visible = !immersive,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(300)) + slideInVertically(tween(420, easing = FastOutSlowInEasing)) { it / 2 },
            exit = fadeOut(tween(180)) + slideOutVertically(tween(240)) { it / 2 },
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6101010))))
                    .navigationBarsPadding()
                    .padding(start = 20.dp, end = 20.dp, top = 56.dp, bottom = 20.dp)
            ) {
                Text(wallpaper.displayTitle, style = MaterialTheme.typography.headlineSmall, maxLines = 2, modifier = Modifier.fadeSlideIn(60, 16.dp))
                Text(
                    buildString {
                        append(wallpaper.categoryLabel)
                        if (wallpaper.hasFourKTag) append(" · Tagged 4K")
                    },
                    color = WalliColors.TextSecondary,
                    modifier = Modifier.padding(top = 2.dp, bottom = 14.dp).fadeSlideIn(120, 16.dp),
                )
                if (action.busy && !downloading) {
                    Text(action.label.orEmpty(), color = WalliColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                    val p = action.progress
                    if (p != null) {
                        LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), color = WalliColors.Pink, trackColor = WalliColors.Border)
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), color = WalliColors.Pink, trackColor = WalliColors.Border)
                    }
                }
                val pct = action.progress?.let { (it * 100).toInt() }
                WalliButton(
                    label = if (downloading) (if (pct != null) "Downloading $pct%" else "Downloading…") else "Download",
                    onClick = { actions.download(wallpaper) },
                    modifier = Modifier.fillMaxWidth().fadeSlideIn(180, 20.dp),
                    icon = Icons.Outlined.Download,
                    loading = downloading,
                    progress = if (downloading) action.progress else null,
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fadeSlideIn(240, 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    WalliButton(
                        label = "Set Wallpaper",
                        onClick = { showSetDialog = true },
                        modifier = Modifier.weight(1.25f),
                        icon = Icons.Outlined.Image,
                        filled = false,
                        enabled = !action.busy,
                    )
                    WalliButton(
                        label = if (isFavorite) "Saved" else "Favorite",
                        onClick = { vm.toggleFavorite(wallpaper.id) },
                        modifier = Modifier.weight(1f),
                        icon = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        filled = false,
                    )
                }
            }
        }
    }
    }

    if (showSetDialog) {
        SetWallpaperSheet(
            onDismiss = { showSetDialog = false },
            onSelect = { target ->
                showSetDialog = false
                actions.setWallpaper(wallpaper, target)
            },
        )
    }
}

@Composable
private fun ImmersiveEffect(immersive: Boolean) {
    val view = LocalView.current
    val appIsDark = LocalPalette.current.isDark
    DisposableEffect(immersive) {
        val window = view.context.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        // The photo is always dark behind the bars: keep their icons light while previewing.
        controller?.isAppearanceLightStatusBars = false
        controller?.isAppearanceLightNavigationBars = false
        if (immersive) controller?.hide(WindowInsetsCompat.Type.systemBars())
        else controller?.show(WindowInsetsCompat.Type.systemBars())
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            controller?.isAppearanceLightStatusBars = !appIsDark
            controller?.isAppearanceLightNavigationBars = !appIsDark
        }
    }
}

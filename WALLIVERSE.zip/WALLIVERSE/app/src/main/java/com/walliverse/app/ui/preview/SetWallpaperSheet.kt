package com.walliverse.app.ui.preview

import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Smartphone
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.walliverse.app.ui.components.fadeSlideIn
import com.walliverse.app.ui.components.pressScale
import com.walliverse.app.ui.theme.WalliColors
import com.walliverse.app.util.WallpaperTarget
import kotlinx.coroutines.launch

/** In-app bottom sheet (replaces the system-looking dialog) for choosing where to apply a wallpaper. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetWallpaperSheet(onDismiss: () -> Unit, onSelect: (WallpaperTarget) -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    fun closeThen(action: () -> Unit) {
        scope.launch { sheetState.hide() }.invokeOnCompletion { action() }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = WalliColors.Surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = {
            Box(
                Modifier
                    .padding(top = 12.dp, bottom = 4.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .background(WalliColors.Border, RoundedCornerShape(2.dp))
            )
        },
    ) {
        Column(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Set as wallpaper", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.fadeSlideIn(0, 12.dp))
            Text(
                "Choose where to apply it. The full-resolution image is downloaded first.",
                color = WalliColors.TextSecondary,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 6.dp).fadeSlideIn(40, 12.dp),
            )
            TargetRow(Icons.Outlined.Home, "Home screen", "Behind your apps and widgets", 80) {
                closeThen { onSelect(WallpaperTarget.Home) }
            }
            TargetRow(Icons.Outlined.Lock, "Lock screen", "Shown when your phone is locked", 130) {
                closeThen { onSelect(WallpaperTarget.Lock) }
            }
            TargetRow(Icons.Outlined.Smartphone, "Both screens", "Use the same image everywhere", 180) {
                closeThen { onSelect(WallpaperTarget.Both) }
            }
            TextButton(onClick = { closeThen(onDismiss) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Cancel", color = WalliColors.TextSecondary)
            }
        }
    }
}

@Composable
private fun TargetRow(icon: ImageVector, title: String, subtitle: String, delayMs: Int, onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    Surface(
        onClick = onClick,
        interactionSource = source,
        shape = RoundedCornerShape(18.dp),
        color = WalliColors.Elevated,
        modifier = Modifier.fillMaxWidth().pressScale(source).fadeSlideIn(delayMs, 16.dp),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(WalliColors.Pink.copy(alpha = 0.16f), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = WalliColors.Pink)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, color = WalliColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = WalliColors.TextSecondary)
        }
    }
}

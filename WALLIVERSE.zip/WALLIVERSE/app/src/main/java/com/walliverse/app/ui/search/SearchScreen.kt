package com.walliverse.app.ui.search

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.components.CategoryChip
import com.walliverse.app.ui.components.EmptyState
import com.walliverse.app.ui.components.ErrorState
import com.walliverse.app.ui.components.LoadingGrid
import com.walliverse.app.ui.components.SearchField
import com.walliverse.app.ui.components.WallpaperGrid
import com.walliverse.app.ui.components.fullSpanItem
import com.walliverse.app.ui.theme.WalliColors

@Composable
fun SearchScreen(vm: AppViewModel, onBack: () -> Unit, onOpenWallpaper: (String) -> Unit) {
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val favorites by vm.favoriteIds.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val selected by vm.searchCategory.collectAsStateWithLifecycle()
    val results by vm.searchResults.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { if (vm.query.value.isEmpty()) focus.requestFocus() }
    val leave = { vm.clearSearch(); onBack() }
    BackHandler(onBack = leave)

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = leave) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            SearchField(query, { vm.query.value = it }, Modifier.weight(1f).padding(end = 12.dp), focus)
        }
        when {
            catalog.loading && catalog.items.isEmpty() -> LoadingGrid(Modifier.weight(1f))
            catalog.items.isEmpty() && catalog.error != null -> ErrorState(catalog.error.orEmpty(), vm::retry, Modifier.weight(1f))
            else -> {
                WallpaperGrid(
                    items = results,
                    favoriteIds = favorites,
                    onOpen = onOpenWallpaper,
                    onToggleFavorite = vm::toggleFavorite,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    header = {
                        fullSpanItem("chips") {
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                            ) {
                                item { CategoryChip("All", selected == null, { vm.searchCategory.value = null }) }
                                items(categories.size) { i ->
                                    val c = categories[i]
                                    CategoryChip(c.label, selected == c.key, { vm.searchCategory.value = c.key })
                                }
                            }
                        }
                        if (results.isEmpty()) {
                            fullSpanItem("empty") {
                                EmptyState(
                                    icon = Icons.Outlined.Search,
                                    title = "No results",
                                    message = if (query.isBlank()) "No wallpapers in this category." else "Nothing matches \"${query.trim()}\". Try a different title or category.",
                                    modifier = Modifier.height(320.dp),
                                )
                            }
                        } else {
                            fullSpanItem("count") {
                                Text("${results.size} results", color = WalliColors.TextSecondary, modifier = Modifier.padding(vertical = 4.dp))
                            }
                        }
                    },
                )
            }
        }
    }
}

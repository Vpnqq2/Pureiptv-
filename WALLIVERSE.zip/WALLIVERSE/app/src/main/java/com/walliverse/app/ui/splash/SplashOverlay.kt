package com.walliverse.app.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.walliverse.app.R
import com.walliverse.app.ui.components.Wordmark
import com.walliverse.app.ui.theme.WalliColors
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val SplashBackground = Color(0xFF0A0E22) // matches the system splash and the icon background

/**
 * Animated intro: the logo springs in with a slight tilt, a neon glow pulses behind it, the icon floats gently
 * and a light sweep glides across it, then the wordmark and tagline fade in.
 */
@Composable
fun SplashOverlay(onFinished: () -> Unit) {
    val intro = remember { Animatable(0f) }
    val text = remember { Animatable(0f) }
    val sweep = remember { Animatable(-0.5f) }
    val loop = rememberInfiniteTransition(label = "splashLoop")
    val pulse by loop.animateFloat(
        initialValue = 0.85f, targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    val bob by loop.animateFloat(
        initialValue = -6f, targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob",
    )

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { intro.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow)) }
            launch { delay(350); text.animateTo(1f, tween(500, easing = FastOutSlowInEasing)) }
            launch { delay(700); sweep.animateTo(1.5f, tween(900, easing = LinearEasing)) }
        }
        delay(500)
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(SplashBackground)
            .pointerInput(Unit) {
                awaitPointerEventScope { while (true) awaitPointerEvent().changes.forEach { it.consume() } }
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
                Canvas(
                    Modifier.fillMaxSize().graphicsLayer {
                        alpha = intro.value.coerceIn(0f, 1f)
                        scaleX = pulse
                        scaleY = pulse
                    }
                ) {
                    drawCircle(
                        Brush.radialGradient(
                            listOf(
                                WalliColors.Pink.copy(alpha = 0.35f),
                                Color(0xFF3D5AFE).copy(alpha = 0.18f),
                                Color.Transparent,
                            ),
                            center = center,
                            radius = size.minDimension / 2,
                        )
                    )
                }
                Image(
                    painter = painterResource(R.drawable.logo_art),
                    contentDescription = "WALLIVERSE logo",
                    modifier = Modifier
                        .size(160.dp)
                        .graphicsLayer {
                            val p = intro.value
                            alpha = p.coerceIn(0f, 1f)
                            scaleX = 0.6f + 0.4f * p
                            scaleY = 0.6f + 0.4f * p
                            rotationZ = (1f - p) * -10f
                            translationY = bob.dp.toPx() * p.coerceIn(0f, 1f)
                        }
                        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                        .drawWithContent {
                            drawContent()
                            val x = size.width * sweep.value
                            drawRect(
                                brush = Brush.linearGradient(
                                    listOf(Color.Transparent, Color.White.copy(alpha = 0.45f), Color.Transparent),
                                    start = Offset(x - size.width * 0.3f, 0f),
                                    end = Offset(x + size.width * 0.1f, size.height * 0.4f),
                                ),
                                blendMode = BlendMode.SrcAtop,
                            )
                        },
                )
            }
            Spacer(Modifier.height(20.dp))
            Wordmark(Modifier.graphicsLayer { alpha = text.value; translationY = (1f - text.value) * 24.dp.toPx() })
            Spacer(Modifier.height(8.dp))
            Text(
                "Infinite Wallpapers for Your World",
                color = WalliColors.TextSecondary,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = text.value * 0.9f },
            )
        }
    }
}

package com.walliverse.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

@Immutable
class WalliPalette(
    val background: Color,
    val surface: Color,
    val elevated: Color,
    val accent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val border: Color,
    /** Hairline around cards/inputs. Invisible in dark, subtle in light. */
    val cardBorder: Color,
    val isDark: Boolean,
)

val DarkPalette = WalliPalette(
    background = Color(0xFF101010),
    surface = Color(0xFF1B1B1B),
    elevated = Color(0xFF242424),
    accent = Color(0xFFFF2785),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFA8A8A8),
    border = Color(0xFF303030),
    cardBorder = Color.Transparent,
    isDark = true,
)

val LightPalette = WalliPalette(
    background = Color(0xFFF6F6F8),
    surface = Color(0xFFFFFFFF),
    elevated = Color(0xFFEDEDF1),
    accent = Color(0xFFDE0F69), // deeper pink: 4.8:1 against white, keeps text and icons readable
    textPrimary = Color(0xFF14141A),
    textSecondary = Color(0xFF6A6A75),
    border = Color(0xFFE1E1E8),
    cardBorder = Color(0xFFE6E6EC),
    isDark = false,
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

/** Theme-aware colours. Read these inside composable code; they follow the active light/dark palette. */
object WalliColors {
    val Background: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.background
    val Surface: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.surface
    val Elevated: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.elevated
    val Pink: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.accent
    val TextPrimary: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.textPrimary
    val TextSecondary: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.textSecondary
    val Border: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.border
    val CardBorder: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.cardBorder

    /** Text drawn on top of wallpaper photos / dark scrims: always light, in both themes. */
    val OnImage = Color.White
    val OnImageMuted = Color(0xCCFFFFFF)
}

private fun colorScheme(p: WalliPalette) = if (p.isDark) {
    darkColorScheme(
        primary = p.accent, onPrimary = Color.White,
        secondary = p.accent, onSecondary = Color.White,
        background = p.background, onBackground = p.textPrimary,
        surface = p.surface, onSurface = p.textPrimary,
        surfaceVariant = p.elevated, onSurfaceVariant = p.textSecondary,
        surfaceContainer = p.surface, surfaceContainerHigh = p.elevated, surfaceContainerHighest = p.elevated,
        outline = p.border, outlineVariant = p.border,
        inverseSurface = Color(0xFF2E2E2E), inverseOnSurface = Color.White, inversePrimary = p.accent,
        error = Color(0xFFFF5470),
    )
} else {
    lightColorScheme(
        primary = p.accent, onPrimary = Color.White,
        secondary = p.accent, onSecondary = Color.White,
        background = p.background, onBackground = p.textPrimary,
        surface = p.surface, onSurface = p.textPrimary,
        surfaceVariant = p.elevated, onSurfaceVariant = p.textSecondary,
        surfaceContainerLowest = p.surface, surfaceContainerLow = p.surface, surfaceContainer = p.surface,
        surfaceContainerHigh = p.elevated, surfaceContainerHighest = p.elevated,
        outline = p.border, outlineVariant = p.border,
        inverseSurface = Color(0xFF1F1F26), inverseOnSurface = Color.White, inversePrimary = Color(0xFFFF2785),
        error = Color(0xFFD32F4A),
    )
}

private val Base = Typography()
private val WalliTypography = Typography(
    headlineSmall = Base.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = Base.titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = Base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = Base.labelLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.3.sp),
)

@Composable
fun WalliverseTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    val palette = if (darkTheme) DarkPalette else LightPalette
    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(colorScheme = colorScheme(palette), typography = WalliTypography, content = content)
    }
}

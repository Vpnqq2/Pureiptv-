package com.walliverse.app.util

import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object NetworkErrors {
    fun describe(error: Throwable?): String = when (error) {
        null -> "Something went wrong."
        is UnknownHostException, is ConnectException -> "No internet connection. Check your network and try again."
        is SocketTimeoutException -> "The connection timed out. Please try again."
        is IOException -> {
            val m = error.message.orEmpty()
            when {
                m.contains("ENOSPC", true) || m.contains("space", true) -> "Not enough storage space on this device."
                m.startsWith("HTTP") -> "The server responded with an error ($m)."
                else -> "Network problem: ${m.ifEmpty { "unknown error" }}"
            }
        }
        else -> "Unexpected error: ${error.message ?: error::class.java.simpleName}"
    }
}

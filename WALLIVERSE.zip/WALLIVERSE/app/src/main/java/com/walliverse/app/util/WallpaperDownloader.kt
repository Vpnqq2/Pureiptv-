package com.walliverse.app.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.walliverse.app.core.AppConfig
import com.walliverse.app.data.model.Wallpaper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

sealed interface DownloadResult {
    data class Saved(val uri: Uri, val name: String) : DownloadResult
    data class AlreadyExists(val name: String) : DownloadResult
    data class Failed(val message: String) : DownloadResult
}

/**
 * Saves the original image into Pictures/WALLIVERSE through MediaStore (scoped storage, API 29+),
 * so no storage permission is needed. Success is reported only after the file is fully written.
 */
class WallpaperDownloader(
    private val context: Context,
    private val client: OkHttpClient,
) {
    private val relativePath = "Pictures/${AppConfig.DOWNLOAD_FOLDER}"

    suspend fun download(wallpaper: Wallpaper, onProgress: (Float?) -> Unit): DownloadResult =
        withContext(Dispatchers.IO) {
            val url = wallpaper.loadUrl
                ?: return@withContext DownloadResult.Failed("This wallpaper has an invalid image link.")
            val resolver = context.contentResolver
            var pending: Uri? = null
            try {
                client.newCall(Request.Builder().url(url).build()).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext DownloadResult.Failed("The server responded with HTTP ${response.code}.")
                    }
                    val body = response.body
                        ?: return@withContext DownloadResult.Failed("The server returned an empty response.")
                    val mime = body.contentType()?.let { "${it.type}/${it.subtype}" } ?: guessMime(url)
                    if (!mime.startsWith("image/")) {
                        return@withContext DownloadResult.Failed("The link did not return an image.")
                    }
                    val name = fileName(wallpaper, mime)
                    if (exists(name)) return@withContext DownloadResult.AlreadyExists(name)

                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, mime)
                        put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    val uri = resolver.insert(collection, values)
                        ?: return@withContext DownloadResult.Failed("Could not create the file on this device.")
                    pending = uri

                    val total = body.contentLength()
                    var written = 0L
                    var lastPercent = -1
                    onProgress(if (total > 0) 0f else null)
                    val out = resolver.openOutputStream(uri)
                        ?: return@withContext DownloadResult.Failed("Could not open the destination file.")
                    out.use { sink ->
                        body.byteStream().use { input ->
                            val buffer = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                sink.write(buffer, 0, n)
                                written += n
                                if (total > 0) {
                                    val percent = (written * 100 / total).toInt()
                                    if (percent != lastPercent) {
                                        lastPercent = percent
                                        onProgress(written.toFloat() / total)
                                    }
                                }
                            }
                            sink.flush()
                        }
                    }
                    if (total > 0 && written < total) {
                        resolver.delete(uri, null, null)
                        pending = null
                        return@withContext DownloadResult.Failed("The download was interrupted. Please try again.")
                    }
                    resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
                    pending = null
                    DownloadResult.Saved(uri, name)
                }
            } catch (e: CancellationException) {
                pending?.let { runCatching { resolver.delete(it, null, null) } }
                throw e
            } catch (e: Exception) {
                pending?.let { runCatching { resolver.delete(it, null, null) } }
                DownloadResult.Failed(NetworkErrors.describe(e))
            }
        }

    private fun exists(name: String): Boolean {
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        context.contentResolver.query(
            collection,
            arrayOf(MediaStore.Images.Media._ID),
            "${MediaStore.Images.Media.DISPLAY_NAME}=? AND ${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?",
            arrayOf(name, "$relativePath%"),
            null,
        )?.use { return it.count > 0 }
        return false
    }

    private fun fileName(w: Wallpaper, mime: String): String {
        val ext = when (mime) {
            "image/jpeg", "image/jpg" -> "jpg"
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/gif" -> "gif"
            "image/heic" -> "heic"
            else -> mime.substringAfter('/').ifEmpty { "img" }
        }
        val base = w.displayTitle.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(40)
            .ifEmpty { w.categoryKey.replace(Regex("[^a-z0-9]+"), "_") }
        return "walliverse_${base}_${w.id.replace(Regex("[^A-Za-z0-9_-]"), "")}.$ext"
    }

    private fun guessMime(url: String): String {
        val path = url.substringBefore('?').lowercase()
        return when {
            path.endsWith(".png") -> "image/png"
            path.endsWith(".webp") -> "image/webp"
            path.endsWith(".gif") -> "image/gif"
            path.endsWith(".jpg") || path.endsWith(".jpeg") -> "image/jpeg"
            else -> "application/octet-stream"
        }
    }
}

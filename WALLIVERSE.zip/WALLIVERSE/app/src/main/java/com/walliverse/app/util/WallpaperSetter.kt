package com.walliverse.app.util

import android.app.WallpaperManager
import android.content.Context
import com.walliverse.app.data.model.Wallpaper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.IOException

enum class WallpaperTarget(val label: String, val flags: Int) {
    Home("Home screen", WallpaperManager.FLAG_SYSTEM),
    Lock("Lock screen", WallpaperManager.FLAG_LOCK),
    Both("Home and lock screen", WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK),
}

sealed interface SetResult {
    data object Success : SetResult
    data class Failed(val message: String) : SetResult
}

/** Downloads the full-resolution original and hands the untouched stream to WallpaperManager. */
class WallpaperSetter(
    private val context: Context,
    private val client: OkHttpClient,
) {
    suspend fun set(wallpaper: Wallpaper, target: WallpaperTarget, onProgress: (Float?) -> Unit): SetResult =
        withContext(Dispatchers.IO) {
            val url = wallpaper.loadUrl
                ?: return@withContext SetResult.Failed("This wallpaper has an invalid image link.")
            val manager = WallpaperManager.getInstance(context)
            if (!manager.isWallpaperSupported) {
                return@withContext SetResult.Failed("This device does not support changing the wallpaper.")
            }
            if (!manager.isSetWallpaperAllowed) {
                return@withContext SetResult.Failed("Changing the wallpaper is restricted on this device.")
            }
            val dir = File(context.cacheDir, TEMP_DIR).apply { mkdirs() }
            val tmp = File(dir, "wp_${wallpaper.id.replace(Regex("[^A-Za-z0-9_-]"), "")}.tmp")
            try {
                fetch(url, tmp, onProgress)
                onProgress(null)
                FileInputStream(tmp).use { input ->
                    manager.setStream(input, null, true, target.flags)
                }
                SetResult.Success
            } catch (e: CancellationException) {
                throw e
            } catch (e: OutOfMemoryError) {
                SetResult.Failed("This image is too large for the device to set as a wallpaper.")
            } catch (e: Exception) {
                SetResult.Failed(NetworkErrors.describe(e))
            } finally {
                tmp.delete()
            }
        }

    private fun fetch(url: String, dest: File, onProgress: (Float?) -> Unit) {
        client.newCall(Request.Builder().url(url).build()).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            val body = response.body ?: throw IOException("Empty response")
            val total = body.contentLength()
            var written = 0L
            var lastPercent = -1
            onProgress(if (total > 0) 0f else null)
            dest.outputStream().use { out ->
                body.byteStream().use { input ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        written += n
                        if (total > 0) {
                            val percent = (written * 100 / total).toInt()
                            if (percent != lastPercent) {
                                lastPercent = percent
                                onProgress(written.toFloat() / total)
                            }
                        }
                    }
                }
            }
            if (total > 0 && written < total) throw IOException("The download was interrupted")
        }
    }

    companion object {
        const val TEMP_DIR = "wallpaper_tmp"
    }
}

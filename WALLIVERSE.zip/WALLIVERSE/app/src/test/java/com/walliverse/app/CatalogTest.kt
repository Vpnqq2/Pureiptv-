package com.walliverse.app

import com.walliverse.app.data.model.Wallpaper
import com.walliverse.app.domain.Catalog
import com.walliverse.app.domain.SortOrder
import org.junit.Assert.assertEquals
import org.junit.Test

class CatalogTest {
    private fun w(id: String, title: String, cat: String, url: String? = "https://a.example/$id.jpg") =
        Wallpaper(id, title, cat, url.orEmpty(), url)

    private val items = listOf(
        w("1", "Mountains", "Nature"),
        w("2", "Forest", " nature "),
        w("3", "Red Car", "Car"),
        w("4", "unknown", "sports"),
        w("5", "4k", ""),
    )

    @Test fun categoriesMergeCaseAndWhitespaceWithoutAlteringOriginals() {
        val cats = Catalog.categories(items)
        val nature = cats.first { it.key == "nature" }
        assertEquals(2, nature.count)
        assertEquals(" nature ", items[1].category)
        assertEquals(setOf("nature", "car", "sports", "other"), cats.map { it.key }.toSet())
    }

    @Test fun categoryCoverSkipsBrokenLinks() {
        val list = listOf(w("1", "a", "X", null), w("2", "b", "X"))
        assertEquals("2", Catalog.categories(list).single().cover.id)
    }

    @Test fun filterByCategoryAndAll() {
        assertEquals(2, Catalog.filterByCategory(items, "nature").size)
        assertEquals(5, Catalog.filterByCategory(items, Catalog.ALL_KEY).size)
        assertEquals(5, Catalog.filterByCategory(items, null).size)
    }

    @Test fun searchMatchesTitleAndCategoryCaseInsensitively() {
        assertEquals(listOf("3"), Catalog.search(items, "RED").map { it.id })
        assertEquals(listOf("1", "2"), Catalog.search(items, "nature").map { it.id })
        assertEquals(listOf("2"), Catalog.search(items, "nature forest").map { it.id })
        assertEquals(emptyList<String>(), Catalog.search(items, "zzz").map { it.id })
        assertEquals(5, Catalog.search(items, "   ").size)
    }

    @Test fun sortOrders() {
        assertEquals(listOf("5", "4", "3", "2", "1"), Catalog.sort(items, SortOrder.Latest).map { it.id })
        assertEquals(listOf("1", "2", "3", "4", "5"), Catalog.sort(items, SortOrder.Oldest).map { it.id })
        assertEquals("5", Catalog.sort(items, SortOrder.TitleAZ).first().id)
    }

    @Test fun randomFeaturedSpreadsAcrossCategoriesAndSkipsBrokenLinks() {
        val many = (1..30).map { w(it.toString(), "t$it", listOf("A", "B", "C", "D")[it % 4], if (it % 7 == 0) null else "https://a.example/$it.jpg") }
        val picks = Catalog.randomFeatured(many, count = 4, random = kotlin.random.Random(42))
        assertEquals(4, picks.size)
        assertEquals(4, picks.map { it.categoryKey }.toSet().size)
        assertEquals(true, picks.all { it.loadUrl != null })
        // different seeds give different slideshows
        val other = Catalog.randomFeatured(many, count = 4, random = kotlin.random.Random(7))
        assertEquals(false, picks.map { it.id } == other.map { it.id })
    }

    @Test fun randomFeaturedWithFewItemsReturnsAllUsable() {
        val few = listOf(w("1", "a", "X"), w("2", "b", "X", null))
        assertEquals(listOf("1"), Catalog.randomFeatured(few, count = 6).map { it.id })
    }
}

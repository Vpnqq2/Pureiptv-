package com.walliverse.app

import com.walliverse.app.data.remote.WallpaperParser
import kotlinx.serialization.SerializationException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.assertThrows
import org.junit.Test

class WallpaperParserTest {

    private val sample = """
        [
          {"id":"1","title":"4k","category":"Other","imageUrl":"https://raw.githubusercontent.com/qatarvpn/pngm/refs/heads/main/4k1.jpeg"},
          {"id":"383","title":"Mountains","category":"Nature","imageUrl":"https://raw.githubusercontent.com/qatarvpn/pngm/refs/heads/main/Fallen Leaves.jpg"},
          {"id":"406","title":"\u010cesk\u00fd Krumlov","category":"Cities","imageUrl":"https://raw.githubusercontent.com/qatarvpn/pngm/refs/heads/main/\u010cesk\u00fd Krumlov.jpg"},
          {"id":"487","title":"","category":"Car","imageUrl":"https://raw.githubusercontent.com/qatarvpn/pngm/refs/heads/main/cr1.jpeg"},
          {"id":"192","title":"unknown","category":"sports","imageUrl":"https://raw.githubusercontent.com/qatarvpn/pngm/refs/heads/main/sprt1.jpeg"}
        ]
    """.trimIndent()

    @Test fun parsesAllRecordsAndKeepsOriginalFields() {
        val list = WallpaperParser.parse(sample)
        assertEquals(5, list.size)
        assertEquals("1", list[0].id)
        assertEquals("4k", list[0].title)
        assertEquals("Other", list[0].category)
        assertTrue(list[0].hasFourKTag)
        assertEquals("https://raw.githubusercontent.com/qatarvpn/pngm/refs/heads/main/Fallen Leaves.jpg", list[1].imageUrl)
    }

    @Test fun encodesSpacesAndUnicodeInImageUrls() {
        val list = WallpaperParser.parse(sample)
        assertTrue(list[1].loadUrl!!.contains("Fallen%20Leaves.jpg"))
        assertNotNull(list[2].loadUrl)
        assertTrue(!list[2].loadUrl!!.contains(" "))
    }

    @Test fun handlesMissingAndUnknownTitles() {
        val list = WallpaperParser.parse(sample)
        assertEquals("Car #487", list[3].displayTitle)
        assertEquals("Sports #192", list[4].displayTitle)
        assertEquals("", list[3].title) // original untouched
    }

    @Test fun missingMetadataDoesNotCrash() {
        val json = """[{"imageUrl":"https://a.example/x.png"},{"id":7},{"id":"9","title":null,"category":null,"imageUrl":null}, 42, "x"]"""
        val list = WallpaperParser.parse(json)
        assertEquals(3, list.size)
        assertEquals("item_1", list[0].id)
        assertEquals("7", list[1].id)
        assertNull(list[1].loadUrl)
        assertEquals("other", list[2].categoryKey)
    }

    @Test fun invalidAndInsecureUrlsAreFlaggedNotDropped() {
        val json = """[{"id":"1","imageUrl":"not a url"},{"id":"2","imageUrl":"http://insecure.example/a.jpg"},{"id":"3","imageUrl":""}]"""
        val list = WallpaperParser.parse(json)
        assertEquals(3, list.size)
        assertTrue(list.all { it.loadUrl == null })
    }

    @Test fun duplicateIdsAreMadeUnique() {
        val list = WallpaperParser.parse("""[{"id":"1","imageUrl":"https://a.example/1.jpg"},{"id":"1","imageUrl":"https://a.example/2.jpg"}]""")
        assertEquals(2, list.map { it.id }.toSet().size)
        assertEquals("1", list[0].id)
    }

    @Test fun malformedJsonThrows() {
        assertThrows(SerializationException::class.java) { WallpaperParser.parse("{ not json") }
        assertThrows(SerializationException::class.java) { WallpaperParser.parse("\"just a string\"") }
    }
}

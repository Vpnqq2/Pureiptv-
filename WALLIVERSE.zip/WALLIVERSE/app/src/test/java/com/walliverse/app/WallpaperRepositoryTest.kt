package com.walliverse.app

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.walliverse.app.data.local.CatalogCache
import com.walliverse.app.data.local.FavoritesStore
import com.walliverse.app.data.remote.CatalogSource
import com.walliverse.app.data.repository.WallpaperRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException

private const val JSON = """[{"id":"1","title":"a","category":"Nature","imageUrl":"https://a.example/1.jpg"},{"id":"2","title":"b","category":"Car","imageUrl":"https://a.example/2.jpg"}]"""

private class FakeSource(var result: () -> String) : CatalogSource {
    var calls = 0
    override suspend fun fetch(): String { calls++; return result() }
}

private class FakeCache(var stored: String? = null) : CatalogCache {
    override suspend fun read() = stored
    override suspend fun write(json: String) { stored = json }
}

class WallpaperRepositoryTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun favorites(scope: CoroutineScope, name: String = "fav.preferences_pb") =
        FavoritesStore(PreferenceDataStoreFactory.create(scope = scope) { File(tmp.root, name) })

    @Test fun successParsesCachesAndServesFromMemory() = runBlocking {
        val source = FakeSource { JSON }
        val cache = FakeCache()
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        val repo = WallpaperRepository(source, cache, favorites(scope))
        val r = repo.load()
        assertEquals(2, r.items.size); assertNull(r.error); assertFalse(r.fromCache)
        assertNotNull(cache.stored)
        repo.load()
        assertEquals(1, source.calls) // second call came from memory
        repo.load(forceRefresh = true)
        assertEquals(2, source.calls)
        scope.coroutineContext[Job]!!.cancel()
    }

    @Test fun networkFailureFallsBackToDiskCache() = runBlocking {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        val repo = WallpaperRepository(FakeSource { throw IOException("offline") }, FakeCache(JSON), favorites(scope))
        val r = repo.load()
        assertEquals(2, r.items.size); assertTrue(r.fromCache); assertNotNull(r.error)
        scope.coroutineContext[Job]!!.cancel()
    }

    @Test fun failureWithoutCacheReturnsError() = runBlocking {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        val repo = WallpaperRepository(FakeSource { throw IOException("offline") }, FakeCache(), favorites(scope))
        val r = repo.load()
        assertTrue(r.items.isEmpty()); assertNotNull(r.error); assertFalse(r.fromCache)
        scope.coroutineContext[Job]!!.cancel()
    }

    @Test fun malformedRemoteJsonFallsBackToCache() = runBlocking {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        val repo = WallpaperRepository(FakeSource { "{ broken" }, FakeCache(JSON), favorites(scope))
        val r = repo.load()
        assertEquals(2, r.items.size); assertTrue(r.fromCache)
        scope.coroutineContext[Job]!!.cancel()
    }

    @Test fun favoritesPersistAcrossStoreInstances() = runBlocking {
        val job1 = Job()
        val store1 = favorites(CoroutineScope(job1 + Dispatchers.IO), "persist.preferences_pb")
        store1.toggle("1"); store1.toggle("2"); store1.toggle("2")
        assertEquals(setOf("1"), store1.favoriteIds.first())
        job1.cancel(); job1.join()

        val job2 = Job()
        val store2 = favorites(CoroutineScope(job2 + Dispatchers.IO), "persist.preferences_pb")
        assertEquals(setOf("1"), store2.favoriteIds.first())
        job2.cancel()
    }
}

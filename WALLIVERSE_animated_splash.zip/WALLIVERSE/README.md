# WALLIVERSE

Native Android wallpaper app — Kotlin, Jetpack Compose (Material 3), MVVM, Coroutines/Flow, OkHttp, Coil, DataStore.
AMOLED black (#101010) with neon-pink (#FF2785) accents. No accounts, no ads, no premium tier.

## Status — please read
This project was generated **without an Android SDK or network access**, so it has **not been compiled, run or tested yet**.
Expect to fix a few compile errors on the first build (typically a missing import or an API-version mismatch).
Nothing below is claimed as "verified on a device".

## Data source
`app/src/main/java/com/walliverse/app/core/AppConfig.kt`
```kotlin
const val WALLPAPERS_JSON_URL = "https://raw.githubusercontent.com/qatarvpn/pngm/refs/heads/main/wallpapers.json"
```
Change that single constant to point at a different RAW JSON file. The JSON is fetched at runtime (never bundled),
cached to disk after the first success, and used offline afterwards.

Schema handled: array of `{ id, title, category, imageUrl }`. Missing/null fields, numeric ids, duplicate ids, empty
titles, `"unknown"` titles, spaces / non-ASCII characters in URLs and non-https URLs are all handled without dropping records.
Original values are never modified; display values are derived.

Snapshot of the live file when this project was written: 590 records, 10 categories
(Other, sports, Nature, Cities, Dark, Space, Vintage, Car, Animals, Blur).

## Build
1. Open the `WALLIVERSE` folder in Android Studio (Ladybug or newer, JDK 17). It syncs Gradle and creates the wrapper;
   or run `gradle wrapper --gradle-version 8.9` once, then `./gradlew assembleDebug`.
2. Run on a device/emulator with Android 10+ (minSdk 29, targetSdk 35).

Checks:
```
./gradlew testDebugUnitTest          # parser, categories, search, repository, favorites persistence
./gradlew connectedDebugAndroidTest  # Compose UI state tests (needs a device)
```

## Signed release (APK / AAB)
```
keytool -genkeypair -v -keystore walliverse.jks -alias walliverse -keyalg RSA -keysize 2048 -validity 10000
```
Create `keystore.properties` in the project root (git-ignored):
```
storeFile=walliverse.jks
storePassword=...
keyAlias=walliverse
keyPassword=...
```
Then `./gradlew assembleRelease` (APK) or `./gradlew bundleRelease` (AAB, for Google Play). Outputs are under `app/build/outputs/`.

## Features and how they work
- **Home**: wordmark, search entry, sort menu (latest / oldest / title / category), Featured pager (one card per category, no
  popularity claims), responsive grid with incremental rendering (40 per page), pull-to-refresh.
- **Search**: debounced local search over title + category, category chips, clear button, empty state.
- **Categories**: derived from the JSON (case/whitespace-insensitive grouping), cover thumbnails, per-category counts, "All".
- **Preview**: full-bleed image, tap to hide/show UI and system bars, Favorite, Download, Set as Wallpaper.
- **Download**: MediaStore → `Pictures/WALLIVERSE`, no storage permission (scoped storage). Progress shown; success reported only
  after the file is fully written; interrupted/failed downloads are deleted; duplicate names are detected.
- **Set wallpaper**: downloads the original to cache, then `WallpaperManager.setStream` for Home / Lock / Both. Restricted or
  unsupported devices produce a clear message.
- **Favorites**: DataStore set of stable wallpaper ids, synced across all screens.
- **More**: clear image cache, clear temp files, privacy policy link (`AppConfig.PRIVACY_POLICY_URL`, blank = "not configured"),
  licenses, share, version.

## Deliberate omissions (not faked)
- No language picker or notification toggle (no localization / notifications implemented).
- No theme switch: AMOLED dark is the only theme.
- The mockup's "Collections", "Downloads" and drawer menu are not implemented; "More" is the Settings screen.
- No resolution or popularity metadata is shown, since the JSON has none. A "4K" badge appears only when a record's title is literally "4k".

## Known risks to check on first run
- Some image hosts (e.g. wallpaperaccess.com) may block hot-linking; those cards show the "Image unavailable" fallback.
- Pink (#FF2785) with white text is ~3.6:1 contrast: fine for bold/large text, borderline for small text.

## Ads (AdMob)
- **Interstitial** when Download is tapped (the download keeps running underneath) and after a wallpaper is successfully applied.
- **App Open** after the intro splash and whenever the app returns from the background.
- Debug builds always use Google's *test* ad units. Release builds read your real ids from `gradle.properties`
  (`ADMOB_APP_ID`, `ADMOB_INTERSTITIAL_ID`, `ADMOB_APP_OPEN_ID`), already filled in; blank ids disable ads.
- Frequency caps: `INTERSTITIAL_COOLDOWN_MS` (30 s) and `APP_OPEN_COOLDOWN_MS` (60 s) in `AppConfig.kt`. Set to `0L` to remove the cap.
- Before publishing: add Google's UMP consent flow for EEA/UK users, declare ads + Advertising ID in Play Console, and never tap your own live ads.

Package name (applicationId): `com.black.wallv2`. Without a `keystore.properties`, release builds are signed with the debug key (fine for sideloading, not for Google Play).

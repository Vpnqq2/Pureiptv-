package com.walliverse.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.walliverse.app.navigation.WalliverseNavHost
import com.walliverse.app.ui.ActionsViewModel
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.splash.SplashOverlay
import com.walliverse.app.ui.theme.WalliverseTheme

class MainActivity : ComponentActivity() {
    private val container by lazy { (application as WalliverseApp).container }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen() // system splash (same colour as the in-app intro, so the hand-off is seamless)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            WalliverseTheme {
                val appVm: AppViewModel = viewModel(
                    factory = viewModelFactory { initializer { AppViewModel(container.repository) } }
                )
                val actionsVm: ActionsViewModel = viewModel(
                    factory = viewModelFactory {
                        initializer { ActionsViewModel(container.downloader, container.setter) }
                    }
                )
                var splashDone by rememberSaveable { mutableStateOf(false) }
                Box(Modifier.fillMaxSize()) {
                    WalliverseNavHost(appVm, actionsVm, container.ads)
                    AnimatedVisibility(visible = !splashDone, exit = fadeOut(tween(450))) {
                        SplashOverlay(onFinished = {
                            splashDone = true
                            container.ads.showAppOpenIfAvailable()
                        })
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        container.ads.attach(this)
    }

    override fun onStop() {
        container.ads.detach(this)
        super.onStop()
    }
}

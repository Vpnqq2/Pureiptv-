package com.walliverse.app.domain

import com.walliverse.app.data.model.Wallpaper
import java.util.Locale

data class CategoryInfo(
    val key: String,
    val label: String,
    val count: Int,
    val cover: Wallpaper,
)

enum class SortOrder(val label: String) {
    Latest("Latest first"),
    Oldest("Oldest first"),
    TitleAZ("Title A–Z"),
    Category("By category"),
}

/** Pure functions over the loaded list (easy to unit test). */
object Catalog {
    const val ALL_KEY = "all"

    /** Categories are grouped case-/whitespace-insensitively; original values stay on the records. */
    fun categories(items: List<Wallpaper>): List<CategoryInfo> =
        items.groupBy { it.categoryKey }
            .map { (key, group) ->
                CategoryInfo(
                    key = key,
                    label = group.first().categoryLabel,
                    count = group.size,
                    cover = group.firstOrNull { it.loadUrl != null } ?: group.first(),
                )
            }
            .sortedWith(compareByDescending<CategoryInfo> { it.count }.thenBy { it.label })

    fun filterByCategory(items: List<Wallpaper>, key: String?): List<Wallpaper> =
        if (key == null || key == ALL_KEY) items else items.filter { it.categoryKey == key }

    fun search(items: List<Wallpaper>, query: String): List<Wallpaper> {
        val tokens = query.trim().lowercase(Locale.ROOT).split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return items
        return items.filter { w -> tokens.all { w.searchText.contains(it) } }
    }

    fun sort(items: List<Wallpaper>, order: SortOrder): List<Wallpaper> = when (order) {
        SortOrder.Latest -> items.sortedByDescending { it.numericId }
        SortOrder.Oldest -> items.sortedBy { it.numericId }
        SortOrder.TitleAZ -> items.sortedBy { it.displayTitle.lowercase(Locale.ROOT) }
        SortOrder.Category -> items.sortedWith(
            compareBy<Wallpaper> { it.categoryKey }.thenByDescending { it.numericId }
        )
    }
}

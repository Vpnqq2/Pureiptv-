package com.walliverse.app.navigation

import android.net.Uri
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.walliverse.app.ads.AdManager
import com.walliverse.app.ui.ActionsViewModel
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.categories.CategoriesScreen
import com.walliverse.app.ui.categories.CategoryScreen
import com.walliverse.app.ui.favorites.FavoritesScreen
import com.walliverse.app.ui.home.HomeScreen
import com.walliverse.app.ui.preview.PreviewScreen
import com.walliverse.app.ui.search.SearchScreen
import com.walliverse.app.ui.settings.MoreScreen
import com.walliverse.app.ui.theme.WalliColors
import kotlinx.coroutines.launch

object Routes {
    const val Home = "home"
    const val Categories = "categories"
    const val Favorites = "favorites"
    const val More = "more"
    const val Search = "search"
    const val Category = "category/{key}"
    const val Preview = "preview/{id}"

    fun category(key: String) = "category/${Uri.encode(key)}"
    fun preview(id: String) = "preview/${Uri.encode(id)}"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab(Routes.Home, "Home", Icons.Outlined.Home),
    Tab(Routes.Categories, "Categories", Icons.Outlined.GridView),
    Tab(Routes.Favorites, "Favorites", Icons.Outlined.FavoriteBorder),
    Tab(Routes.More, "More", Icons.Outlined.Menu),
)

@Composable
fun WalliverseNavHost(vm: AppViewModel, actions: ActionsViewModel, ads: AdManager) {
    val nav = rememberNavController()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val showMessage: (String) -> Unit = { msg -> scope.launch { snackbar.showSnackbar(msg) } }

    LaunchedEffect(actions) { actions.messages.collect { snackbar.showSnackbar(it) } }
    LaunchedEffect(actions) { actions.adEvents.collect { ads.showInterstitial() } }

    val entry by nav.currentBackStackEntryAsState()
    val currentRoute = entry?.destination?.route
    val showBar = Tabs.any { it.route == currentRoute }

    Scaffold(
        containerColor = WalliColors.Background,
        contentWindowInsets = WindowInsets(0),
        snackbarHost = { SnackbarHost(snackbar, Modifier.navigationBarsPadding()) },
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = WalliColors.Background) {
                    Tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                if (currentRoute != tab.route) {
                                    nav.navigate(tab.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                val active = currentRoute == tab.route
                                val s by animateFloatAsState(
                                    if (active) 1.2f else 1f,
                                    spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                                    label = "tabIcon",
                                )
                                Icon(tab.icon, contentDescription = null, modifier = Modifier.graphicsLayer { scaleX = s; scaleY = s })
                            },
                            label = { Text(tab.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = WalliColors.Pink,
                                selectedTextColor = WalliColors.Pink,
                                indicatorColor = Color.Transparent,
                                unselectedIconColor = WalliColors.TextSecondary,
                                unselectedTextColor = WalliColors.TextSecondary,
                            ),
                        )
                    }
                }
            }
        },
    ) { inner ->
        NavHost(
            navController = nav,
            startDestination = Routes.Home,
            modifier = Modifier.padding(inner),
            enterTransition = { fadeIn(tween(220)) },
            exitTransition = { fadeOut(tween(160)) },
            popEnterTransition = { fadeIn(tween(220)) },
            popExitTransition = { fadeOut(tween(160)) },
        ) {
            composable(Routes.Home) {
                HomeScreen(
                    vm,
                    onOpenWallpaper = { nav.open(Routes.preview(it)) },
                    onOpenSearch = { nav.open(Routes.Search) },
                    onOpenCategory = { nav.open(Routes.category(it)) },
                )
            }
            composable(Routes.Categories) {
                CategoriesScreen(vm, onOpenCategory = { nav.open(Routes.category(it)) })
            }
            composable(Routes.Favorites) {
                FavoritesScreen(vm, onOpenWallpaper = { nav.open(Routes.preview(it)) })
            }
            composable(Routes.More) { MoreScreen(onMessage = showMessage) }
            composable(
                Routes.Search,
                enterTransition = { slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { it / 5 } + fadeIn(tween(320)) },
                exitTransition = { fadeOut(tween(200)) },
                popEnterTransition = { fadeIn(tween(250)) },
                popExitTransition = { slideOutHorizontally(tween(280)) { it / 5 } + fadeOut(tween(250)) },
            ) {
                SearchScreen(vm, onBack = { nav.popBackStack() }, onOpenWallpaper = { nav.open(Routes.preview(it)) })
            }
            composable(
                Routes.Category,
                arguments = listOf(navArgument("key") { type = NavType.StringType }),
                enterTransition = { slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { it / 5 } + fadeIn(tween(320)) },
                exitTransition = { fadeOut(tween(200)) },
                popEnterTransition = { fadeIn(tween(250)) },
                popExitTransition = { slideOutHorizontally(tween(280)) { it / 5 } + fadeOut(tween(250)) },
            ) { e ->
                val key = Uri.decode(e.arguments?.getString("key").orEmpty())
                CategoryScreen(vm, key, onBack = { nav.popBackStack() }, onOpenWallpaper = { nav.open(Routes.preview(it)) })
            }
            composable(
                Routes.Preview,
                arguments = listOf(navArgument("id") { type = NavType.StringType }),
                enterTransition = { fadeIn(tween(300)) + scaleIn(tween(350, easing = FastOutSlowInEasing), initialScale = 0.92f) },
                exitTransition = { fadeOut(tween(200)) },
                popEnterTransition = { fadeIn(tween(250)) },
                popExitTransition = { fadeOut(tween(250)) + scaleOut(tween(300), targetScale = 0.94f) },
            ) { e ->
                val id = Uri.decode(e.arguments?.getString("id").orEmpty())
                PreviewScreen(vm, actions, id, onBack = { nav.popBackStack() })
            }
        }
    }
}

/** Avoids duplicate screen instances when a destination is tapped twice. */
private fun NavController.open(route: String) = navigate(route) { launchSingleTop = true }

package com.walliverse.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.walliverse.app.data.model.Wallpaper
import com.walliverse.app.data.repository.WallpaperRepository
import com.walliverse.app.domain.Catalog
import com.walliverse.app.domain.CategoryInfo
import com.walliverse.app.domain.SortOrder
import com.walliverse.app.util.NetworkErrors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CatalogState(
    val loading: Boolean = true,
    val refreshing: Boolean = false,
    val items: List<Wallpaper> = emptyList(),
    val error: String? = null,
    /** Network failed but saved data is being shown. */
    val fromCache: Boolean = false,
)

@OptIn(FlowPreview::class)
class AppViewModel(private val repo: WallpaperRepository) : ViewModel() {

    private val _catalog = MutableStateFlow(CatalogState())
    val catalog: StateFlow<CatalogState> = _catalog.asStateFlow()

    val favoriteIds: StateFlow<Set<String>> =
        repo.favoriteIds.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private val items = _catalog.map { it.items }.distinctUntilChanged()

    val sort = MutableStateFlow(SortOrder.Latest)

    val homeItems: StateFlow<List<Wallpaper>> = combine(items, sort) { list, order -> Catalog.sort(list, order) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val categories: StateFlow<List<CategoryInfo>> = items
        .map { Catalog.categories(it) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- search ----
    val query = MutableStateFlow("")
    val searchCategory = MutableStateFlow<String?>(null)

    val searchResults: StateFlow<List<Wallpaper>> = combine(
        items,
        query.debounce { if (it.isEmpty()) 0L else 250L }.distinctUntilChanged(),
        searchCategory,
    ) { list, q, cat -> Catalog.search(Catalog.filterByCategory(list, cat), q) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var loadJob: Job? = null

    init {
        load(force = false)
    }

    fun refresh() = load(force = true)
    fun retry() = load(force = true)

    private fun load(force: Boolean) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _catalog.update { it.copy(loading = it.items.isEmpty(), refreshing = it.items.isNotEmpty(), error = null) }
            val result = repo.load(force)
            _catalog.value = CatalogState(
                loading = false,
                refreshing = false,
                items = result.items,
                error = if (result.items.isEmpty() && result.error != null) NetworkErrors.describe(result.error) else null,
                fromCache = result.fromCache,
            )
        }
    }

    fun toggleFavorite(id: String) {
        viewModelScope.launch { repo.toggleFavorite(id) }
    }

    fun setSort(order: SortOrder) {
        sort.value = order
    }

    fun clearSearch() {
        query.value = ""
        searchCategory.value = null
    }
}

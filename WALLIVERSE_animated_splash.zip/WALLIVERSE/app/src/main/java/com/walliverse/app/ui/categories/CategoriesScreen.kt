package com.walliverse.app.ui.categories

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import com.walliverse.app.ui.components.fadeSlideIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.walliverse.app.domain.Catalog
import com.walliverse.app.domain.CategoryInfo
import com.walliverse.app.ui.AppViewModel
import com.walliverse.app.ui.components.EmptyState
import com.walliverse.app.ui.components.ErrorState
import com.walliverse.app.ui.components.LoadingGrid
import com.walliverse.app.ui.components.WallpaperGrid
import com.walliverse.app.ui.components.WallpaperImage
import com.walliverse.app.ui.components.shimmer
import com.walliverse.app.ui.theme.WalliColors

@Composable
fun CategoriesScreen(vm: AppViewModel, onOpenCategory: (String) -> Unit) {
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Categories", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.fadeSlideIn(0, 16.dp).padding(16.dp))
        when {
            catalog.loading && catalog.items.isEmpty() -> LoadingGrid(Modifier.weight(1f))
            catalog.items.isEmpty() && catalog.error != null -> ErrorState(catalog.error.orEmpty(), vm::retry, Modifier.weight(1f))
            categories.isEmpty() -> EmptyState(Icons.Outlined.Image, "No categories", "Categories appear once wallpapers load.", Modifier.weight(1f))
            else -> {
                val all = catalog.items.firstOrNull { it.loadUrl != null }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (all != null) {
                        item(key = "all") {
                            CategoryCard("All", catalog.items.size, all.loadUrl, Modifier.fadeSlideIn(0, 32.dp)) { onOpenCategory(Catalog.ALL_KEY) }
                        }
                    }
                    itemsIndexed(categories, key = { _, c -> c.key }) { i, info: CategoryInfo ->
                        CategoryCard(info.label, info.count, info.cover.loadUrl, Modifier.fadeSlideIn((i + 1).coerceAtMost(8) * 55, 32.dp)) { onOpenCategory(info.key) }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryCard(label: String, count: Int, coverUrl: String?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .aspectRatio(1.1f)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClickLabel = "Open $label", onClick = onClick)
    ) {
        WallpaperImage(coverUrl, "$label category cover", Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC101010)))))
        Row(
            Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text("$count wallpapers", color = WalliColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Color.White)
        }
    }
}

/** Wallpapers of one category (key == "all" shows everything). */
@Composable
fun CategoryScreen(vm: AppViewModel, key: String, onBack: () -> Unit, onOpenWallpaper: (String) -> Unit) {
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val favorites by vm.favoriteIds.collectAsStateWithLifecycle()
    val list = remember(catalog.items, key) { Catalog.filterByCategory(catalog.items, key) }
    val title = if (key == Catalog.ALL_KEY) "All" else categories.firstOrNull { it.key == key }?.label ?: key.replaceFirstChar { it.uppercase() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Column {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text("${list.size} wallpapers", color = WalliColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
        }
        when {
            catalog.loading && catalog.items.isEmpty() -> LoadingGrid(Modifier.weight(1f))
            list.isEmpty() -> EmptyState(Icons.Outlined.Image, "Nothing here", "No wallpapers in this category.", Modifier.weight(1f))
            else -> WallpaperGrid(list, favorites, onOpenWallpaper, vm::toggleFavorite, Modifier.weight(1f))
        }
    }
}

package com.walliverse.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.delay
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.BrokenImage
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.compose.AsyncImagePainter
import coil.request.ImageRequest
import com.walliverse.app.core.AppConfig
import com.walliverse.app.data.model.Wallpaper
import com.walliverse.app.ui.theme.WalliColors

const val CARD_ASPECT = 0.68f

// ---------------------------------------------------------------- motion helpers

/** Springy "press in" feedback driven by an interaction source. */
fun Modifier.pressScale(source: InteractionSource, pressedScale: Float = 0.96f): Modifier = composed {
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    graphicsLayer { scaleX = scale; scaleY = scale }
}

/** Fade + rise entrance. Use [delayMs] to stagger siblings. */
fun Modifier.fadeSlideIn(delayMs: Int = 0, offsetY: Dp = 24.dp): Modifier = composed {
    val progress = remember { Animatable(0f) }
    val px = with(LocalDensity.current) { offsetY.toPx() }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        progress.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
    }
    graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * px
    }
}

/** Pill button with press animation, single-line label and optional spinner / progress. */
@Composable
fun WalliButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    filled: Boolean = true,
    enabled: Boolean = true,
    loading: Boolean = false,
    progress: Float? = null,
) {
    val source = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(50)
    val body: @Composable RowScope.() -> Unit = {
        if (loading) {
            if (progress != null) {
                CircularProgressIndicator(progress = { progress }, modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = LocalContentColor.current, trackColor = Color(0x33FFFFFF))
            } else {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = LocalContentColor.current)
            }
            Spacer(Modifier.width(8.dp))
        } else if (icon != null) {
            Icon(icon, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(label, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelLarge)
    }
    val m = modifier.height(52.dp).pressScale(source)
    if (filled) {
        Button(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = WalliColors.Pink, contentColor = Color.White),
            contentPadding = PaddingValues(horizontal = 16.dp),
            interactionSource = source, content = body,
        )
    } else {
        OutlinedButton(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            border = BorderStroke(1.dp, if (enabled) WalliColors.Pink else WalliColors.Border),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = WalliColors.Pink),
            contentPadding = PaddingValues(horizontal = 12.dp),
            interactionSource = source, content = body,
        )
    }
}

// ---------------------------------------------------------------- shimmer / images

@Composable
fun Modifier.shimmer(): Modifier {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmerProgress",
    )
    return this.background(
        Brush.horizontalGradient(
            colors = listOf(WalliColors.Surface, WalliColors.Elevated, WalliColors.Surface),
            startX = -400f + progress * 1400f,
            endX = progress * 1400f + 400f,
        )
    )
}

/** Remote image with shimmer while loading and a fallback icon when the link is missing or broken. */
@Composable
fun WallpaperImage(
    url: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
) {
    val context = LocalContext.current
    var state by remember(url) { mutableStateOf<AsyncImagePainter.State>(AsyncImagePainter.State.Empty) }
    val request = remember(url) { ImageRequest.Builder(context).data(url).crossfade(true).build() }
    Box(modifier.background(WalliColors.Surface)) {
        if (url != null) {
            AsyncImage(
                model = request,
                contentDescription = contentDescription,
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale,
                onState = { state = it },
            )
        }
        when {
            url == null || state is AsyncImagePainter.State.Error -> Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(Icons.Outlined.BrokenImage, null, tint = WalliColors.TextSecondary, modifier = Modifier.size(28.dp))
                Text("Image unavailable", color = WalliColors.TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
            state is AsyncImagePainter.State.Success -> Unit
            else -> Box(Modifier.fillMaxSize().shimmer())
        }
    }
}

// ---------------------------------------------------------------- cards

@Composable
fun FavoriteButton(isFavorite: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val pop = remember { Animatable(1f) }
    var previous by remember { mutableStateOf(isFavorite) }
    LaunchedEffect(isFavorite) {
        if (isFavorite && !previous) {
            pop.snapTo(0.55f)
            pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 380f))
        }
        previous = isFavorite
    }
    IconButton(onClick = onClick, modifier = modifier) {
        Box(
            Modifier.size(32.dp).graphicsLayer { scaleX = pop.value; scaleY = pop.value }.background(Color(0x99000000), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                tint = if (isFavorite) WalliColors.Pink else Color.White,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

@Composable
fun WallpaperCard(
    wallpaper: Wallpaper,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier,
    /** Non-null = play the entrance animation after this delay. */
    enterDelayMs: Long? = null,
) {
    val source = remember { MutableInteractionSource() }
    val enter = remember { Animatable(if (enterDelayMs == null) 1f else 0f) }
    val lift = with(LocalDensity.current) { 36.dp.toPx() }
    LaunchedEffect(Unit) {
        if (enterDelayMs != null) {
            delay(enterDelayMs)
            enter.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
        }
    }
    Box(
        modifier
            .aspectRatio(CARD_ASPECT)
            .graphicsLayer {
                val p = enter.value
                alpha = p
                translationY = (1f - p) * lift
                val sc = 0.92f + 0.08f * p
                scaleX = sc; scaleY = sc
            }
            .pressScale(source)
            .clip(RoundedCornerShape(16.dp))
            .clickable(interactionSource = source, indication = LocalIndication.current, onClickLabel = "Open ${wallpaper.displayTitle}", onClick = onClick)
    ) {
        WallpaperImage(wallpaper.loadUrl, wallpaper.displayTitle, Modifier.fillMaxSize())
        if (wallpaper.hasFourKTag) {
            Text(
                "4K",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
                    .background(Color(0xB3000000), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
        FavoriteButton(isFavorite, onToggleFavorite, Modifier.align(Alignment.BottomEnd))
    }
}

// ---------------------------------------------------------------- grid with incremental rendering

@Composable
fun WallpaperGrid(
    items: List<Wallpaper>,
    favoriteIds: Set<String>,
    onOpen: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyGridState = rememberLazyGridState(),
    contentPadding: PaddingValues = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
    header: LazyGridScope.() -> Unit = {},
) {
    val limit = rememberSaveable(items) { mutableStateOf(AppConfig.PAGE_SIZE) }
    val shown = remember(items, limit.value) { items.take(limit.value) }
    val seen = remember(items) { HashSet<String>() }

    LaunchedEffect(state, items) {
        snapshotFlow {
            val info = state.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            (info.totalItemsCount > 0 && last >= info.totalItemsCount - 8) to limit.value
        }.collect { (nearEnd, current) ->
            if (nearEnd && current < items.size) limit.value = current + AppConfig.PAGE_SIZE
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        state = state,
        modifier = modifier,
        contentPadding = contentPadding,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        header()
        itemsIndexed(shown, key = { _, w -> w.id }, contentType = { _, _ -> "wallpaper" }) { index, wallpaper ->
            val firstTime = remember { seen.add(wallpaper.id) }
            WallpaperCard(
                wallpaper = wallpaper,
                isFavorite = wallpaper.id in favoriteIds,
                onClick = { onOpen(wallpaper.id) },
                onToggleFavorite = { onToggleFavorite(wallpaper.id) },
                modifier = Modifier.animateItem(),
                enterDelayMs = if (firstTime) (index % 8) * 45L else null,
            )
        }
    }
}

fun LazyGridScope.fullSpanItem(key: String, content: @Composable () -> Unit) {
    item(key = key, span = { GridItemSpan(maxLineSpan) }) { content() }
}

@Composable
fun LoadingGrid(modifier: Modifier = Modifier) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        modifier = modifier,
        userScrollEnabled = false,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp, top = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(8) {
            Box(Modifier.aspectRatio(CARD_ASPECT).clip(RoundedCornerShape(16.dp)).shimmer())
        }
    }
}

// ---------------------------------------------------------------- text bits

@Composable
fun Wordmark(modifier: Modifier = Modifier) {
    Text(
        text = buildAnnotatedString {
            withStyle(SpanStyle(color = Color.White)) { append("WALLI") }
            withStyle(SpanStyle(color = WalliColors.Pink)) { append("VERSE") }
        },
        style = MaterialTheme.typography.titleLarge.copy(letterSpacing = 3.sp),
        modifier = modifier,
    )
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Row(
        modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (actionLabel != null && onAction != null) {
            TextButton(onClick = onAction) { Text(actionLabel, color = WalliColors.Pink) }
        }
    }
}

// ---------------------------------------------------------------- search

@Composable
fun SearchBarButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(16.dp),
        color = WalliColors.Surface,
    ) {
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Search, null, tint = WalliColors.TextSecondary)
            Spacer(Modifier.size(12.dp))
            Text("Search wallpapers…", color = WalliColors.TextSecondary)
        }
    }
}

@Composable
fun SearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
) {
    val keyboard = LocalSoftwareKeyboardController.current
    TextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier.let { if (focusRequester != null) it.focusRequester(focusRequester) else it },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        placeholder = { Text("Search wallpapers…", color = WalliColors.TextSecondary) },
        leadingIcon = { Icon(Icons.Outlined.Search, null, tint = WalliColors.TextSecondary) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(Icons.Outlined.Close, contentDescription = "Clear search", tint = WalliColors.TextSecondary)
                }
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { keyboard?.hide() }),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = WalliColors.Surface,
            unfocusedContainerColor = WalliColors.Surface,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = WalliColors.Pink,
        ),
    )
}

@Composable
fun CategoryChip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        modifier = modifier.semantics { this.selected = selected },
        shape = RoundedCornerShape(50),
        color = if (selected) WalliColors.Pink else WalliColors.Surface,
        contentColor = if (selected) Color.White else WalliColors.TextSecondary,
    ) {
        Text(label, Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge)
    }
}

// ---------------------------------------------------------------- states & dialogs

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Column(
        modifier.fillMaxSize().fadeSlideIn().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = WalliColors.Pink, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(message, color = WalliColors.TextSecondary, textAlign = TextAlign.Center)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = WalliColors.Pink, contentColor = Color.White),
            ) { Text(actionLabel) }
        }
    }
}

@Composable
fun ErrorState(message: String, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    EmptyState(
        icon = Icons.Outlined.WifiOff,
        title = "Something went wrong",
        message = message,
        modifier = modifier,
        actionLabel = "Try again",
        onAction = onRetry,
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WalliColors.Elevated,
        title = { Text(title) },
        text = { Text(message, color = WalliColors.TextSecondary) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel, color = WalliColors.Pink) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

package com.walliverse.app.ui.settings

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PrivacyTip
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.imageLoader
import com.walliverse.app.BuildConfig
import com.walliverse.app.core.AppConfig
import com.walliverse.app.ui.components.ConfirmDialog
import com.walliverse.app.ui.components.fadeSlideIn
import com.walliverse.app.ui.theme.WalliColors
import com.walliverse.app.util.WallpaperSetter
import com.walliverse.app.util.openUrl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

private enum class Pending { ImageCache, TempCache }

@Composable
fun MoreScreen(onMessage: (String) -> Unit) {
    val context = LocalContext.current
    var pending by remember { mutableStateOf<Pending?>(null) }
    var showLicenses by remember { mutableStateOf(false) }
    var cacheRefresh by remember { mutableStateOf(0) }
    var cacheBytes by remember { mutableStateOf<Long?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(cacheRefresh) {
        cacheBytes = withContext(Dispatchers.IO) { context.imageLoader.diskCache?.size }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.fadeSlideIn(0, 16.dp).padding(bottom = 16.dp))

        Section("Appearance", 1) {
            SettingsRow(Icons.Outlined.Palette, "Theme", "AMOLED Dark (the only theme)")
        }
        Section("Storage", 2) {
            SettingsRow(
                Icons.Outlined.Image, "Clear image cache",
                cacheBytes?.let { formatBytes(it) } ?: "Calculating…",
            ) { pending = Pending.ImageCache }
            SettingsRow(Icons.Outlined.Delete, "Clear temporary files", "Leftover wallpaper downloads") { pending = Pending.TempCache }
        }
        Section("About", 3) {
            SettingsRow(Icons.Outlined.PrivacyTip, "Privacy Policy", null) {
                if (AppConfig.PRIVACY_POLICY_URL.isBlank()) onMessage("Privacy policy link is not configured yet.")
                else if (!context.openUrl(AppConfig.PRIVACY_POLICY_URL)) onMessage("No app available to open this link.")
            }
            SettingsRow(Icons.Outlined.Description, "Open-source licenses", null) { showLicenses = true }
            SettingsRow(Icons.Outlined.Share, "Share WALLIVERSE", null) {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "Check out WALLIVERSE – wallpapers for your phone: https://play.google.com/store/apps/details?id=${context.packageName}")
                }
                try {
                    context.startActivity(Intent.createChooser(send, "Share WALLIVERSE"))
                } catch (_: Exception) {
                    onMessage("No app available to share with.")
                }
            }
            SettingsRow(Icons.Outlined.Info, "Version", BuildConfig.VERSION_NAME)
        }
    }

    pending?.let { which ->
        ConfirmDialog(
            title = if (which == Pending.ImageCache) "Clear image cache?" else "Clear temporary files?",
            message = if (which == Pending.ImageCache) "Wallpapers will be downloaded again the next time you view them."
            else "This removes unfinished wallpaper downloads. Saved wallpapers and favorites are not affected.",
            confirmLabel = "Clear",
            onConfirm = {
                pending = null
                scope.launch {
                    val ok = clearCache(context, which)
                    cacheRefresh++
                    onMessage(if (ok) "Cache cleared." else "Couldn't clear everything.")
                }
            },
            onDismiss = { pending = null },
        )
    }

    if (showLicenses) {
        AlertDialog(
            onDismissRequest = { showLicenses = false },
            containerColor = WalliColors.Elevated,
            title = { Text("Open-source licenses") },
            text = {
                Text(
                    "This app uses the following open-source software, all licensed under the Apache License 2.0:\n\n" +
                        "• AndroidX / Jetpack Compose / Material 3\n• Kotlin, kotlinx.coroutines, kotlinx.serialization\n" +
                        "• OkHttp\n• Coil\n\nFull license text: apache.org/licenses/LICENSE-2.0",
                    color = WalliColors.TextSecondary,
                )
            },
            confirmButton = { TextButton(onClick = { showLicenses = false }) { Text("Close", color = WalliColors.Pink) } },
        )
    }
}

private suspend fun clearCache(context: android.content.Context, which: Pending): Boolean =
    withContext(Dispatchers.IO) {
        runCatching {
            when (which) {
                Pending.ImageCache -> {
                    context.imageLoader.memoryCache?.clear()
                    context.imageLoader.diskCache?.clear()
                }
                Pending.TempCache -> File(context.cacheDir, WallpaperSetter.TEMP_DIR).deleteRecursively()
            }
        }.isSuccess
    }

@Composable
private fun Section(title: String, order: Int, content: @Composable () -> Unit) {
  Column(Modifier.fadeSlideIn(order * 90, 24.dp)) {
    Text(title, color = WalliColors.TextSecondary, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
    Surface(shape = RoundedCornerShape(16.dp), color = WalliColors.Surface, modifier = Modifier.fillMaxWidth()) {
        Column { content() }
    }
    Spacer(Modifier.height(12.dp))
  }
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, subtitle: String?, onClick: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.clickable(onClick = onClick) else it }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = WalliColors.TextSecondary)
        Spacer(Modifier.size(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title)
            if (subtitle != null) Text(subtitle, color = WalliColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
    else -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
}

package com.walliverse.app.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.walliverse.app.R
import com.walliverse.app.ui.components.Wordmark
import com.walliverse.app.ui.theme.WalliColors
import kotlinx.coroutines.delay

/**
 * Animated branded intro using the Walliverse wallpaper-card icon.
 * The icon gently pulses while a pink/blue neon halo breathes behind it.
 */
@Composable
fun SplashOverlay(onFinished: () -> Unit) {
    val text = remember { Animatable(0f) }
    val transition = rememberInfiniteTransition(label = "walliverseSplash")

    val iconScale by transition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(
            animation = tween(1050, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "iconPulse",
    )
    val glowAlpha by transition.animateFloat(
        initialValue = 0.24f,
        targetValue = 0.68f,
        animationSpec = infiniteRepeatable(
            animation = tween(1050, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "glowPulse",
    )

    LaunchedEffect(Unit) {
        delay(180)
        text.animateTo(1f, tween(550, easing = FastOutSlowInEasing))
        delay(1550)
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(WalliColors.Background)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) awaitPointerEvent().changes.forEach { it.consume() }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                modifier = Modifier.size(230.dp),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    modifier = Modifier
                        .size(205.dp)
                        .scale(iconScale * 1.05f)
                        .alpha(glowAlpha)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0x99F000A8),
                                    Color(0x554A42FF),
                                    Color.Transparent,
                                ),
                            ),
                            CircleShape,
                        ),
                )

                Image(
                    painter = painterResource(R.drawable.walliverse_icon),
                    contentDescription = "Walliverse app icon",
                    modifier = Modifier
                        .size(178.dp)
                        .scale(iconScale),
                )
            }

            Spacer(Modifier.height(22.dp))

            Wordmark(
                Modifier.graphicsLayer {
                    alpha = text.value
                    translationY = (1f - text.value) * 18.dp.toPx()
                },
            )

            Spacer(Modifier.height(9.dp))

            Text(
                text = "Infinite Wallpapers for Your World",
                color = WalliColors.TextSecondary,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer {
                    alpha = text.value * 0.92f
                    translationY = (1f - text.value) * 10.dp.toPx()
                },
            )

            Spacer(Modifier.height(30.dp))

            Box(contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(26.dp)
                        .alpha(glowAlpha * 0.25f)
                        .background(WalliColors.Pink, CircleShape),
                )
                Box(
                    Modifier
                        .size(6.dp)
                        .background(WalliColors.Pink, CircleShape),
                )
            }
        }
    }
}

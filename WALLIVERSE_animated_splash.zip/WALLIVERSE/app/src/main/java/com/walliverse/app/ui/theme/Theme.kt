package com.walliverse.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object WalliColors {
    val Background = Color(0xFF101010)
    val Surface = Color(0xFF1B1B1B)
    val Elevated = Color(0xFF242424)
    val Pink = Color(0xFFFF2785)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFA8A8A8)
    val Border = Color(0xFF303030)
}

private val Scheme = darkColorScheme(
    primary = WalliColors.Pink,
    onPrimary = Color.White,
    secondary = WalliColors.Pink,
    onSecondary = Color.White,
    background = WalliColors.Background,
    onBackground = WalliColors.TextPrimary,
    surface = WalliColors.Surface,
    onSurface = WalliColors.TextPrimary,
    surfaceVariant = WalliColors.Elevated,
    onSurfaceVariant = WalliColors.TextSecondary,
    surfaceContainer = WalliColors.Surface,
    surfaceContainerHigh = WalliColors.Elevated,
    surfaceContainerHighest = WalliColors.Elevated,
    outline = WalliColors.Border,
    outlineVariant = WalliColors.Border,
    error = Color(0xFFFF5470),
)

private val Base = Typography()
private val WalliTypography = Typography(
    headlineSmall = Base.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = Base.titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = Base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = Base.labelLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.3.sp),
)

/** AMOLED dark is the only theme. */
@Composable
fun WalliverseTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = WalliTypography, content = content)
}

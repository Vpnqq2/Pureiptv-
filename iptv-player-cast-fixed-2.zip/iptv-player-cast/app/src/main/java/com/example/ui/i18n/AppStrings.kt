package com.example.ui.i18n

enum class AppLanguage {
    ENGLISH,
    SPANISH,
    ARABIC
}

object AppStrings {
    fun get(language: AppLanguage = AppLanguage.ENGLISH): Strings = when (language) {
        AppLanguage.ENGLISH -> English
        AppLanguage.SPANISH -> Spanish
        AppLanguage.ARABIC -> Arabic
    }

    interface Strings {
        val appName: String
        val navPlaylists: String
        val navLive: String
        val navMovies: String
        val navSeries: String
        val navEpg: String
        val navFavorites: String
        val navSettings: String
        val searchHint: String
        val allCategories: String
        val categories: String
        val channelsCount: String
        val moviesCount: String
        val seriesCount: String
        val searchCategories: String
        val noChannelsFound: String
        val noPlaylists: String
        val noPlaylistsDesc: String
        val addPlaylist: String
        val loadSample: String
        val m3uTab: String
        val xtreamTab: String
        val playlistName: String
        val m3uUrl: String
        val serverUrl: String
        val username: String
        val password: String
        val cancel: String
        val save: String
        val loading: String
        val activePlaylist: String
        val switchPlaylist: String
        val deletePlaylist: String
        val activeBadge: String
        val playlistsSubtitle: String
        val language: String
        val english: String
        val spanish: String
        val arabic: String
        val liveNow: String
        val upcoming: String
        val resumePlaying: String
        val watchHistory: String
        val favorites: String
        val playNow: String
        val episodes: String
        val season: String
        val episode: String

        // Rich Settings Strings
        val playerSettings: String
        val decoderMode: String
        val decoderDesc: String
        val bufferSize: String
        val bufferDesc: String
        val autoPlayNext: String
        val autoPlayDesc: String
        val storageCache: String
        val clearLogoCache: String
        val clearLogoCacheDesc: String
        val clearHistory: String
        val clearHistoryDesc: String
        val cacheClearedNotice: String
        val historyClearedNotice: String
        val aboutApp: String
        val appVersion: String
        val engineVersion: String
        val networkStatus: String
        val appEditionLabel: String
        val mediaEngineLabel: String
        val connectivityLabel: String
        val protocolsLabel: String
        val decodersLabel: String
        val revisitWelcome: String

        // Splash & Welcome Screen Strings
        val splashTagline: String
        val splashStatus1: String
        val splashStatus2: String
        val splashStatus3: String
        val welcomeBadge: String
        val welcomeTitle: String
        val welcomeSubtitle: String
        val feature1Title: String
        val feature1Desc: String
        val feature2Title: String
        val feature2Desc: String
        val feature3Title: String
        val feature3Desc: String
        val welcomeStartFree: String
        val welcomeConnectXtream: String
        val welcomeImportM3u: String
        val welcomeSkip: String

        // Cast Strings
        val castTitle: String
        val castSubtitle: String
        val castSettingsTitle: String
        val castSettingsDesc: String
        val openSettings: String
        val castExternalTitle: String
        val castExternalDesc: String
        val castViaApp: String
        val copyStreamUrl: String
        val copyUrl: String
        val copiedToClipboard: String
        val castInstructionsTitle: String
        val castStep1: String
        val castStep2: String
        val castStep3: String
        val close: String
        val castNoDevices: String
        val castNoDevicesHint: String
        val castScanning: String
        val castRescan: String
        val castConnecting: String
        val castReconnecting: String
        val castConnectedTo: String
        val castReturnToPhone: String
        val castNowCasting: String
        val castPickHint: String
        val castTempLink: String
        val castLinkUnavailable: String
        val castErrNoPlayServices: String
        val castErrNoWifi: String
        val castErrConnection: String
        val castErrDeviceLost: String
        val castErrAuth: String
        val castErrNotFound: String
        val castErrUnreachable: String
        val castErrTls: String
        val castErrUnsupported: String
        val castErrRelay: String
        val castErrInvalidUrl: String
        val castMirrorNote: String

        // Reconnect & Player Strings
        val streamInterrupted: String
        val streamAutoReconnecting: String
        val streamStopped: String
        val streamReconnectingIn: String
        val streamConnectingNow: String
        val streamManualAttempt: String
        val reconnectNow: String
        val backToChannels: String
        val streamMaxRetries: String

        // EPG Strings
        val syncEpg: String
        val syncingEpg: String
        val epgTimeShift: String
        val epgProgramsCount: String
        val epgSourceUrl: String
        val noEpgData: String
        val nowPlaying: String

        // Validation & Import Strings
        val invalidPlaylistUrl: String
        val emptyPlaylistError: String
        val networkError: String
    }

    object English : Strings {
        override val appName = "IPTV Player Pro"
        override val navPlaylists = "Playlists"
        override val navLive = "Live TV"
        override val navMovies = "Movies"
        override val navSeries = "Series"
        override val navEpg = "TV Guide"
        override val navFavorites = "Favorites"
        override val navSettings = "Settings"
        override val searchHint = "Search channels, movies, series..."
        override val allCategories = "All Channels"
        override val categories = "Categories"
        override val channelsCount = "channels"
        override val moviesCount = "movies"
        override val seriesCount = "series"
        override val searchCategories = "Search categories..."
        override val noChannelsFound = "No channels match your filter"
        override val noPlaylists = "No Playlists Added"
        override val noPlaylistsDesc = "Import an M3U playlist or Xtream Codes subscription to start watching."
        override val addPlaylist = "Add Playlist"
        override val loadSample = "Load Free Sample Playlist"
        override val m3uTab = "M3U URL"
        override val xtreamTab = "Xtream Codes"
        override val playlistName = "Playlist Name"
        override val m3uUrl = "M3U Playlist URL"
        override val serverUrl = "Server URL (http://...)"
        override val username = "Username"
        override val password = "Password"
        override val cancel = "Cancel"
        override val save = "Connect & Save"
        override val loading = "Importing channels..."
        override val activePlaylist = "Active Playlist"
        override val switchPlaylist = "Switch Playlist"
        override val deletePlaylist = "Delete Playlist"
        override val activeBadge = "ACTIVE"
        override val playlistsSubtitle = "Manage M3U & Xtream Subscriptions"
        override val language = "Language"
        override val english = "English"
        override val spanish = "Español"
        override val arabic = "العربية"
        override val liveNow = "LIVE NOW"
        override val upcoming = "Upcoming"
        override val resumePlaying = "Continue Watching"
        override val watchHistory = "Watch History"
        override val favorites = "Favorites"
        override val playNow = "Play Now"
        override val episodes = "Episodes"
        override val season = "Season"
        override val episode = "Episode"

        // Rich Settings
        override val playerSettings = "Playback & Hardware"
        override val decoderMode = "Hardware Acceleration (HW+)"
        override val decoderDesc = "Use device GPU hardware for 4K / 60FPS video decoding"
        override val bufferSize = "Stream Buffer Capacity"
        override val bufferDesc = "Optimized 4-second pre-buffer for smooth anti-freeze playback"
        override val autoPlayNext = "Auto-play Next Episode"
        override val autoPlayDesc = "Automatically starts the subsequent series episode"
        override val storageCache = "Storage & Cache Management"
        override val clearLogoCache = "Clear Channel Logos & Cache"
        override val clearLogoCacheDesc = "Frees internal storage by wiping cached artwork"
        override val clearHistory = "Clear Playback History"
        override val clearHistoryDesc = "Resets continue-watching positions and recent channels"
        override val cacheClearedNotice = "Image and metadata cache cleared"
        override val historyClearedNotice = "Playback history successfully cleared"
        override val aboutApp = "App Info & Engine"
        override val appVersion = "Version 2.5.0 Pro"
        override val engineVersion = "AndroidX Media3 ExoPlayer 1.5.1"
        override val networkStatus = "Online (Low-latency HLS/TS Engine)"
        override val appEditionLabel = "App edition"
        override val mediaEngineLabel = "Media engine"
        override val connectivityLabel = "Connection"
        override val protocolsLabel = "Supported protocols"
        override val decodersLabel = "Supported decoders"
        override val revisitWelcome = "Show welcome screen again"

        // Splash & Welcome Screen
        override val splashTagline = "Ultra HD • 4K HDR • Smart IPTV Engine"
        override val splashStatus1 = "Initializing hardware acceleration..."
        override val splashStatus2 = "Loading media playback engine..."
        override val splashStatus3 = "Ready."
        override val welcomeBadge = "SMART ENTERTAINMENT"
        override val welcomeTitle = "Television Reimagined"
        override val welcomeSubtitle = "Experience crystal-clear live channels, blockbuster movies, and binge-worthy TV series with ultra-low latency."
        override val feature1Title = "Ultra HD Live & TV Guide"
        override val feature1Desc = "Fast, freeze-free streaming with integrated Electronic Program Guide"
        override val feature2Title = "Movies & On-Demand Series"
        override val feature2Desc = "Organized episodes, seasons, and resume-playback tracking"
        override val feature3Title = "Xtream Codes & M3U Engine"
        override val feature3Desc = "Connect any IPTV subscription with smart categorization"
        override val welcomeStartFree = "Explore with Free Channels"
        override val welcomeConnectXtream = "Connect Xtream Codes"
        override val welcomeImportM3u = "Import M3U Playlist"
        override val welcomeSkip = "Skip to Player"

        // Cast Strings
        override val castTitle = "Cast to TV"
        override val castSubtitle = "Chromecast • Google TV • DLNA / UPnP"
        override val castSettingsTitle = "Wireless Display & Cast Settings"
        override val castSettingsDesc = "Search for nearby TV screens and connect automatically"
        override val openSettings = "Open Settings"
        override val castExternalTitle = "Stream via External Player"
        override val castExternalDesc = "Open a credential-free temporary link in VLC, Web Video Caster or another player"
        override val castViaApp = "Cast via App"
        override val copyStreamUrl = "Copy Stream URL"
        override val copyUrl = "Copy URL"
        override val copiedToClipboard = "Stream URL copied to clipboard"
        override val castInstructionsTitle = "How to connect to your TV:"
        override val castStep1 = "Ensure your phone and TV are connected to the same Wi-Fi network."
        override val castStep2 = "Pick your TV from the list above."
        override val castStep3 = "Start any channel or movie. It plays on the TV and your phone becomes the remote."
        override val close = "Close"
        override val castNoDevices = "No TVs found"
        override val castNoDevicesHint = "Make sure the TV is on and connected to the same Wi-Fi network as this phone."
        override val castScanning = "Searching for TVs…"
        override val castRescan = "Search again"
        override val castConnecting = "Connecting to %s…"
        override val castReconnecting = "Connection lost. Reconnecting to %s…"
        override val castConnectedTo = "Connected to %s"
        override val castReturnToPhone = "Disconnect and watch on phone"
        override val castNowCasting = "Playing on TV: %s"
        override val castPickHint = "Start any channel, movie or episode and it will play on the TV."
        override val castTempLink = "Copy temporary link"
        override val castLinkUnavailable = "Couldn't create a link. Connect to Wi-Fi and try again."
        override val castErrNoPlayServices = "Google Cast isn't available on this phone (Google Play services missing). DLNA TVs still work."
        override val castErrNoWifi = "Connect to the same Wi-Fi network as the TV first."
        override val castErrConnection = "Couldn't connect to the TV. Try again."
        override val castErrDeviceLost = "Lost contact with the TV. Check Wi-Fi and reconnect."
        override val castErrAuth = "The stream was refused (login required or access denied)."
        override val castErrNotFound = "The stream link was not found on the server."
        override val castErrUnreachable = "Couldn't reach the stream. Check your connection or the IPTV server."
        override val castErrTls = "Secure connection failed (invalid HTTPS certificate)."
        override val castErrUnsupported = "This TV can't play this stream format. Try another device or an external player."
        override val castErrRelay = "Couldn't start the local relay needed to send this stream to the TV."
        override val castErrInvalidUrl = "This stream has an invalid or unsupported link."
        override val castMirrorNote = "Screen mirroring (shows the whole phone screen, not a cast)"

        // Reconnect & Player Strings
        override val streamInterrupted = "Stream Interrupted"
        override val streamAutoReconnecting = "Auto-reconnecting to stream..."
        override val streamStopped = "Stream Stopped"
        override val streamReconnectingIn = "Reconnecting in %ds (Attempt %d of %d)"
        override val streamConnectingNow = "Connecting to stream now... (Attempt %d)"
        override val streamManualAttempt = "Manual retry"
        override val reconnectNow = "Retry Now"
        override val backToChannels = "Back"
        override val streamMaxRetries = "Stream stopped. Maximum retry attempts reached."

        // EPG Strings
        override val syncEpg = "Sync EPG"
        override val syncingEpg = "Syncing EPG data..."
        override val epgTimeShift = "Time Shift"
        override val epgProgramsCount = "programs"
        override val epgSourceUrl = "EPG / XMLTV URL (Optional)"
        override val noEpgData = "No EPG data available for this channel"
        override val nowPlaying = "NOW"

        // Validation & Import Strings
        override val invalidPlaylistUrl = "Invalid playlist URL. Please enter a valid HTTP/HTTPS link."
        override val emptyPlaylistError = "The playlist is empty or contains no playable streams."
        override val networkError = "Network connection failed. Please check your internet or URL."
    }

    object Spanish : Strings {
        override val appName = "IPTV Player Pro"
        override val navPlaylists = "Listas"
        override val navLive = "TV en Vivo"
        override val navMovies = "Películas"
        override val navSeries = "Series"
        override val navEpg = "Guía TV"
        override val navFavorites = "Favoritos"
        override val navSettings = "Ajustes"
        override val searchHint = "Buscar canales, películas, series..."
        override val allCategories = "Todos los Canales"
        override val categories = "Categorías"
        override val channelsCount = "canales"
        override val moviesCount = "películas"
        override val seriesCount = "series"
        override val searchCategories = "Buscar categorías..."
        override val noChannelsFound = "No se encontraron canales"
        override val noPlaylists = "Sin Listas de Reproducción"
        override val noPlaylistsDesc = "Importe una lista M3U o suscripción Xtream Codes para comenzar a ver."
        override val addPlaylist = "Añadir Lista"
        override val loadSample = "Cargar Lista de Muestra Gratuita"
        override val m3uTab = "URL M3U"
        override val xtreamTab = "Códigos Xtream"
        override val playlistName = "Nombre de Lista"
        override val m3uUrl = "URL de Lista M3U"
        override val serverUrl = "URL del Servidor (http://...)"
        override val username = "Usuario"
        override val password = "Contraseña"
        override val cancel = "Cancelar"
        override val save = "Conectar y Guardar"
        override val loading = "Importando canales..."
        override val activePlaylist = "Lista Activa"
        override val switchPlaylist = "Cambiar Lista"
        override val deletePlaylist = "Eliminar Lista"
        override val activeBadge = "ACTIVA"
        override val playlistsSubtitle = "Gestionar suscripciones M3U y Xtream"
        override val language = "Idioma"
        override val english = "English"
        override val spanish = "Español"
        override val arabic = "العربية"
        override val liveNow = "EN VIVO"
        override val upcoming = "A Continuación"
        override val resumePlaying = "Continuar Viendo"
        override val watchHistory = "Historial de Reproducción"
        override val favorites = "Favoritos"
        override val playNow = "Reproducir Ahora"
        override val episodes = "Episodios"
        override val season = "Temporada"
        override val episode = "Capítulo"

        // Rich Settings
        override val playerSettings = "Reproducción y Hardware"
        override val decoderMode = "Aceleración por Hardware (HW+)"
        override val decoderDesc = "Usa la GPU del dispositivo para decodificación 4K / 60FPS"
        override val bufferSize = "Capacidad del Búfer de Streaming"
        override val bufferDesc = "Pre-búfer optimizado de 4 segundos para evitar cortes"
        override val autoPlayNext = "Reproducir Siguiente Episodio"
        override val autoPlayDesc = "Inicia automáticamente el siguiente capítulo de la serie"
        override val storageCache = "Almacenamiento y Caché"
        override val clearLogoCache = "Borrar Logos y Metadatos en Caché"
        override val clearLogoCacheDesc = "Libera espacio en el dispositivo eliminando miniaturas"
        override val clearHistory = "Borrar Historial de Reproducción"
        override val clearHistoryDesc = "Reinicia las posiciones de guardado y canales recientes"
        override val cacheClearedNotice = "Caché de imágenes borrada con éxito"
        override val historyClearedNotice = "Historial de reproducción borrado"
        override val aboutApp = "Información y Diagnóstico"
        override val appVersion = "Versión 2.5.0 Pro"
        override val engineVersion = "Motor AndroidX Media3 ExoPlayer 1.5.1"
        override val networkStatus = "En Línea (HLS/TS de Baja Latencia)"
        override val appEditionLabel = "Versión de la app"
        override val mediaEngineLabel = "Motor multimedia"
        override val connectivityLabel = "Conexión"
        override val protocolsLabel = "Protocolos compatibles"
        override val decodersLabel = "Decodificadores compatibles"
        override val revisitWelcome = "Mostrar la bienvenida de nuevo"

        // Splash & Welcome Screen
        override val splashTagline = "Ultra HD • 4K HDR • Motor IPTV Inteligente"
        override val splashStatus1 = "Inicializando aceleración por hardware..."
        override val splashStatus2 = "Cargando motor de reproducción de medios..."
        override val splashStatus3 = "Listo."
        override val welcomeBadge = "ENTRETENIMIENTO INTELIGENTE"
        override val welcomeTitle = "Televisión Sin Límites"
        override val welcomeSubtitle = "Disfruta de canales en vivo, películas taquilleras y series completas en calidad 4K ultra nítida."
        override val feature1Title = "Canales en Vivo Ultra HD y Guía TV"
        override val feature1Desc = "Reproducción de baja latencia sin cortes con guía electrónica EPG"
        override val feature2Title = "Películas y Series a la Carta"
        override val feature2Desc = "Control de episodios por temporada y reanudación de reproducción"
        override val feature3Title = "Motor Xtream Codes y Listas M3U"
        override val feature3Desc = "Conecta cualquier suscripción IPTV con organización automática de categorías"
        override val welcomeStartFree = "Explorar con Canales Gratuitos"
        override val welcomeConnectXtream = "Conectar Xtream Codes"
        override val welcomeImportM3u = "Importar Lista M3U"
        override val welcomeSkip = "Saltar al Reproductor"

        // Cast Strings
        override val castTitle = "Transmitir a la TV"
        override val castSubtitle = "Chromecast • Google TV • DLNA / UPnP"
        override val castSettingsTitle = "Ajustes de Pantalla Inalámbrica"
        override val castSettingsDesc = "Buscar televisores cercanos y conectar automáticamente"
        override val openSettings = "Abrir Ajustes"
        override val castExternalTitle = "Transmitir mediante App Externa"
        override val castExternalDesc = "Abrir un enlace temporal sin credenciales en VLC, Web Video Caster u otro reproductor"
        override val castViaApp = "Transmitir con App"
        override val copyStreamUrl = "Copiar Enlace de Transmisión"
        override val copyUrl = "Copiar Enlace"
        override val copiedToClipboard = "Enlace copiado al portapapeles"
        override val castInstructionsTitle = "Cómo conectar a tu TV:"
        override val castStep1 = "Asegúrate de que tu teléfono y TV estén en la misma red Wi-Fi."
        override val castStep2 = "Elige tu televisor en la lista de arriba."
        override val castStep3 = "Inicia un canal o película. Se reproduce en la TV y el teléfono funciona como control remoto."
        override val close = "Cerrar"
        override val castNoDevices = "No se encontraron televisores"
        override val castNoDevicesHint = "Asegúrate de que el televisor esté encendido y conectado a la misma red Wi-Fi que este teléfono."
        override val castScanning = "Buscando televisores…"
        override val castRescan = "Buscar de nuevo"
        override val castConnecting = "Conectando con %s…"
        override val castReconnecting = "Conexión perdida. Reconectando con %s…"
        override val castConnectedTo = "Conectado a %s"
        override val castReturnToPhone = "Desconectar y ver en el teléfono"
        override val castNowCasting = "Reproduciendo en la TV: %s"
        override val castPickHint = "Inicia cualquier canal, película o episodio y se reproducirá en la TV."
        override val castTempLink = "Copiar enlace temporal"
        override val castLinkUnavailable = "No se pudo crear el enlace. Conéctate al Wi-Fi e inténtalo de nuevo."
        override val castErrNoPlayServices = "Google Cast no está disponible en este teléfono (faltan los servicios de Google Play). Los televisores DLNA siguen funcionando."
        override val castErrNoWifi = "Primero conéctate a la misma red Wi-Fi que el televisor."
        override val castErrConnection = "No se pudo conectar con el televisor. Inténtalo de nuevo."
        override val castErrDeviceLost = "Se perdió el contacto con el televisor. Revisa el Wi-Fi y vuelve a conectar."
        override val castErrAuth = "El servidor rechazó la transmisión (requiere inicio de sesión o acceso denegado)."
        override val castErrNotFound = "No se encontró el enlace de la transmisión en el servidor."
        override val castErrUnreachable = "No se pudo acceder a la transmisión. Revisa tu conexión o el servidor IPTV."
        override val castErrTls = "Falló la conexión segura (certificado HTTPS no válido)."
        override val castErrUnsupported = "Este televisor no puede reproducir este formato. Prueba otro dispositivo o un reproductor externo."
        override val castErrRelay = "No se pudo iniciar el relé local necesario para enviar la transmisión al televisor."
        override val castErrInvalidUrl = "Esta transmisión tiene un enlace no válido o no compatible."
        override val castMirrorNote = "Duplicar pantalla (muestra toda la pantalla del teléfono, no es transmisión)"

        // Reconnect & Player Strings
        override val streamInterrupted = "Transmisión Interrumpida"
        override val streamAutoReconnecting = "Reconectando automáticamente a la transmisión..."
        override val streamStopped = "Transmisión Detenida"
        override val streamReconnectingIn = "Reconectando en %ds (Intento %d de %d)"
        override val streamConnectingNow = "Conectando al servidor ahora... (Intento %d)"
        override val streamManualAttempt = "Reintento manual"
        override val reconnectNow = "Reintentar Ahora"
        override val backToChannels = "Volver"
        override val streamMaxRetries = "Transmisión detenida. Se alcanzó el límite de intentos."

        // EPG Strings
        override val syncEpg = "Sincronizar Guía"
        override val syncingEpg = "Sincronizando guía..."
        override val epgTimeShift = "Ajuste Horario"
        override val epgProgramsCount = "programas"
        override val epgSourceUrl = "URL de Guía XMLTV (Opcional)"
        override val noEpgData = "Sin datos de guía para este canal"
        override val nowPlaying = "EN VIVO"

        // Validation & Import Strings
        override val invalidPlaylistUrl = "URL de lista no válida. Ingrese un enlace HTTP/HTTPS válido."
        override val emptyPlaylistError = "La lista está vacía o no contiene transmisiones reproducibles."
        override val networkError = "Error de red. Verifique su conexión o la dirección de la lista."
    }

    object Arabic : Strings {
        override val appName = "IPTV Player Pro"
        override val navPlaylists = "القوائم"
        override val navLive = "البث المباشر"
        override val navMovies = "الأفلام"
        override val navSeries = "المسلسلات"
        override val navEpg = "دليل القنوات"
        override val navFavorites = "المفضلة"
        override val navSettings = "الإعدادات"
        override val searchHint = "بحث عن قنوات، أفلام، مسلسلات..."
        override val allCategories = "جميع القنوات"
        override val categories = "الأقسام"
        override val channelsCount = "قناة"
        override val moviesCount = "فيلم"
        override val seriesCount = "مسلسل"
        override val searchCategories = "بحث في الأقسام..."
        override val noChannelsFound = "لا توجد قنوات تطابق البحث"
        override val noPlaylists = "لم يتم إضافة قوائم تشغيل"
        override val noPlaylistsDesc = "قم باستيراد قائمة M3U أو اشتراك Xtream Codes لبدء المشاهدة."
        override val addPlaylist = "إضافة قائمة تشغيل"
        override val loadSample = "تحميل قائمة تجريبية مجانية"
        override val m3uTab = "رابط M3U"
        override val xtreamTab = "بيانات Xtream"
        override val playlistName = "اسم القائمة"
        override val m3uUrl = "رابط قائمة M3U"
        override val serverUrl = "رابط السيرفر (http://...)"
        override val username = "اسم المستخدم"
        override val password = "كلمة المرور"
        override val cancel = "إلغاء"
        override val save = "اتصال وحفظ"
        override val loading = "جاري استيراد القنوات..."
        override val activePlaylist = "القائمة النشطة"
        override val switchPlaylist = "تبديل القائمة"
        override val deletePlaylist = "حذف القائمة"
        override val activeBadge = "نشط"
        override val playlistsSubtitle = "إدارة اشتراكات M3U و Xtream"
        override val language = "اللغة"
        override val english = "English"
        override val spanish = "Español"
        override val arabic = "العربية"
        override val liveNow = "مباشر الآن"
        override val upcoming = "التالي"
        override val resumePlaying = "متابعة المشاهدة"
        override val watchHistory = "سجل المشاهدة"
        override val favorites = "المفضلة"
        override val playNow = "تشغيل الآن"
        override val episodes = "الحلقات"
        override val season = "الموسم"
        override val episode = "الحلقة"

        // Rich Settings
        override val playerSettings = "التشغيل والعتاد"
        override val decoderMode = "تسريع العتاد (HW+)"
        override val decoderDesc = "استخدام كرت الشاشة لفك تشفير الفيديو بدقة 4K و 60 إطاراً"
        override val bufferSize = "سعة التخزين المؤقت للبث"
        override val bufferDesc = "تخزين مؤقت مسبق 4 ثوانٍ لمنع التقطيع والتعليق"
        override val autoPlayNext = "تشغيل الحلقة التالية تلقائياً"
        override val autoPlayDesc = "بدء تشغيل الحلقة التالية من المسلسل مباشرة"
        override val storageCache = "التخزين والذاكرة المؤقتة"
        override val clearLogoCache = "مسح شعارات القنوات والذاكرة المؤقتة"
        override val clearLogoCacheDesc = "تحرير مساحة التخزين عبر حذف الصور المخزنة"
        override val clearHistory = "مسح سجل المشاهدة"
        override val clearHistoryDesc = "إعادة ضبط نقاط التوقف والقنوات المشاهدة مؤخراً"
        override val cacheClearedNotice = "تم مسح الذاكرة المؤقتة للصور بنجاح"
        override val historyClearedNotice = "تم مسح سجل المشاهدة بنجاح"
        override val aboutApp = "معلومات التطبيق والمشغل"
        override val appVersion = "الإصدار 2.5.0 برو"
        override val engineVersion = "مشغل AndroidX Media3 ExoPlayer 1.5.1"
        override val networkStatus = "متصل (محرك HLS/TS منخفض التأخير)"
        override val appEditionLabel = "إصدار التطبيق"
        override val mediaEngineLabel = "محرك التشغيل"
        override val connectivityLabel = "الاتصال"
        override val protocolsLabel = "البروتوكولات المدعومة"
        override val decodersLabel = "المشغلات المدعومة"
        override val revisitWelcome = "عرض شاشة الترحيب مرة أخرى"

        // Splash & Welcome Screen
        override val splashTagline = "Ultra HD • 4K HDR • مشغل IPTV الذكي"
        override val splashStatus1 = "جاري تهيئة تسريع العتاد..."
        override val splashStatus2 = "تحميل محرك تشغيل الوسائط..."
        override val splashStatus3 = "جاهز."
        override val welcomeBadge = "ترفيه ذكي متطور"
        override val welcomeTitle = "تلفزيون بلا حدود"
        override val welcomeSubtitle = "استمتع بالقنوات المباشرة، أحدث الأفلام، والمسلسلات بجودة فائقة السرعة والوضوح."
        override val feature1Title = "قنوات مباشرة فائقة الوضوح ودليل EPG"
        override val feature1Desc = "بث فائق السرعة بدون تقطيع مع دليل البرامج الإلكتروني"
        override val feature2Title = "أفلام ومسلسلات حسب الطلب"
        override val feature2Desc = "تنظيم المواسم والحلقات وحفظ نقطة التوقف تلقائياً"
        override val feature3Title = "دعم كامل لـ Xtream Codes وقوائم M3U"
        override val feature3Desc = "ربط أي اشتراك IPTV مع تنظيم تلقائي ذكي للأقسام"
        override val welcomeStartFree = "استكشاف القنوات المجانية"
        override val welcomeConnectXtream = "ربط اشتراك Xtream Codes"
        override val welcomeImportM3u = "استيراد ملف أو رابط M3U"
        override val welcomeSkip = "الدخول للمشغل مباشرة"

        // Cast Strings
        override val castTitle = "البث إلى التلفاز"
        override val castSubtitle = "Chromecast • Google TV • DLNA / UPnP"
        override val castSettingsTitle = "فتح إعدادات الشاشة اللاسلكية والبث"
        override val castSettingsDesc = "البحث عن شاشات التلفاز القريبة والربط التلقائي"
        override val openSettings = "فتح الإعدادات"
        override val castExternalTitle = "بث عبر تطبيق خارجي"
        override val castExternalDesc = "فتح رابط مؤقت بلا بيانات دخول في VLC أو Web Video Caster أو أي مشغل آخر"
        override val castViaApp = "بث عبر تطبيق"
        override val copyStreamUrl = "نسخ رابط البث"
        override val copyUrl = "نسخ الرابط"
        override val copiedToClipboard = "تم نسخ رابط البث للحافظة"
        override val castInstructionsTitle = "كيفية توصيل البث بالتلفاز:"
        override val castStep1 = "تأكد من اتصال الهاتف والتلفاز بنفس شبكة الـ Wi-Fi."
        override val castStep2 = "اختر التلفاز من القائمة أعلاه."
        override val castStep3 = "شغّل أي قناة أو فيلم فيُعرض على التلفاز ويصبح الهاتف جهاز التحكم."
        override val close = "إغلاق"
        override val castNoDevices = "لم يتم العثور على أي تلفاز"
        override val castNoDevicesHint = "تأكد من تشغيل التلفاز واتصاله بنفس شبكة Wi-Fi المتصل بها هذا الهاتف."
        override val castScanning = "جارٍ البحث عن أجهزة التلفاز…"
        override val castRescan = "إعادة البحث"
        override val castConnecting = "جارٍ الاتصال بـ %s…"
        override val castReconnecting = "انقطع الاتصال. جارٍ إعادة الاتصال بـ %s…"
        override val castConnectedTo = "متصل بـ %s"
        override val castReturnToPhone = "قطع الاتصال والمشاهدة على الهاتف"
        override val castNowCasting = "يُعرض على التلفاز: %s"
        override val castPickHint = "شغّل أي قناة أو فيلم أو حلقة وسيُعرض مباشرة على التلفاز."
        override val castTempLink = "نسخ رابط مؤقت"
        override val castLinkUnavailable = "تعذر إنشاء الرابط. اتصل بشبكة Wi-Fi وحاول مجددًا."
        override val castErrNoPlayServices = "Google Cast غير متاح على هذا الهاتف (خدمات Google Play غير متوفرة). أجهزة DLNA ما زالت تعمل."
        override val castErrNoWifi = "اتصل أولًا بنفس شبكة Wi-Fi المتصل بها التلفاز."
        override val castErrConnection = "تعذر الاتصال بالتلفاز. حاول مرة أخرى."
        override val castErrDeviceLost = "انقطع الاتصال بالتلفاز. تحقق من Wi-Fi وأعد الاتصال."
        override val castErrAuth = "رفض الخادم البث (يتطلب تسجيل دخول أو الوصول مرفوض)."
        override val castErrNotFound = "رابط البث غير موجود على الخادم."
        override val castErrUnreachable = "تعذر الوصول إلى البث. تحقق من اتصالك أو من خادم IPTV."
        override val castErrTls = "فشل الاتصال الآمن (شهادة HTTPS غير صالحة)."
        override val castErrUnsupported = "هذا التلفاز لا يدعم تنسيق هذا البث. جرّب جهازًا آخر أو مشغلًا خارجيًا."
        override val castErrRelay = "تعذر تشغيل الوسيط المحلي اللازم لإرسال البث إلى التلفاز."
        override val castErrInvalidUrl = "رابط هذا البث غير صالح أو غير مدعوم."
        override val castMirrorNote = "مرآة الشاشة (تعرض شاشة الهاتف كاملة وليست بثًا)"

        // Reconnect & Player Strings
        override val streamInterrupted = "انقطع البث"
        override val streamAutoReconnecting = "جاري إعادة الاتصال بالبث تلقائياً..."
        override val streamStopped = "توقف البث"
        override val streamReconnectingIn = "إعادة المحاولة خلال %d ثوانٍ (محاولة %d من %d)"
        override val streamConnectingNow = "جاري محاولة فتح البث الآن... (محاولة %d)"
        override val streamManualAttempt = "محاولة يدوية"
        override val reconnectNow = "إعادة المحاولة الآن"
        override val backToChannels = "رجوع"
        override val streamMaxRetries = "توقف البث. تم استنفاد محاولات إعادة الاتصال."

        // EPG Strings
        override val syncEpg = "تحديث الدليل"
        override val syncingEpg = "جاري تحديث دليل البرامج..."
        override val epgTimeShift = "فرق التوقيت"
        override val epgProgramsCount = "برنامج"
        override val epgSourceUrl = "رابط دليل XMLTV (اختياري)"
        override val noEpgData = "لا توجد بيانات دليل برامج لهذه القناة"
        override val nowPlaying = "مباشر الآن"

        // Validation & Import Strings
        override val invalidPlaylistUrl = "رابط قائمة التشغيل غير صالح. يرجى إدخال رابط HTTP/HTTPS صحيح."
        override val emptyPlaylistError = "قائمة التشغيل فارغة أو لا تحتوي على أي قنوات قابلة للتشغيل."
        override val networkError = "فشل الاتصال بالشبكة. يرجى التحقق من اتصال الإنترنت أو صحة الرابط."
    }
}

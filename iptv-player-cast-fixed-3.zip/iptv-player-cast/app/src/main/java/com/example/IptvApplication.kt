package com.example

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.example.ads.AdsController
import com.example.analytics.AppAnalytics

class IptvApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        AdsController.attach(this)
        AppAnalytics.init(this)
        AppFirebaseMessagingService.createChannel(this)

        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) = AdsController.onActivityStarted(activity)
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })

        // Fires when the whole app goes to the background / comes back to the foreground.
        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) = AdsController.onAppForegrounded()
            override fun onStop(owner: LifecycleOwner) = AdsController.onAppBackgrounded()
        })
    }
}

package com.example.ads

import android.app.Activity
import android.app.Application
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.example.BuildConfig
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Single place for AdMob: initialization, interstitial before playing a channel, and app-open ads.
 * All timing rules are the constants below, so they are easy to tune.
 */
object AdsController {

    // ---------------- Timing rules (tune here) ----------------
    /** An interstitial can appear on every Nth time the user taps a channel/movie/episode to watch. */
    private const val INTERSTITIAL_EVERY_N_PLAYS = 3

    /** ...and never sooner than this after the previous full-screen ad (or after the app launched). */
    private const val INTERSTITIAL_MIN_INTERVAL_MS = 2 * 60 * 1000L

    /** App-open ad on return only if the app was in the background at least this long. */
    private const val APP_OPEN_MIN_BACKGROUND_MS = 30 * 1000L

    /** A loaded app-open ad expires after 4 hours (AdMob rule). */
    private const val APP_OPEN_MAX_AGE_MS = 4 * 60 * 60 * 1000L

    /** On a cold start, the app-open ad is shown only if it finishes loading within this window. */
    private const val COLD_START_WINDOW_MS = 5 * 1000L

    private const val MAX_LOAD_RETRIES = 3
    private const val TAG = "AdsController"

    private lateinit var app: Application
    private val main = Handler(Looper.getMainLooper())
    private val initStarted = AtomicBoolean(false)
    private var initialized = false

    private var currentActivity: WeakReference<Activity>? = null
    private var isShowingAd = false
    private var lastFullScreenAdAt = 0L
    private var backgroundedAt = 0L
    private var coldStartDeadline = 0L
    private var playsSinceInterstitial = 0

    private var interstitial: InterstitialAd? = null
    private var interstitialLoading = false
    private var interstitialRetries = 0

    private var appOpen: AppOpenAd? = null
    private var appOpenLoadedAt = 0L
    private var appOpenLoading = false
    private var appOpenRetries = 0

    // ---------------- Setup ----------------

    fun attach(application: Application) {
        app = application
        val now = SystemClock.elapsedRealtime()
        lastFullScreenAdAt = now // first interstitial is never right after launch
        coldStartDeadline = now + COLD_START_WINDOW_MS
    }

    /** Call from MainActivity.onCreate. */
    fun start(activity: Activity) {
        ConsentManager.gather(activity) { initializeOnce() }
        if (ConsentManager.canRequestAds(activity)) initializeOnce()
    }

    private fun initializeOnce() {
        if (!initStarted.compareAndSet(false, true)) return
        // Google recommends initializing the SDK off the main thread.
        Thread {
            MobileAds.initialize(app) {
                main.post {
                    initialized = true
                    loadInterstitial()
                    loadAppOpen()
                }
            }
        }.start()
    }

    // ---------------- Lifecycle hooks (called from IptvApplication) ----------------

    fun onActivityStarted(activity: Activity) {
        if (!isShowingAd) currentActivity = WeakReference(activity)
    }

    fun onAppForegrounded() {
        if (backgroundedAt == 0L) return // cold start is handled when the ad finishes loading
        val away = SystemClock.elapsedRealtime() - backgroundedAt
        if (away >= APP_OPEN_MIN_BACKGROUND_MS) showAppOpenIfAvailable()
    }

    fun onAppBackgrounded() {
        backgroundedAt = SystemClock.elapsedRealtime()
    }

    // ---------------- Interstitial (before watching a stream) ----------------

    /**
     * Call when the user taps a channel/movie/episode. Runs [onContinue] right away if no ad is due,
     * otherwise shows the ad and runs [onContinue] when it is closed.
     */
    fun maybeShowInterstitial(activity: Activity?, onContinue: () -> Unit) {
        playsSinceInterstitial++
        val now = SystemClock.elapsedRealtime()
        val due = playsSinceInterstitial >= INTERSTITIAL_EVERY_N_PLAYS &&
            now - lastFullScreenAdAt >= INTERSTITIAL_MIN_INTERVAL_MS

        if (activity == null || !initialized || isShowingAd || !due) {
            onContinue()
            return
        }
        val ad = interstitial
        if (ad == null) {
            loadInterstitial()
            onContinue() // never make the user wait for an ad
            return
        }

        var continued = false
        fun proceed() {
            if (!continued) {
                continued = true
                onContinue()
            }
        }

        isShowingAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                finishShowing(shown = true)
                interstitial = null
                playsSinceInterstitial = 0
                loadInterstitial()
                proceed()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.w(TAG, "Interstitial failed to show: ${error.message}")
                finishShowing(shown = false)
                interstitial = null
                loadInterstitial()
                proceed()
            }
        }
        ad.show(activity)
    }

    private fun loadInterstitial() {
        if (!initialized || interstitialLoading || interstitial != null) return
        interstitialLoading = true
        InterstitialAd.load(
            app,
            BuildConfig.ADMOB_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    interstitialLoading = false
                    interstitialRetries = 0
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Interstitial load failed: ${error.message}")
                    interstitial = null
                    interstitialLoading = false
                    if (interstitialRetries < MAX_LOAD_RETRIES) {
                        interstitialRetries++
                        main.postDelayed({ loadInterstitial() }, 30_000L * interstitialRetries)
                    }
                }
            }
        )
    }

    // ---------------- App open (launch and return) ----------------

    private fun loadAppOpen() {
        if (!initialized || appOpenLoading || (appOpen != null && !isAppOpenExpired())) return
        appOpenLoading = true
        AppOpenAd.load(
            app,
            BuildConfig.ADMOB_APP_OPEN_ID,
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpen = ad
                    appOpenLoadedAt = SystemClock.elapsedRealtime()
                    appOpenLoading = false
                    appOpenRetries = 0
                    // Cold start: show it if the app was only just opened.
                    if (SystemClock.elapsedRealtime() < coldStartDeadline) showAppOpenIfAvailable()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "App open load failed: ${error.message}")
                    appOpen = null
                    appOpenLoading = false
                    if (appOpenRetries < MAX_LOAD_RETRIES) {
                        appOpenRetries++
                        main.postDelayed({ loadAppOpen() }, 30_000L * appOpenRetries)
                    }
                }
            }
        )
    }

    private fun isAppOpenExpired() =
        SystemClock.elapsedRealtime() - appOpenLoadedAt >= APP_OPEN_MAX_AGE_MS

    private fun showAppOpenIfAvailable() {
        if (!initialized || isShowingAd) return
        val activity = currentActivity?.get() ?: return
        val ad = appOpen
        if (ad == null || isAppOpenExpired()) {
            appOpen = null
            loadAppOpen()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && activity.isInPictureInPictureMode) return

        coldStartDeadline = 0L
        isShowingAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                finishShowing(shown = true)
                appOpen = null
                loadAppOpen()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.w(TAG, "App open failed to show: ${error.message}")
                finishShowing(shown = false)
                appOpen = null
                loadAppOpen()
            }
        }
        ad.show(activity)
    }

    private fun finishShowing(shown: Boolean) {
        isShowingAd = false
        if (shown) lastFullScreenAdAt = SystemClock.elapsedRealtime()
    }
}

package com.example.ads

import android.app.Activity
import android.content.Context
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Google UMP consent flow (required for users in the EEA / UK).
 * The consent message itself is configured in the AdMob console (Privacy & messaging).
 */
object ConsentManager {

    fun canRequestAds(context: Context): Boolean =
        UserMessagingPlatform.getConsentInformation(context).canRequestAds()

    /** Refreshes consent status, shows the form if one is required, then calls [onReady] if ads may be requested. */
    fun gather(activity: Activity, onReady: () -> Unit) {
        val info = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder().build()
        info.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                    if (info.canRequestAds()) onReady()
                }
            },
            {
                if (info.canRequestAds()) onReady()
            }
        )
    }
}

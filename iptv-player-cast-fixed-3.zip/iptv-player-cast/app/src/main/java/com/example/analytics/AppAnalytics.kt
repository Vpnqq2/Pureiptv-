package com.example.analytics

import android.content.Context
import android.os.Bundle
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.messaging.FirebaseMessaging

/**
 * Thin, crash-safe wrapper around Firebase Analytics + Crashlytics + Cloud Messaging.
 * If google-services.json is missing (Firebase not configured), every call is a silent no-op.
 */
object AppAnalytics {
    private const val TAG = "AppAnalytics"

    /** Every device is subscribed to this topic, so you can send a notification to all users from the console. */
    const val TOPIC_ALL = "all_users"

    private var analytics: FirebaseAnalytics? = null
    private var crashlytics: FirebaseCrashlytics? = null

    fun init(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) FirebaseApp.initializeApp(context)
            if (FirebaseApp.getApps(context).isEmpty()) {
                Log.w(TAG, "Firebase is not configured (google-services.json missing) - analytics disabled")
                return
            }
            analytics = FirebaseAnalytics.getInstance(context)
            crashlytics = FirebaseCrashlytics.getInstance()
            FirebaseMessaging.getInstance().subscribeToTopic(TOPIC_ALL)
        } catch (t: Throwable) {
            Log.w(TAG, "Firebase init failed", t)
        }
    }

    fun logScreen(name: String) {
        val b = Bundle().apply {
            putString(FirebaseAnalytics.Param.SCREEN_NAME, name)
            putString(FirebaseAnalytics.Param.SCREEN_CLASS, "MainActivity")
        }
        safe { analytics?.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, b) }
    }

    /** [type] is "live", "movie" or "series". Channel names are deliberately NOT sent. */
    fun logPlay(type: String) = logEvent("play_stream", "content_type" to type)

    fun logPlayerError(code: String) {
        log("player_error: $code")
        logEvent("player_error", "error_code" to code)
    }

    fun logEvent(name: String, vararg params: Pair<String, String>) {
        val b = Bundle()
        params.forEach { (k, v) -> b.putString(k.take(40), v.take(100)) }
        safe { analytics?.logEvent(name.take(40), b) }
    }

    /** Breadcrumb attached to the next Crashlytics crash report. */
    fun log(message: String) = safe { crashlytics?.log(message) }

    /** Report a handled (non-fatal) exception to Crashlytics. */
    fun recordNonFatal(t: Throwable) = safe { crashlytics?.recordException(t) }

    private inline fun safe(block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            Log.w(TAG, "analytics call failed", t)
        }
    }
}

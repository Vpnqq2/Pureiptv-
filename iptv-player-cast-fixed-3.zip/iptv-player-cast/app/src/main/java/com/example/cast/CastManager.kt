package com.example.cast

import android.content.Context
import com.example.data.model.StreamItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

/**
 * Single entry point for casting. Wraps Google Cast + DLNA behind one device list / one session state,
 * and decides per stream whether the TV gets the real URL or a credential-free relay URL.
 */
object CastManager {

    private lateinit var appContext: Context
    private var initialized = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var google: GoogleCastController
    private lateinit var dlna: DlnaController
    private val relay = CastRelayServer()
    private val probeClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()

    private val active = MutableStateFlow<CastProtocol?>(null)
    private val dlnaState = MutableStateFlow<CastSessionState>(CastSessionState.Idle)
    private var externalLinks = 0

    private val _lastError = MutableStateFlow<CastError?>(null)
    val lastError: StateFlow<CastError?> = _lastError.asStateFlow()

    /** True while a cast session is connected (stream is shown on the TV, phone is the remote). */
    lateinit var state: StateFlow<CastSessionState>
        private set
    lateinit var devices: StateFlow<List<CastDeviceInfo>>
        private set
    lateinit var status: StateFlow<RemotePlaybackStatus>
        private set
    lateinit var scanning: StateFlow<Boolean>
        private set
    lateinit var googleAvailable: StateFlow<Boolean?>
        private set

    val isCasting: Boolean get() = initialized && state.value is CastSessionState.Connected

    private val dlnaById = HashMap<String, DlnaProtocol.Renderer>()

    @Synchronized
    fun init(context: Context) {
        if (initialized) return
        appContext = context.applicationContext
        google = GoogleCastController(appContext)
        dlna = DlnaController(appContext)
        dlna.onDeviceLost = {
            dlnaState.value = CastSessionState.Failed(CastError.DEVICE_LOST)
        }
        googleAvailable = google.available

        state = combine(google.state, dlnaState, active) { g, d, a -> if (a == CastProtocol.DLNA) d else g }
            .stateIn(scope, SharingStarted.Eagerly, CastSessionState.Idle)
        status = combine(google.status, dlna.status, active) { g, d, a -> if (a == CastProtocol.DLNA) d else g }
            .stateIn(scope, SharingStarted.Eagerly, RemotePlaybackStatus())
        devices = combine(google.devices, dlna.devices) { g, d ->
            dlnaById.clear()
            d.forEach { dlnaById[it.udn] = it }
            // A TV that exposes both Cast and DLNA is listed twice on purpose: the user picks the protocol.
            g + d.map { CastDeviceInfo(it.udn, it.name, CastProtocol.DLNA) }
        }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        scanning = dlna.scanning
        initialized = true
        google.init()

        scope.launch { // release the relay once nothing needs it
            state.collect { s ->
                if ((s is CastSessionState.Idle || s is CastSessionState.Failed) && externalLinks == 0) relay.stop()
            }
        }
    }

    // ---------- discovery / session ----------

    fun startDiscovery() {
        if (!initialized) return
        google.startDiscovery()
        dlna.startScan()
    }

    fun stopDiscovery() {
        if (!initialized) return
        google.stopDiscovery()
        dlna.stopScan()
    }

    fun connect(device: CastDeviceInfo) {
        _lastError.value = null
        if (!CastNetwork.hasLan(appContext)) {
            if (device.protocol == CastProtocol.GOOGLE_CAST) {
                _lastError.value = CastError.NO_WIFI
                return
            }
        }
        when (device.protocol) {
            CastProtocol.GOOGLE_CAST -> {
                if (active.value == CastProtocol.DLNA) disconnect()
                active.value = CastProtocol.GOOGLE_CAST
                google.connect(device.id)
            }
            CastProtocol.DLNA -> {
                val r = dlnaById[device.id] ?: run { dlnaState.value = CastSessionState.Failed(CastError.DEVICE_LOST); active.value = CastProtocol.DLNA; return }
                if (state.value is CastSessionState.Connected) disconnect()
                dlna.select(r)
                active.value = CastProtocol.DLNA
                dlnaState.value = CastSessionState.Connected(r.name, CastProtocol.DLNA)
            }
        }
    }

    fun disconnect() {
        if (!initialized) return
        scope.launch {
            when (active.value) {
                CastProtocol.DLNA -> { runCatching { dlna.stop() }; dlna.release(); dlnaState.value = CastSessionState.Idle }
                else -> google.disconnect()
            }
            active.value = null
            _lastError.value = null
        }
    }

    fun clearError() { _lastError.value = null }

    // ---------- playback ----------

    /** Sends [stream] to the connected TV. Errors are published through [lastError]. */
    fun castStream(stream: StreamItem, startMs: Long = 0L) {
        val st = state.value as? CastSessionState.Connected ?: return
        _lastError.value = null
        scope.launch {
            try {
                val p = prepare(stream, st.protocol)
                when (st.protocol) {
                    CastProtocol.GOOGLE_CAST -> google.load(p.url, stream.name, stream.logoUrl, p.mime, p.isLive, startMs) { err ->
                        if (err != null) _lastError.value = err
                    }
                    CastProtocol.DLNA -> dlna.load(p.url, stream.name, p.mime, p.isLive)
                }
            } catch (e: CastException) {
                _lastError.value = e.error
            } catch (_: Exception) {
                _lastError.value = CastError.CONNECTION_FAILED
            }
        }
    }

    fun play() = scope.launch { runCatching { if (active.value == CastProtocol.DLNA) dlna.play() else google.play() } }
    fun pause() = scope.launch { runCatching { if (active.value == CastProtocol.DLNA) dlna.pause() else google.pause() } }
    fun seek(ms: Long) = scope.launch { runCatching { if (active.value == CastProtocol.DLNA) dlna.seek(ms) else google.seek(ms) } }
    fun setVolume(v: Float) = scope.launch { runCatching { if (active.value == CastProtocol.DLNA) dlna.setVolume(v) else google.setVolume(v) } }

    /** Stops media on the TV but keeps the connection so another channel can be cast right away. */
    fun stopPlayback() {
        if (!initialized || !isCasting) return
        scope.launch { runCatching { if (active.value == CastProtocol.DLNA) dlna.stop() else google.stopMedia() } }
    }

    fun positionMs(): Long = if (!initialized) 0L else if (active.value == CastProtocol.DLNA) dlna.status.value.positionMs else google.position()

    // ---------- URL preparation ----------

    data class Prepared(val url: String, val mime: String, val isLive: Boolean, val viaRelay: Boolean)

    private suspend fun prepare(stream: StreamItem, protocol: CastProtocol): Prepared = withContext(Dispatchers.IO) {
        val raw = stream.streamUrl.trim()
        if (!CastUrlPolicy.isHttp(raw)) throw CastException(CastError.INVALID_URL)
        val upstream = CastUrlPolicy.toCastableUrl(raw, stream.type)
        probe(upstream)
        val mime = CastUrlPolicy.mimeType(upstream, stream.type)
        val isLive = stream.type == com.example.data.model.ChannelType.LIVE
        // Relay when: credentials inside the URL, URL only reachable from this phone, or HLS for the
        // Cast web receiver (needs CORS headers which IPTV servers almost never send).
        val needRelay = CastUrlPolicy.hasCredentials(upstream) ||
            CastUrlPolicy.isLoopbackHost(upstream) ||
            (protocol == CastProtocol.GOOGLE_CAST && CastUrlPolicy.isHls(mime))
        if (!needRelay) return@withContext Prepared(upstream, mime, isLive, false)
        Prepared(relayUrl(upstream), mime, isLive, true)
    }

    private fun relayUrl(upstream: String): String {
        val ip = CastNetwork.localIpv4(appContext) ?: throw CastException(CastError.NO_WIFI)
        try {
            relay.start()
        } catch (_: IOException) { throw CastException(CastError.RELAY_FAILED) }
        relay.currentHost = ip
        return relay.urlFor(ip, upstream)
    }

    /** Verifies the phone can open the URL before involving the TV; maps failures to clear errors. */
    private fun probe(url: String) {
        val req = try {
            Request.Builder().url(url).header("Range", "bytes=0-0").build()
        } catch (_: Exception) { throw CastException(CastError.INVALID_URL) }
        try {
            probeClient.newCall(req).execute().use { r ->
                when {
                    r.code == 401 || r.code == 403 -> throw CastException(CastError.AUTH_REQUIRED)
                    r.code == 404 || r.code == 410 -> throw CastException(CastError.NOT_FOUND)
                    r.code >= 500 -> throw CastException(CastError.UNREACHABLE)
                    !r.isSuccessful -> throw CastException(CastError.UNREACHABLE)
                }
            }
        } catch (e: CastException) { throw e
        } catch (_: SSLException) { throw CastException(CastError.TLS)
        } catch (_: IOException) { throw CastException(CastError.UNREACHABLE) }
    }

    // ---------- links for external players ----------

    /**
     * A temporary credential-free LAN link for external players (VLC, Web Video Caster...) or clipboard.
     * Valid only while this app runs. Returns null if no Wi-Fi/LAN address or the relay can't start.
     */
    fun externalLink(stream: StreamItem): String? {
        if (!initialized) return null
        val raw = stream.streamUrl.trim()
        if (!CastUrlPolicy.isHttp(raw)) return null
        val upstream = CastUrlPolicy.toCastableUrl(raw, stream.type)
        if (!CastUrlPolicy.hasCredentials(upstream) && !CastUrlPolicy.isLoopbackHost(upstream)) return upstream
        return try { relayUrl(upstream).also { externalLinks++ } } catch (_: CastException) { null }
    }

    fun releaseExternalLinks() {
        externalLinks = 0
        if (initialized && !isCasting) relay.stop()
    }
}

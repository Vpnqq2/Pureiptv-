package com.example.cast

import android.content.Context
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider

/**
 * Registered in AndroidManifest (com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME).
 * Uses Google's Default Media Receiver, which plays HLS (needs CORS - the relay adds it), MP4/H.264,
 * WebM and similar. A custom receiver needs a Cast developer registration and is not required here.
 */
class CastOptionsProvider : OptionsProvider {
    override fun getCastOptions(context: Context): CastOptions =
        CastOptions.Builder()
            .setReceiverApplicationId(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID)
            .setStopReceiverApplicationWhenEndingSession(true)
            .build()

    override fun getAdditionalSessionProviders(context: Context): List<SessionProvider>? = null
}

package com.example.cast

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

/**
 * DLNA / UPnP MediaRenderer control: SSDP discovery + AVTransport/RenderingControl SOAP.
 * This is a different protocol from Google Cast; many smart TVs (Samsung, LG, Sony, Philips)
 * implement it and accept a plain http URL for progressive formats (MP4/TS, sometimes MKV/HLS).
 */
class DlnaController(
    private val context: Context,
    scopeParent: Job? = null
) {
    private val scope = CoroutineScope(SupervisorJob(scopeParent) + Dispatchers.IO)
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .followRedirects(false) // device descriptions must not redirect us off-LAN
        .build()

    private val _devices = MutableStateFlow<List<DlnaProtocol.Renderer>>(emptyList())
    val devices: StateFlow<List<DlnaProtocol.Renderer>> = _devices.asStateFlow()

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()

    private val _status = MutableStateFlow(RemotePlaybackStatus())
    val status: StateFlow<RemotePlaybackStatus> = _status.asStateFlow()

    @Volatile private var renderer: DlnaProtocol.Renderer? = null
    private var scanJob: Job? = null
    private var pollJob: Job? = null
    @Volatile var onDeviceLost: (() -> Unit)? = null

    // ---------- discovery ----------

    fun startScan() {
        if (scanJob?.isActive == true) return
        scanJob = scope.launch {
            _scanning.value = true
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val lock = wifi?.createMulticastLock("iptv-dlna")?.apply { setReferenceCounted(false); acquire() }
            try {
                val found = LinkedHashMap<String, DlnaProtocol.Renderer>()
                repeat(2) { // SSDP is UDP: ask twice
                    for (loc in ssdpSearch()) {
                        val r = fetchDescription(loc) ?: continue
                        found[r.udn] = r
                    }
                    _devices.value = found.values.toList()
                }
            } finally {
                _scanning.value = false
                try { lock?.release() } catch (_: Exception) {}
            }
        }
    }

    fun stopScan() { scanJob?.cancel() }

    private fun ssdpSearch(): Set<String> {
        val locations = LinkedHashSet<String>()
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket().apply { soTimeout = 1000; reuseAddress = true }
            CastNetwork.lanNetwork(context)?.bindSocket(socket) // use Wi-Fi even if mobile data is default
            val data = DlnaProtocol.msearch().toByteArray(Charsets.US_ASCII)
            val group = InetAddress.getByName(DlnaProtocol.SSDP_ADDRESS)
            repeat(2) { socket.send(DatagramPacket(data, data.size, group, DlnaProtocol.SSDP_PORT)) }
            val end = System.currentTimeMillis() + 3000
            val buf = ByteArray(4096)
            while (System.currentTimeMillis() < end) {
                try {
                    val p = DatagramPacket(buf, buf.size)
                    socket.receive(p)
                    DlnaProtocol.parseSsdpLocation(String(p.data, 0, p.length, Charsets.US_ASCII))
                        ?.let { locations.add(it) }
                } catch (_: SocketTimeoutException) { /* keep listening until deadline */ }
            }
        } catch (_: Exception) {
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
        return locations
    }

    private fun fetchDescription(location: String): DlnaProtocol.Renderer? = try {
        http.newCall(Request.Builder().url(location).build()).execute().use { r ->
            if (!r.isSuccessful) null
            else DlnaProtocol.parseDescription(r.body?.string().orEmpty(), location)
        }
    } catch (_: Exception) { null }

    // ---------- control ----------

    fun select(r: DlnaProtocol.Renderer) {
        renderer = r
        _status.value = RemotePlaybackStatus()
    }

    fun release() {
        pollJob?.cancel()
        renderer = null
        _status.value = RemotePlaybackStatus()
    }

    fun shutdown() { scanJob?.cancel(); release() }

    /** Sends the media to the TV and starts playback. Throws [CastException] on failure. */
    suspend fun load(url: String, title: String, mime: String, isLive: Boolean) = withContext(Dispatchers.IO) {
        val r = renderer ?: throw CastException(CastError.DEVICE_LOST)
        runCatching { soap(r.avTransportControlUrl, DlnaProtocol.AV_TRANSPORT, "Stop", DlnaProtocol.stopBody()) }
        soap(r.avTransportControlUrl, DlnaProtocol.AV_TRANSPORT, "SetAVTransportURI",
            DlnaProtocol.setUriBody(url, DlnaProtocol.didl(title, url, mime, isLive)))
        soap(r.avTransportControlUrl, DlnaProtocol.AV_TRANSPORT, "Play", DlnaProtocol.playBody())
        _status.value = RemotePlaybackStatus(isPlaying = true, isBuffering = true, hasMedia = true, canSeek = !isLive)
        startPolling(isLive)
    }

    suspend fun play() = control("Play", DlnaProtocol.playBody())
    suspend fun pause() = control("Pause", DlnaProtocol.pauseBody())
    suspend fun stop() { pollJob?.cancel(); runCatching { control("Stop", DlnaProtocol.stopBody()) }
        _status.value = _status.value.copy(isPlaying = false, hasMedia = false) }
    suspend fun seek(ms: Long) = control("Seek", DlnaProtocol.seekBody(ms))

    suspend fun setVolume(fraction: Float) = withContext(Dispatchers.IO) {
        val url = renderer?.renderingControlUrl ?: return@withContext
        soap(url, DlnaProtocol.RENDERING_CONTROL, "SetVolume", DlnaProtocol.setVolumeBody((fraction * 100).toInt()))
        _status.value = _status.value.copy(volume = fraction)
    }

    private suspend fun control(action: String, body: String) = withContext(Dispatchers.IO) {
        val r = renderer ?: throw CastException(CastError.DEVICE_LOST)
        soap(r.avTransportControlUrl, DlnaProtocol.AV_TRANSPORT, action, body)
    }

    private fun soap(controlUrl: String, service: String, action: String, body: String): String {
        val req = Request.Builder().url(controlUrl)
            .header("SOAPACTION", DlnaProtocol.soapAction(service, action))
            .post(body.toRequestBody("text/xml; charset=\"utf-8\"".toMediaType()))
            .build()
        try {
            return http.newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                if (!r.isSuccessful) {
                    val code = DlnaProtocol.tag(text, "errorCode")?.toIntOrNull()
                    throw CastException(
                        if (code != null && code in setOf(701, 702, 714, 715, 716, 717)) CastError.UNSUPPORTED_FORMAT
                        else CastError.CONNECTION_FAILED
                    )
                }
                text
            }
        } catch (e: CastException) { throw e
        } catch (e: SSLException) { throw CastException(CastError.TLS)
        } catch (e: IOException) { throw CastException(CastError.DEVICE_LOST) }
    }

    private fun startPolling(isLive: Boolean) {
        pollJob?.cancel()
        pollJob = scope.launch {
            val started = System.currentTimeMillis()
            var seenPlaying = false
            var failures = 0
            while (isActive) {
                delay(2000)
                val r = renderer ?: return@launch
                try {
                    val ti = soap(r.avTransportControlUrl, DlnaProtocol.AV_TRANSPORT, "GetTransportInfo", DlnaProtocol.transportInfoBody())
                    val state = DlnaProtocol.tag(ti, "CurrentTransportState") ?: ""
                    val tStatus = DlnaProtocol.tag(ti, "CurrentTransportStatus") ?: "OK"
                    failures = 0
                    val pi = runCatching { soap(r.avTransportControlUrl, DlnaProtocol.AV_TRANSPORT, "GetPositionInfo", DlnaProtocol.positionInfoBody()) }.getOrDefault("")
                    val pos = DlnaProtocol.parseTime(DlnaProtocol.tag(pi, "RelTime"))
                    val dur = DlnaProtocol.parseTime(DlnaProtocol.tag(pi, "TrackDuration"))
                    if (state == "PLAYING") seenPlaying = true
                    val unsupported = tStatus.equals("ERROR_OCCURRED", true) ||
                        (!seenPlaying && state in setOf("STOPPED", "NO_MEDIA_PRESENT") && System.currentTimeMillis() - started > 6000) ||
                        (!seenPlaying && System.currentTimeMillis() - started > 20000)
                    _status.value = _status.value.copy(
                        isPlaying = state == "PLAYING",
                        isBuffering = state == "TRANSITIONING",
                        positionMs = pos, durationMs = dur,
                        canSeek = !isLive && dur > 0,
                        error = if (unsupported) CastError.UNSUPPORTED_FORMAT else null
                    )
                    if (unsupported) return@launch
                } catch (e: CastException) {
                    if (++failures >= 3) { onDeviceLost?.invoke(); return@launch }
                }
            }
        }
    }
}

class CastException(val error: CastError) : Exception(error.name)

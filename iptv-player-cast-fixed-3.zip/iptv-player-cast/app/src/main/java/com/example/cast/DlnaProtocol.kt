package com.example.cast

import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.net.URI
import javax.xml.parsers.DocumentBuilderFactory

/** Pure UPnP/DLNA helpers: SSDP messages, device description parsing, SOAP/DIDL builders. No Android deps. */
object DlnaProtocol {

    const val SSDP_ADDRESS = "239.255.255.250"
    const val SSDP_PORT = 1900
    const val AV_TRANSPORT = "urn:schemas-upnp-org:service:AVTransport:1"
    const val RENDERING_CONTROL = "urn:schemas-upnp-org:service:RenderingControl:1"

    data class Renderer(
        val udn: String,
        val name: String,
        val avTransportControlUrl: String,
        val renderingControlUrl: String?
    )

    fun msearch(): String =
        "M-SEARCH * HTTP/1.1\r\n" +
            "HOST: $SSDP_ADDRESS:$SSDP_PORT\r\n" +
            "MAN: \"ssdp:discover\"\r\n" +
            "MX: 2\r\n" +
            "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n"

    /** Returns the LOCATION header of an SSDP response, or null. */
    fun parseSsdpLocation(packet: String): String? {
        if (!packet.startsWith("HTTP/1.1 200") && !packet.startsWith("NOTIFY")) return null
        return packet.lineSequence()
            .map { it.trim() }
            .firstOrNull { it.startsWith("LOCATION:", ignoreCase = true) }
            ?.substringAfter(':')?.trim()
            ?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    /** Parses a UPnP device description. Returns null when the device has no AVTransport service. */
    fun parseDescription(xml: String, locationUrl: String): Renderer? {
        val doc = try {
            val f = DocumentBuilderFactory.newInstance()
            // XXE hardening: descriptions come from arbitrary devices on the LAN
            try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Exception) {}
            f.isExpandEntityReferences = false
            f.newDocumentBuilder().parse(ByteArrayInputStream(xml.toByteArray(Charsets.UTF_8)))
        } catch (_: Exception) { return null }

        val root = doc.documentElement ?: return null
        val urlBase = text(root, "URLBase")?.takeIf { it.isNotBlank() } ?: locationUrl
        val device = firstDescendant(root, "device") ?: return null
        val name = text(device, "friendlyName") ?: "TV"
        val udn = text(device, "UDN") ?: locationUrl

        var av: String? = null
        var rc: String? = null
        val services = root.getElementsByTagName("service")
        for (i in 0 until services.length) {
            val s = services.item(i) as? Element ?: continue
            val type = text(s, "serviceType") ?: continue
            val ctl = text(s, "controlURL") ?: continue
            val abs = resolve(urlBase, ctl) ?: continue
            if (type.startsWith("urn:schemas-upnp-org:service:AVTransport")) av = abs
            if (type.startsWith("urn:schemas-upnp-org:service:RenderingControl")) rc = abs
        }
        return av?.let { Renderer(udn, name, it, rc) }
    }

    fun resolve(base: String, ref: String): String? = try {
        URI(base).resolve(ref.trim()).toString()
    } catch (_: Exception) { null }

    private fun text(parent: Element, tag: String): String? {
        val n = parent.getElementsByTagName(tag)
        return if (n.length > 0) n.item(0).textContent?.trim() else null
    }

    private fun firstDescendant(parent: Element, tag: String): Element? {
        val n = parent.getElementsByTagName(tag)
        return if (n.length > 0 && n.item(0).nodeType == Node.ELEMENT_NODE) n.item(0) as Element else null
    }

    fun escapeXml(s: String): String = buildString(s.length + 16) {
        for (c in s) when (c) {
            '&' -> append("&amp;"); '<' -> append("&lt;"); '>' -> append("&gt;")
            '"' -> append("&quot;"); '\'' -> append("&apos;"); else -> append(c)
        }
    }

    fun didl(title: String, url: String, mime: String, isLive: Boolean): String =
        "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
            "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
            "<item id=\"0\" parentID=\"-1\" restricted=\"1\">" +
            "<dc:title>${escapeXml(title)}</dc:title>" +
            "<upnp:class>object.item.videoItem${if (isLive) ".videoBroadcast" else ""}</upnp:class>" +
            "<res protocolInfo=\"http-get:*:${escapeXml(mime)}:*\">${escapeXml(url)}</res>" +
            "</item></DIDL-Lite>"

    fun soapEnvelope(serviceType: String, action: String, args: List<Pair<String, String>>): String =
        "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body>" +
            "<u:$action xmlns:u=\"$serviceType\">" +
            args.joinToString("") { (k, v) -> "<$k>${escapeXml(v)}</$k>" } +
            "</u:$action></s:Body></s:Envelope>"

    fun soapAction(serviceType: String, action: String) = "\"$serviceType#$action\""

    fun setUriBody(url: String, didl: String) = soapEnvelope(AV_TRANSPORT, "SetAVTransportURI", listOf(
        "InstanceID" to "0", "CurrentURI" to url, "CurrentURIMetaData" to didl))

    fun playBody() = soapEnvelope(AV_TRANSPORT, "Play", listOf("InstanceID" to "0", "Speed" to "1"))
    fun pauseBody() = soapEnvelope(AV_TRANSPORT, "Pause", listOf("InstanceID" to "0"))
    fun stopBody() = soapEnvelope(AV_TRANSPORT, "Stop", listOf("InstanceID" to "0"))
    fun seekBody(ms: Long) = soapEnvelope(AV_TRANSPORT, "Seek", listOf(
        "InstanceID" to "0", "Unit" to "REL_TIME", "Target" to formatTime(ms)))
    fun transportInfoBody() = soapEnvelope(AV_TRANSPORT, "GetTransportInfo", listOf("InstanceID" to "0"))
    fun positionInfoBody() = soapEnvelope(AV_TRANSPORT, "GetPositionInfo", listOf("InstanceID" to "0"))
    fun setVolumeBody(percent: Int) = soapEnvelope(RENDERING_CONTROL, "SetVolume", listOf(
        "InstanceID" to "0", "Channel" to "Master", "DesiredVolume" to percent.coerceIn(0, 100).toString()))

    fun formatTime(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        return "%02d:%02d:%02d".format(total / 3600, (total % 3600) / 60, total % 60)
    }

    fun parseTime(s: String?): Long {
        val p = s?.trim()?.split(':') ?: return 0
        if (p.size != 3) return 0
        val h = p[0].toLongOrNull() ?: return 0
        val m = p[1].toLongOrNull() ?: return 0
        val sec = p[2].substringBefore('.').toLongOrNull() ?: return 0
        return (h * 3600 + m * 60 + sec) * 1000
    }

    fun tag(xml: String, name: String): String? =
        Regex("<(?:\\w+:)?$name>([^<]*)</(?:\\w+:)?$name>").find(xml)?.groupValues?.get(1)?.trim()
}

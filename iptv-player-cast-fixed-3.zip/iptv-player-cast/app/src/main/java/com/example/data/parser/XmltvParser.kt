package com.example.data.parser

import android.util.Xml
import com.example.data.local.EpgProgramEntity
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.io.PushbackInputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class XmltvResult(
    val programs: List<EpgProgramEntity>,
    val channelDisplayNameMap: Map<String, List<String>>,
    val channelAliases: Map<String, String> // normalized name -> channelId
)

object XmltvParser {

    fun parse(inputStream: InputStream): XmltvResult {
        // Strip UTF-8 BOM if present
        val pushback = PushbackInputStream(inputStream, 3)
        val bom = ByteArray(3)
        val n = pushback.read(bom, 0, 3)
        if (n >= 3 && bom[0] == 0xEF.toByte() && bom[1] == 0xBB.toByte() && bom[2] == 0xBF.toByte()) {
            // BOM consumed
        } else if (n > 0) {
            pushback.unread(bom, 0, n)
        }

        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        // Pass null so XmlPullParser auto-detects encoding from the XML declaration
        parser.setInput(pushback, null)

        val programs = mutableListOf<EpgProgramEntity>()
        val channelNamesMap = mutableMapOf<String, MutableList<String>>()
        val channelAliases = mutableMapOf<String, String>()

        var eventType = parser.eventType

        var currentChannelTagId: String? = null
        var currentProgChannel: String? = null
        var currentStart: Long = 0
        var currentEnd: Long = 0
        var currentTitle: String? = null
        var currentDesc: String? = null

        while (eventType != XmlPullParser.END_DOCUMENT) {
            val name = parser.name
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (name?.lowercase(Locale.ROOT)) {
                        "channel" -> {
                            currentChannelTagId = parser.getAttributeValue(null, "id")?.trim()
                            if (!currentChannelTagId.isNullOrBlank()) {
                                val norm = normalizeName(currentChannelTagId)
                                if (norm.isNotBlank()) {
                                    channelAliases[norm] = currentChannelTagId
                                }
                            }
                        }
                        "display-name" -> {
                            try {
                                val text = parser.nextText()?.trim()
                                if (!text.isNullOrBlank() && currentChannelTagId != null) {
                                    val list = channelNamesMap.getOrPut(currentChannelTagId) { mutableListOf() }
                                    if (!list.contains(text)) {
                                        list.add(text)
                                    }
                                    val normalized = normalizeName(text)
                                    if (normalized.isNotBlank()) {
                                        channelAliases[normalized] = currentChannelTagId
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                        "programme" -> {
                            val startStr = parser.getAttributeValue(null, "start")
                            val stopStr = parser.getAttributeValue(null, "stop")
                            currentProgChannel = parser.getAttributeValue(null, "channel")?.trim()

                            currentStart = parseDate(startStr)
                            currentEnd = parseDate(stopStr)
                            currentTitle = null
                            currentDesc = null
                        }
                        "title" -> {
                            try {
                                currentTitle = parser.nextText()?.trim()
                            } catch (_: Exception) {}
                        }
                        "desc" -> {
                            try {
                                currentDesc = parser.nextText()?.trim()
                            } catch (_: Exception) {}
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (name?.lowercase(Locale.ROOT)) {
                        "channel" -> {
                            currentChannelTagId = null
                        }
                        "programme" -> {
                            if (!currentProgChannel.isNullOrBlank() && !currentTitle.isNullOrBlank() && currentStart > 0) {
                                val validEnd = if (currentEnd > currentStart) currentEnd else currentStart + 3600_000L
                                programs.add(
                                    EpgProgramEntity(
                                        channelId = currentProgChannel,
                                        title = currentTitle!!,
                                        description = currentDesc,
                                        startEpoch = currentStart,
                                        endEpoch = validEnd
                                    )
                                )
                            }
                            currentProgChannel = null
                            currentTitle = null
                            currentDesc = null
                        }
                    }
                }
            }
            try {
                eventType = parser.next()
            } catch (e: Exception) {
                break
            }
        }

        return XmltvResult(
            programs = programs,
            channelDisplayNameMap = channelNamesMap,
            channelAliases = channelAliases
        )
    }

    /**
     * Parses standard XMLTV timestamps with time zone offsets into UTC epoch milliseconds.
     * Supported formats:
     * - "20261010130000 +0000", "20261010130000 +0300", "20261010130000 -0500"
     * - "20261010130000 +03:00", "20261010130000 -04:00"
     * - "20261010130000+0300" (no space)
     * - "20261010130000" (no timezone, defaults to UTC)
     * - "202610101300 +0000" (12 digits)
     * - "2026-10-10T13:00:00Z", "2026-10-10 13:00:00" (ISO 8601 fallback)
     */
    fun parseDate(dateStr: String?): Long {
        if (dateStr.isNullOrBlank()) return 0L
        val trimmed = dateStr.trim()

        // 1. ISO 8601 fallback if hyphens are present
        if (trimmed.contains("-") && (trimmed.contains("T") || trimmed.contains(" "))) {
            return parseIsoDate(trimmed)
        }

        // 2. Standard XMLTV format: extract leading digits (YYYYMMDDHHMM[SS])
        var i = 0
        while (i < trimmed.length && trimmed[i].isDigit()) {
            i++
        }
        val digits = trimmed.substring(0, i)
        if (digits.length < 12) return 0L

        return try {
            val year = digits.substring(0, 4).toInt()
            val month = digits.substring(4, 6).toInt() - 1 // Calendar months 0-based
            val day = digits.substring(6, 8).toInt()
            val hour = digits.substring(8, 10).toInt()
            val min = digits.substring(10, 12).toInt()
            val sec = if (digits.length >= 14) digits.substring(12, 14).toInt() else 0

            val remainder = trimmed.substring(i).trim()
            val tz = parseTimezone(remainder)

            val cal = Calendar.getInstance(tz).apply {
                clear()
                set(year, month, day, hour, min, sec)
            }
            cal.timeInMillis
        } catch (_: Exception) {
            0L
        }
    }

    private fun parseIsoDate(isoStr: String): Long {
        val clean = isoStr.replace(" ", "T")
        val formats = listOf(
            "yyyy-MM-dd'T'HH:mm:ssZ",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss"
        )
        for (pattern in formats) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                val date = sdf.parse(clean)
                if (date != null) return date.time
            } catch (_: Exception) {}
        }
        return 0L
    }

    private fun parseTimezone(tzStr: String): TimeZone {
        if (tzStr.isBlank() || tzStr.equals("Z", ignoreCase = true) ||
            tzStr.equals("UTC", ignoreCase = true) || tzStr.equals("GMT", ignoreCase = true)) {
            return TimeZone.getTimeZone("UTC")
        }
        val clean = tzStr.replace(" ", "")
        if (clean.startsWith("+") || clean.startsWith("-")) {
            val sign = clean[0]
            val digits = clean.drop(1).filter { it.isDigit() }.take(4)
            if (digits.length >= 4) {
                val h = digits.substring(0, 2)
                val m = digits.substring(2, 4)
                return TimeZone.getTimeZone("GMT$sign$h:$m")
            } else if (digits.length >= 2) {
                val h = digits.substring(0, 2)
                return TimeZone.getTimeZone("GMT$sign$h:00")
            }
        }
        return TimeZone.getTimeZone("UTC")
    }

    /**
     * Normalizes channel names for fuzzy & exact EPG matching.
     * Strips bracketed tags [AR], |AR|, quality labels (HD, FHD, 4K),
     * normalizes Arabic letter variations and removes diacritics.
     */
    fun normalizeName(name: String): String {
        return name.lowercase(Locale.ROOT)
            .replace(Regex("""^[|\[(][a-z0-9_-]{1,6}[\])|]\s*""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""^[a-z]{2,4}:\s*""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\b(hd|fhd|4k|uhd|sd|hevc|h265|1080p|720p|live|channel|tv|stream|plus|\+)\b""", RegexOption.IGNORE_CASE), "")
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ة', 'ه')
            .replace('ى', 'ي')
            .replace(Regex("""[\u064B-\u065F]"""), "") // remove tashkeel/diacritics
            .replace(Regex("""[^a-z0-9\u0600-\u06FF]"""), "")
            .trim()
    }
}

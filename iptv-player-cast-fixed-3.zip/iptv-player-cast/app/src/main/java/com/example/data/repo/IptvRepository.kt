package com.example.data.repo

import androidx.room.withTransaction
import com.example.data.local.EpgProgramEntity
import com.example.data.local.IptvDao
import com.example.data.local.IptvDatabase
import com.example.data.local.PlaylistEntity
import com.example.data.local.StreamEntity
import com.example.data.model.CategorySummary
import com.example.data.model.ChannelType
import com.example.data.model.PlaylistItem
import com.example.data.model.PlaylistType
import com.example.data.model.StreamItem
import com.example.data.parser.M3uParser
import com.example.data.parser.XmltvParser
import com.example.data.sample.SamplePlaylists
import com.example.data.xtream.XtreamClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream

class IptvRepository(
    private val dao: IptvDao,
    private val database: IptvDatabase? = null,
    private val xtreamClient: XtreamClient = XtreamClient(),
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {

    val allPlaylists: Flow<List<PlaylistItem>> = dao.getAllPlaylists().map { list ->
        list.map { it.toModel() }
    }

    val activePlaylist: Flow<PlaylistItem?> = dao.getActivePlaylist().map { it?.toModel() }

    fun getStreams(playlistId: Long, type: ChannelType): Flow<List<StreamItem>> {
        return dao.getStreams(playlistId, type).map { list -> list.map { it.toModel() } }
    }

    fun getStreamsByCategory(playlistId: Long, type: ChannelType, category: String): Flow<List<StreamItem>> {
        return dao.getStreamsByCategory(playlistId, type, category).map { list -> list.map { it.toModel() } }
    }

    fun getCategories(playlistId: Long, type: ChannelType): Flow<List<String>> {
        return dao.getCategories(playlistId, type)
    }

    fun getCategoriesWithCounts(playlistId: Long, type: ChannelType): Flow<List<CategorySummary>> {
        return dao.getCategoriesWithCounts(playlistId, type).map { list ->
            list.map { CategorySummary(name = com.example.util.CategorySanitizer.clean(it.category), type = type, count = it.count) }
                .groupBy { it.name }
                .map { (cleanName, items) ->
                    CategorySummary(name = cleanName, type = type, count = items.sumOf { it.count })
                }
        }
    }

    fun getAllFavorites(): Flow<List<StreamItem>> {
        return dao.getAllFavorites().map { list -> list.map { it.toModel() } }
    }

    fun getFavoritesByType(type: ChannelType): Flow<List<StreamItem>> {
        return dao.getFavoritesByType(type).map { list -> list.map { it.toModel() } }
    }

    fun getWatchHistory(): Flow<List<StreamItem>> {
        return dao.getWatchHistory().map { list -> list.map { it.toModel() } }
    }

    fun searchStreams(playlistId: Long, query: String): Flow<List<StreamItem>> {
        return dao.searchStreams(playlistId, query).map { list -> list.map { it.toModel() } }
    }

    fun getEpisodesForSeries(seriesId: String): Flow<List<StreamItem>> {
        return dao.getEpisodesForSeries(seriesId).map { list -> list.map { it.toModel() } }
    }

    // --- EPG Methods ---

    fun getAllUpcomingEpgFlow(cutoffEpoch: Long = System.currentTimeMillis() - 7200_000L): Flow<List<EpgProgramEntity>> {
        return dao.getAllUpcomingEpg(cutoffEpoch)
    }

    suspend fun getAllUpcomingEpgOnce(cutoffEpoch: Long = System.currentTimeMillis() - 7200_000L): List<EpgProgramEntity> = withContext(Dispatchers.IO) {
        dao.getAllUpcomingEpgOnce(cutoffEpoch)
    }

    fun getUpcomingEpg(channelId: String): Flow<List<EpgProgramEntity>> {
        return dao.getUpcomingEpg(channelId, System.currentTimeMillis())
    }

    suspend fun getCurrentProgram(channelId: String): EpgProgramEntity? = withContext(Dispatchers.IO) {
        dao.getCurrentProgram(channelId, System.currentTimeMillis())
    }

    fun getEpgProgramCount(): Flow<Int> {
        return dao.getEpgProgramCount()
    }

    suspend fun getEpgCountOnce(): Int = withContext(Dispatchers.IO) {
        dao.getEpgCountOnce()
    }

    suspend fun clearAllEpg() = withContext(Dispatchers.IO) {
        dao.clearAllEpg()
    }

    suspend fun loadSampleEpg(): Int = withContext(Dispatchers.IO) {
        val sample = SamplePlaylists.createSampleEpg()
        dao.insertEpgPrograms(sample)
        sample.size
    }

    /**
     * Connects XMLTV importer with the database:
     * 1. Downloads & parses XMLTV data.
     * 2. Queries streams from database.
     * 3. Matches channels using exact IDs, display names, and normalized titles.
     * 4. Updates stream records in the database with their matching epgChannelId.
     * 5. Persists EPG programs in a single database transaction to avoid overlapping flow emissions.
     */
    suspend fun importXmltv(url: String, playlistId: Long? = null): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = url.trim()
            if (cleanUrl.isBlank()) {
                return@withContext Result.failure(Exception("Empty XMLTV URL"))
            }

            val request = Request.Builder()
                .url(cleanUrl)
                .header("User-Agent", "IPTVSmartersPro/3.1.5.1 (Linux; Android 14)")
                .header("Accept", "*/*")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP error ${response.code} downloading XMLTV"))
            }

            val body = response.body?.byteStream()
                ?: return@withContext Result.failure(Exception("Empty XMLTV response body"))

            val buffered = BufferedInputStream(body)
            buffered.mark(2)
            val header = ByteArray(2)
            val bytesRead = buffered.read(header)
            buffered.reset()

            val isGzip = (bytesRead >= 2 && header[0] == 0x1f.toByte() && header[1] == 0x8b.toByte()) ||
                    cleanUrl.endsWith(".gz", ignoreCase = true)

            val inputStream: InputStream = if (isGzip) {
                GZIPInputStream(buffered)
            } else {
                buffered
            }

            val result = XmltvParser.parse(inputStream)
            if (result.programs.isEmpty()) {
                return@withContext Result.failure(Exception("No EPG programmes parsed from XMLTV source"))
            }

            // Cleanup expired programmes older than 24h
            val cutoff = System.currentTimeMillis() - 86400_000L

            // 1. Fetch live channels from database to match against XMLTV
            val dbStreams = if (playlistId != null && playlistId > 0) {
                dao.getStreamsOnce(playlistId, ChannelType.LIVE)
            } else {
                dao.getAllStreamsByTypeOnce(ChannelType.LIVE)
            }

            // 2. Build lookup maps from XMLTV data
            val xmltvChannelIds = result.programs.map { it.channelId }.toHashSet()
            val xmltvDisplayNameToId = mutableMapOf<String, String>()
            result.channelDisplayNameMap.forEach { (chId, names) ->
                names.forEach { name ->
                    val norm = XmltvParser.normalizeName(name)
                    if (norm.isNotBlank()) {
                        xmltvDisplayNameToId[norm] = chId
                    }
                }
            }
            result.channelAliases.forEach { (aliasNorm, chId) ->
                if (aliasNorm.isNotBlank()) {
                    xmltvDisplayNameToId[aliasNorm] = chId
                }
            }

            // 3. Match each database stream to an XMLTV channel ID
            val streamUpdates = mutableListOf<Pair<Long, String>>() // stream.id to matchedXmltvId
            val streamIdToMatchedXmltvId = mutableMapOf<String, String>() // stream.streamId to matchedXmltvId

            dbStreams.forEach { stream ->
                var matchedId: String? = null

                // Direct exact match on stream.epgChannelId
                if (!stream.epgChannelId.isNullOrBlank() && xmltvChannelIds.contains(stream.epgChannelId)) {
                    matchedId = stream.epgChannelId
                }

                // Normalized match on stream.epgChannelId
                if (matchedId == null && !stream.epgChannelId.isNullOrBlank()) {
                    val normEpg = XmltvParser.normalizeName(stream.epgChannelId)
                    matchedId = xmltvDisplayNameToId[normEpg]
                }

                // Match streamId
                if (matchedId == null && xmltvChannelIds.contains(stream.streamId)) {
                    matchedId = stream.streamId
                }

                // Match stream.name exact or normalized
                if (matchedId == null) {
                    val normName = XmltvParser.normalizeName(stream.name)
                    matchedId = xmltvDisplayNameToId[normName]
                }

                // Fuzzy contains match on normalized name
                if (matchedId == null) {
                    val normName = XmltvParser.normalizeName(stream.name)
                    if (normName.length >= 3) {
                        matchedId = xmltvDisplayNameToId.entries.firstOrNull { (k, _) ->
                            k.length >= 3 && (normName.contains(k) || k.contains(normName))
                        }?.value
                    }
                }

                if (matchedId != null) {
                    streamIdToMatchedXmltvId[stream.streamId] = matchedId
                    if (stream.epgChannelId != matchedId) {
                        streamUpdates.add(stream.id to matchedId)
                    }
                }
            }

            // 4. Also insert program records under stream.streamId so direct queries succeed
            val additionalAliasPrograms = mutableListOf<EpgProgramEntity>()
            if (streamIdToMatchedXmltvId.isNotEmpty()) {
                val programsByXmltvId = result.programs.groupBy { it.channelId }
                streamIdToMatchedXmltvId.forEach { (streamId, xmltvId) ->
                    if (streamId != xmltvId) {
                        val progs = programsByXmltvId[xmltvId] ?: emptyList()
                        for (p in progs) {
                            additionalAliasPrograms.add(p.copy(id = 0, channelId = streamId))
                        }
                    }
                }
            }

            val allProgramsToInsert = result.programs + additionalAliasPrograms

            // 5. Atomic single transaction to avoid multiple Flow re-triggers and UI freezing
            if (database != null) {
                database.withTransaction {
                    dao.cleanupOldEpg(cutoff)
                    allProgramsToInsert.chunked(500).forEach { batch ->
                        dao.insertEpgPrograms(batch)
                    }
                    streamUpdates.forEach { (streamDbId, epgId) ->
                        dao.updateStreamEpgChannelId(streamDbId, epgId)
                    }
                }
            } else {
                dao.cleanupOldEpg(cutoff)
                allProgramsToInsert.chunked(500).forEach { batch ->
                    dao.insertEpgPrograms(batch)
                }
                streamUpdates.forEach { (streamDbId, epgId) ->
                    dao.updateStreamEpgChannelId(streamDbId, epgId)
                }
            }

            Result.success(result.programs.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun importXtreamEpg(serverUrl: String, user: String, pass: String, playlistId: Long? = null): Result<Int> {
        val xmltvUrl = xtreamClient.getXmltvUrl(serverUrl, user, pass)
        return importXmltv(xmltvUrl, playlistId)
    }

    // --- Stream Actions ---

    suspend fun toggleFavorite(streamId: Long, currentFav: Boolean) = withContext(Dispatchers.IO) {
        dao.updateFavorite(streamId, !currentFav)
    }

    suspend fun recordWatchProgress(streamId: Long, progressMs: Long, durationMs: Long) = withContext(Dispatchers.IO) {
        dao.updateWatchProgress(streamId, progressMs, durationMs, System.currentTimeMillis())
    }

    suspend fun clearWatchHistory() = withContext(Dispatchers.IO) {
        dao.clearWatchHistory()
    }

    suspend fun setActivePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        dao.setActivePlaylist(playlistId)
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        dao.deleteStreamsByPlaylist(playlistId)
        dao.deletePlaylist(playlistId)
    }

    suspend fun purgeSampleData() = withContext(Dispatchers.IO) {
        dao.purgeSamplePlaylists()
        dao.purgeOrphanStreams()
    }

    private fun validateAndNormalizeUrl(url: String): String {
        val trimmed = url.trim()
        if (trimmed.isBlank()) {
            throw IllegalArgumentException("Playlist URL cannot be empty")
        }
        val lower = trimmed.lowercase()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
            throw IllegalArgumentException("Invalid playlist URL scheme. Must start with http:// or https://")
        }
        return trimmed
    }

    suspend fun importM3uUrl(name: String, url: String, epgUrl: String? = null): Result<Long> = withContext(Dispatchers.IO) {
        var createdPlaylistId: Long? = null
        try {
            val normalizedUrl = validateAndNormalizeUrl(url)

            val request = Request.Builder()
                .url(normalizedUrl)
                .header("User-Agent", "Mozilla/5.0 (Android; Mobile; IPTVPlayer/2.5.0)")
                .build()

            val response = try {
                httpClient.newCall(request).execute()
            } catch (e: Exception) {
                throw Exception("Network connection failed: ${e.localizedMessage ?: "Unable to connect to server"}")
            }

            if (!response.isSuccessful) {
                throw Exception("Server returned error code HTTP ${response.code}: ${response.message}")
            }

            val responseBody = response.body
                ?: throw Exception("Empty playlist response body from server")

            // Read content into memory to validate before creating database records
            val bytes = responseBody.bytes()
            if (bytes.isEmpty()) {
                throw Exception("Playlist file downloaded from server is completely empty (0 bytes)")
            }

            // Create temporary test stream to check validity
            val testStream = ByteArrayInputStream(bytes)
            val parseResult = M3uParser.parseWithEpg(testStream, 0L)
            if (parseResult.streams.isEmpty()) {
                throw Exception("No valid or playable streams found in playlist. Ensure it contains valid #EXTINF lines.")
            }

            // Create playlist record atomically in database
            val playlistEntity = PlaylistEntity(
                name = name.ifBlank { "M3U Playlist" },
                type = PlaylistType.M3U_URL,
                sourceUrl = normalizedUrl,
                epgUrl = epgUrl?.ifBlank { null } ?: parseResult.epgUrl,
                isActive = false
            )

            val playlistId = dao.insertPlaylist(playlistEntity)
            createdPlaylistId = playlistId

            // Insert streams associated with this playlist ID, ensuring unique stream URLs
            val updatedStreams = parseResult.streams.mapIndexed { idx, s ->
                s.copy(
                    playlistId = playlistId,
                    streamId = if (s.streamId.startsWith("stream_0_")) "stream_${playlistId}_$idx" else s.streamId
                )
            }

            // Transactional or chunked write with automatic rollback if error occurs
            if (database != null) {
                database.withTransaction {
                    updatedStreams.chunked(500).forEach { batch ->
                        dao.insertStreams(batch)
                    }
                }
            } else {
                updatedStreams.chunked(500).forEach { batch ->
                    dao.insertStreams(batch)
                }
            }

            val liveCount = updatedStreams.count { it.type == ChannelType.LIVE }
            val movieCount = updatedStreams.count { it.type == ChannelType.MOVIE }
            val seriesCount = updatedStreams.count { it.type == ChannelType.SERIES }

            val effectiveEpgUrl = epgUrl?.ifBlank { null } ?: parseResult.epgUrl
            dao.updatePlaylist(
                playlistEntity.copy(
                    id = playlistId,
                    epgUrl = effectiveEpgUrl,
                    channelCount = liveCount,
                    movieCount = movieCount,
                    seriesCount = seriesCount,
                    isActive = true
                )
            )
            dao.setActivePlaylist(playlistId)

            Result.success(playlistId)
        } catch (e: Exception) {
            // Clean up / rollback partial or failed playlist import completely
            createdPlaylistId?.let { id ->
                try {
                    dao.deleteStreamsByPlaylist(id)
                    dao.deletePlaylist(id)
                } catch (_: Exception) {}
            }
            Result.failure(e)
        }
    }

    suspend fun importM3uContent(name: String, content: String, epgUrl: String? = null): Result<Long> = withContext(Dispatchers.IO) {
        var createdPlaylistId: Long? = null
        try {
            val trimmedContent = content.trim()
            if (trimmedContent.isBlank()) {
                throw Exception("M3U content is empty")
            }

            val stream = ByteArrayInputStream(trimmedContent.toByteArray(Charsets.UTF_8))
            val parseResult = M3uParser.parseWithEpg(stream, 0L)
            if (parseResult.streams.isEmpty()) {
                throw Exception("No valid or playable streams found in provided M3U content")
            }

            val playlistEntity = PlaylistEntity(
                name = name.ifBlank { "Imported M3U" },
                type = PlaylistType.M3U_CONTENT,
                sourceUrl = "local_content",
                epgUrl = epgUrl?.ifBlank { null } ?: parseResult.epgUrl,
                isActive = false
            )
            val playlistId = dao.insertPlaylist(playlistEntity)
            createdPlaylistId = playlistId

            val updatedStreams = parseResult.streams.mapIndexed { idx, s ->
                s.copy(
                    playlistId = playlistId,
                    streamId = if (s.streamId.startsWith("stream_0_")) "stream_${playlistId}_$idx" else s.streamId
                )
            }

            if (database != null) {
                database.withTransaction {
                    updatedStreams.chunked(500).forEach { batch ->
                        dao.insertStreams(batch)
                    }
                }
            } else {
                updatedStreams.chunked(500).forEach { batch ->
                    dao.insertStreams(batch)
                }
            }

            val liveCount = updatedStreams.count { it.type == ChannelType.LIVE }
            val movieCount = updatedStreams.count { it.type == ChannelType.MOVIE }
            val seriesCount = updatedStreams.count { it.type == ChannelType.SERIES }

            val effectiveEpgUrl = epgUrl?.ifBlank { null } ?: parseResult.epgUrl
            dao.updatePlaylist(
                playlistEntity.copy(
                    id = playlistId,
                    epgUrl = effectiveEpgUrl,
                    channelCount = liveCount,
                    movieCount = movieCount,
                    seriesCount = seriesCount,
                    isActive = true
                )
            )
            dao.setActivePlaylist(playlistId)

            Result.success(playlistId)
        } catch (e: Exception) {
            // Clean up / rollback partial or failed playlist import completely
            createdPlaylistId?.let { id ->
                try {
                    dao.deleteStreamsByPlaylist(id)
                    dao.deletePlaylist(id)
                } catch (_: Exception) {}
            }
            Result.failure(e)
        }
    }

    suspend fun importXtream(
        name: String,
        serverUrl: String,
        user: String,
        pass: String,
        customEpgUrl: String? = null
    ): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = xtreamClient.sanitizeServerUrl(serverUrl)
            val cleanUser = user.trim()
            val cleanPass = pass.trim()

            if (cleanUrl.isBlank() || cleanUser.isBlank() || cleanPass.isBlank()) {
                return@withContext Result.failure(Exception("Please enter Server URL, Username, and Password"))
            }

            val auth = xtreamClient.authenticate(cleanUrl, cleanUser, cleanPass)
            if (!auth.success) {
                return@withContext Result.failure(Exception(auth.message ?: "Authentication failed. Check credentials or server."))
            }

            val defaultXmltvUrl = xtreamClient.getXmltvUrl(cleanUrl, cleanUser, cleanPass)
            val effectiveEpgUrl = customEpgUrl?.ifBlank { null } ?: defaultXmltvUrl

            val playlistEntity = PlaylistEntity(
                name = name.ifBlank { "Xtream Account" },
                type = PlaylistType.XTREAM,
                sourceUrl = cleanUrl,
                epgUrl = effectiveEpgUrl,
                username = cleanUser,
                password = cleanPass,
                isActive = false
            )
            var createdPlaylistId: Long? = null
            try {
                val playlistId = dao.insertPlaylist(playlistEntity)
                createdPlaylistId = playlistId

                val streams = xtreamClient.fetchAllStreams(playlistId, cleanUrl, cleanUser, cleanPass)
                if (streams.isEmpty()) {
                    throw Exception("Authenticated successfully, but no active streams were found on this account.")
                }

                if (database != null) {
                    database.withTransaction {
                        streams.chunked(500).forEach { batch ->
                            dao.insertStreams(batch)
                        }
                    }
                } else {
                    streams.chunked(500).forEach { batch ->
                        dao.insertStreams(batch)
                    }
                }

                val liveCount = streams.count { it.type == ChannelType.LIVE }
                val movieCount = streams.count { it.type == ChannelType.MOVIE }
                val seriesCount = streams.count { it.type == ChannelType.SERIES }

                dao.updatePlaylist(
                    playlistEntity.copy(
                        id = playlistId,
                        epgUrl = effectiveEpgUrl,
                        channelCount = liveCount,
                        movieCount = movieCount,
                        seriesCount = seriesCount,
                        isActive = true
                    )
                )
                dao.setActivePlaylist(playlistId)

                Result.success(playlistId)
            } catch (inner: Exception) {
                createdPlaylistId?.let { id ->
                    try {
                        dao.deleteStreamsByPlaylist(id)
                        dao.deletePlaylist(id)
                    } catch (_: Exception) {}
                }
                throw inner
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun PlaylistEntity.toModel() = PlaylistItem(
        id = id,
        name = name,
        type = type,
        sourceUrl = sourceUrl,
        epgUrl = epgUrl,
        username = username,
        password = password,
        channelCount = channelCount,
        movieCount = movieCount,
        seriesCount = seriesCount,
        isActive = isActive,
        lastUpdated = lastUpdated
    )

    private fun StreamEntity.toModel() = StreamItem(
        id = id,
        playlistId = playlistId,
        streamId = streamId,
        name = name,
        streamUrl = streamUrl,
        logoUrl = logoUrl,
        category = com.example.util.CategorySanitizer.clean(category),
        type = type,
        epgChannelId = epgChannelId,
        isFavorite = isFavorite,
        lastPlayed = lastPlayed,
        watchProgressMs = watchProgressMs,
        durationMs = durationMs,
        releaseDate = releaseDate,
        rating = rating,
        plot = plot,
        seasonNumber = seasonNumber,
        episodeNumber = episodeNumber,
        seriesId = seriesId
    )
}

package com.example.data.xtream

import com.example.data.local.StreamEntity
import com.example.data.model.ChannelType
import com.example.data.parser.M3uParser
import com.example.util.CategorySanitizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.util.concurrent.TimeUnit

class XtreamClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {

    private val userAgent = "IPTVSmartersPro/3.1.5.1 (Linux; Android 14)"

    data class AuthResult(
        val success: Boolean,
        val message: String? = null,
        val serverInfo: String? = null,
        val expiryDate: String? = null,
        val maxConnections: String? = null
    )

    fun sanitizeServerUrl(raw: String): String {
        var trimmed = raw.trim()
        if (!trimmed.startsWith("http://", ignoreCase = true) && !trimmed.startsWith("https://", ignoreCase = true)) {
            trimmed = "http://$trimmed"
        }

        // Strip trailing slash
        while (trimmed.endsWith("/")) {
            trimmed = trimmed.substring(0, trimmed.length - 1)
        }

        // Strip common script paths if the user pasted the full URL
        val suffixesToRemove = listOf(
            "/player_api.php",
            "/get.php",
            "/c",
            "/client_area",
            "/xmltv.php"
        )
        for (suffix in suffixesToRemove) {
            if (trimmed.endsWith(suffix, ignoreCase = true)) {
                trimmed = trimmed.substring(0, trimmed.length - suffix.length)
            }
        }

        return trimmed.trimEnd('/')
    }

    fun getXmltvUrl(serverUrl: String, user: String, pass: String): String {
        val base = sanitizeServerUrl(serverUrl)
        return "$base/xmltv.php?username=${user.trim()}&password=${pass.trim()}"
    }

    suspend fun authenticate(
        serverUrl: String,
        user: String,
        pass: String
    ): AuthResult = withContext(Dispatchers.IO) {
        try {
            val base = sanitizeServerUrl(serverUrl)
            val cleanUser = user.trim()
            val cleanPass = pass.trim()

            val url = "$base/player_api.php?username=$cleanUser&password=$cleanPass"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .header("Accept", "application/json, text/plain, */*")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext AuthResult(false, "Server HTTP error ${response.code} (${response.message})")
            }

            val body = response.body?.string()?.trim()
                ?: return@withContext AuthResult(false, "Empty response from Xtream server")

            if (!body.startsWith("{")) {
                // If the response is not JSON, check if it's an M3U redirect or HTML
                return@withContext AuthResult(false, "Unexpected server response (non-JSON). Verify server URL and port.")
            }

            val json = JSONObject(body)
            val userInfo = json.optJSONObject("user_info")

            if (userInfo != null) {
                val authVal = userInfo.opt("auth")
                val isAuth = authVal == 1 || authVal == "1" || userInfo.optInt("auth", 0) == 1 || userInfo.optString("auth") == "1"
                val status = userInfo.optString("status")
                val isStatusActive = status.equals("Active", ignoreCase = true) ||
                        status.equals("Trial", ignoreCase = true) ||
                        status.equals("1") ||
                        status.isBlank()

                if (isAuth || isStatusActive || (userInfo.has("username") && !status.equals("Banned", ignoreCase = true) && !status.equals("Disabled", ignoreCase = true))) {
                    val serverInfo = json.optJSONObject("server_info")
                    val expDate = userInfo.optString("exp_date")
                    val maxConns = userInfo.optString("max_connections")
                    return@withContext AuthResult(
                        success = true,
                        serverInfo = serverInfo?.optString("url") ?: base,
                        expiryDate = expDate,
                        maxConnections = maxConns
                    )
                } else {
                    val msg = userInfo.optString("message").ifBlank { "Account is $status or expired" }
                    return@withContext AuthResult(false, msg)
                }
            } else {
                // Some panels don't wrap in user_info or return direct status
                val directStatus = json.optString("status")
                if (directStatus.equals("Active", ignoreCase = true) || json.optInt("auth") == 1) {
                    return@withContext AuthResult(success = true, serverInfo = base)
                }
                val msg = json.optString("message").ifBlank { "Authentication failed. Please verify credentials." }
                return@withContext AuthResult(false, msg)
            }
        } catch (e: Exception) {
            AuthResult(false, "Connection error: ${e.localizedMessage ?: "Timeout or unreachable server"}")
        }
    }

    suspend fun fetchAllStreams(
        playlistId: Long,
        serverUrl: String,
        user: String,
        pass: String
    ): List<StreamEntity> = withContext(Dispatchers.IO) {
        val base = sanitizeServerUrl(serverUrl)
        val cleanUser = user.trim()
        val cleanPass = pass.trim()
        val result = mutableListOf<StreamEntity>()

        // 1. Fetch category maps for live, vod, series
        val liveCatMap = fetchCategoriesMap(base, cleanUser, cleanPass, "get_live_categories")
        val vodCatMap = fetchCategoriesMap(base, cleanUser, cleanPass, "get_vod_categories")
        val seriesCatMap = fetchCategoriesMap(base, cleanUser, cleanPass, "get_series_categories")

        // 2. Fetch Live Streams via player_api
        try {
            val liveUrl = "$base/player_api.php?username=$cleanUser&password=$cleanPass&action=get_live_streams"
            val liveJson = fetchJsonArray(liveUrl)
            for (i in 0 until liveJson.length()) {
                val item = liveJson.optJSONObject(i) ?: continue
                val streamId = item.optString("stream_id").ifBlank {
                    item.optInt("stream_id", 0).takeIf { it > 0 }?.toString() ?: item.optString("num")
                }
                if (streamId.isBlank()) continue
                val name = item.optString("name").ifBlank { item.optString("title", "Channel $streamId") }
                val icon = item.optString("stream_icon").takeIf { it.isNotBlank() }
                val catId = item.optString("category_id")
                val rawCat = liveCatMap[catId] ?: "Live"
                val catName = CategorySanitizer.clean(rawCat)
                val epgId = item.optString("epg_channel_id").takeIf { it.isNotBlank() }
                    ?: item.optString("epg_id").takeIf { it.isNotBlank() }

                val customExt = item.optString("container_extension").trim().trimStart('.')
                val liveExt = if (customExt.isNotBlank()) customExt else "ts"
                val playUrl = "$base/live/$cleanUser/$cleanPass/$streamId.$liveExt"
                result.add(
                    StreamEntity(
                        playlistId = playlistId,
                        streamId = streamId,
                        name = name,
                        streamUrl = playUrl,
                        logoUrl = icon,
                        category = catName,
                        type = ChannelType.LIVE,
                        epgChannelId = epgId
                    )
                )
            }
        } catch (_: Exception) { }

        // 3. Fetch VOD Movies
        try {
            val vodUrl = "$base/player_api.php?username=$cleanUser&password=$cleanPass&action=get_vod_streams"
            val vodJson = fetchJsonArray(vodUrl)
            for (i in 0 until vodJson.length()) {
                val item = vodJson.optJSONObject(i) ?: continue
                val streamId = item.optString("stream_id").ifBlank {
                    item.optInt("stream_id", 0).takeIf { it > 0 }?.toString() ?: item.optString("num")
                }
                if (streamId.isBlank()) continue
                val name = item.optString("name").ifBlank { item.optString("title", "Movie $streamId") }
                val icon = item.optString("stream_icon").takeIf { it.isNotBlank() }
                val catId = item.optString("category_id")
                val rawCat = vodCatMap[catId] ?: "Movies"
                val catName = CategorySanitizer.clean(rawCat)
                val ext = item.optString("container_extension").trim().trimStart('.').ifBlank { "mp4" }
                val rating = item.optString("rating").takeIf { it.isNotBlank() }
                val plot = item.optString("plot").takeIf { it.isNotBlank() }
                val releaseDate = item.optString("releasedate").takeIf { it.isNotBlank() }

                val playUrl = "$base/movie/$cleanUser/$cleanPass/$streamId.$ext"
                result.add(
                    StreamEntity(
                        playlistId = playlistId,
                        streamId = streamId,
                        name = name,
                        streamUrl = playUrl,
                        logoUrl = icon,
                        category = catName,
                        type = ChannelType.MOVIE,
                        rating = rating,
                        plot = plot,
                        releaseDate = releaseDate
                    )
                )
            }
        } catch (_: Exception) { }

        // 4. Fetch Series, Seasons, and Episodes
        try {
            val seriesUrl = "$base/player_api.php?username=$cleanUser&password=$cleanPass&action=get_series"
            val seriesJson = fetchJsonArray(seriesUrl)

            if (seriesJson.length() > 0) {
                val seriesItems = mutableListOf<JSONObject>()
                for (i in 0 until seriesJson.length()) {
                    seriesJson.optJSONObject(i)?.let { seriesItems.add(it) }
                }

                // Fetch series info and episodes concurrently using coroutines and semaphore
                val concurrencyLimit = Semaphore(8)
                val maxParallelSeries = 100 // Load full seasons/episodes for up to 100 series during initial import
                val processedSeries = coroutineScope {
                    seriesItems.take(maxParallelSeries).map { item ->
                        async(Dispatchers.IO) {
                            concurrencyLimit.withPermit {
                                fetchEpisodesForSeriesItem(base, cleanUser, cleanPass, playlistId, item, seriesCatMap)
                            }
                        }
                    }.awaitAll()
                }

                processedSeries.forEach { episodes ->
                    result.addAll(episodes)
                }

                // If account has more than maxParallelSeries, add remaining as placeholders
                if (seriesItems.size > maxParallelSeries) {
                    for (i in maxParallelSeries until seriesItems.size) {
                        val item = seriesItems[i]
                        val seriesId = item.optString("series_id").ifBlank {
                            item.optInt("series_id", 0).takeIf { it > 0 }?.toString() ?: ""
                        }
                        if (seriesId.isBlank()) continue
                        val seriesName = item.optString("name").ifBlank { item.optString("title", "Series $seriesId") }
                        val cover = item.optString("cover").takeIf { it.isNotBlank() }
                            ?: item.optString("backdrop_path").takeIf { it.isNotBlank() }
                        val catId = item.optString("category_id")
                        val rawCat = seriesCatMap[catId] ?: "Series"
                        val catName = CategorySanitizer.clean(rawCat)
                        val rating = item.optString("rating").takeIf { it.isNotBlank() }
                        val plot = item.optString("plot").takeIf { it.isNotBlank() }

                        result.add(
                            StreamEntity(
                                playlistId = playlistId,
                                streamId = "series_$seriesId",
                                name = seriesName,
                                streamUrl = "$base/series/$cleanUser/$cleanPass/$seriesId.mp4",
                                logoUrl = cover,
                                category = catName,
                                type = ChannelType.SERIES,
                                rating = rating,
                                plot = plot,
                                seriesId = seriesName,
                                seasonNumber = 1,
                                episodeNumber = 1
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) { }

        // 5. CRITICAL FALLBACK: If player_api returned 0 streams, fallback to standard M3U endpoint
        if (result.isEmpty()) {
            try {
                val m3uUrl = "$base/get.php?username=$cleanUser&password=$cleanPass&type=m3u_plus&output=ts"
                val req = Request.Builder()
                    .url(m3uUrl)
                    .header("User-Agent", userAgent)
                    .build()
                val resp = client.newCall(req).execute()
                if (resp.isSuccessful) {
                    val stream: InputStream? = resp.body?.byteStream()
                    if (stream != null) {
                        val parsed = M3uParser.parse(stream, playlistId)
                        result.addAll(parsed)
                    }
                }
            } catch (_: Exception) { }
        }

        result
    }

    private suspend fun fetchEpisodesForSeriesItem(
        base: String,
        cleanUser: String,
        cleanPass: String,
        playlistId: Long,
        item: JSONObject,
        seriesCatMap: Map<String, String>
    ): List<StreamEntity> {
        val seriesId = item.optString("series_id").ifBlank {
            item.optInt("series_id", 0).takeIf { it > 0 }?.toString() ?: ""
        }
        if (seriesId.isBlank()) return emptyList()

        val seriesName = item.optString("name").ifBlank { item.optString("title", "Series $seriesId") }
        val cover = item.optString("cover").takeIf { it.isNotBlank() }
            ?: item.optString("backdrop_path").takeIf { it.isNotBlank() }
        val catId = item.optString("category_id")
        val rawCat = seriesCatMap[catId] ?: "Series"
        val catName = CategorySanitizer.clean(rawCat)
        val rating = item.optString("rating").takeIf { it.isNotBlank() }
        val plot = item.optString("plot").takeIf { it.isNotBlank() }

        val episodes = fetchSeriesEpisodes(
            serverUrl = base,
            user = cleanUser,
            pass = cleanPass,
            playlistId = playlistId,
            seriesId = seriesId,
            seriesName = seriesName,
            catName = catName,
            cover = cover,
            plot = plot,
            rating = rating
        )

        return if (episodes.isNotEmpty()) {
            episodes
        } else {
            // Fallback placeholder so the series still appears in the catalog
            listOf(
                StreamEntity(
                    playlistId = playlistId,
                    streamId = "series_$seriesId",
                    name = seriesName,
                    streamUrl = "$base/series/$cleanUser/$cleanPass/$seriesId.mp4",
                    logoUrl = cover,
                    category = catName,
                    type = ChannelType.SERIES,
                    rating = rating,
                    plot = plot,
                    seriesId = seriesName,
                    seasonNumber = 1,
                    episodeNumber = 1
                )
            )
        }
    }

    suspend fun fetchSeriesEpisodes(
        serverUrl: String,
        user: String,
        pass: String,
        playlistId: Long,
        seriesId: String,
        seriesName: String,
        catName: String,
        cover: String?,
        plot: String?,
        rating: String?
    ): List<StreamEntity> = withContext(Dispatchers.IO) {
        val base = sanitizeServerUrl(serverUrl)
        val cleanUser = user.trim()
        val cleanPass = pass.trim()
        val episodesList = mutableListOf<StreamEntity>()

        try {
            val seriesInfoUrl = "$base/player_api.php?username=$cleanUser&password=$cleanPass&action=get_series_info&series_id=$seriesId"
            val seriesInfoJson = fetchJsonObject(seriesInfoUrl) ?: return@withContext emptyList()

            val infoObj = seriesInfoJson.optJSONObject("info")
            val effectivePlot = infoObj?.optString("plot")?.takeIf { it.isNotBlank() } ?: plot
            val effectiveCover = infoObj?.optString("cover")?.takeIf { it.isNotBlank() }
                ?: infoObj?.optString("backdrop_path")?.takeIf { it.isNotBlank() }
                ?: cover
            val effectiveRating = infoObj?.optString("rating")?.takeIf { it.isNotBlank() } ?: rating

            val episodesObj = seriesInfoJson.optJSONObject("episodes")
            val episodesArray = seriesInfoJson.optJSONArray("episodes")

            if (episodesObj != null) {
                val seasonKeys = episodesObj.keys()
                while (seasonKeys.hasNext()) {
                    val seasonKey = seasonKeys.next()
                    val seasonNum = seasonKey.toIntOrNull() ?: 1
                    val seasonEpisodes = episodesObj.optJSONArray(seasonKey) ?: continue
                    for (e in 0 until seasonEpisodes.length()) {
                        val epObj = seasonEpisodes.optJSONObject(e) ?: continue
                        val epEntity = parseEpisode(
                            epObj = epObj,
                            base = base,
                            cleanUser = cleanUser,
                            cleanPass = cleanPass,
                            playlistId = playlistId,
                            seriesName = seriesName,
                            catName = catName,
                            defaultSeason = seasonNum,
                            fallbackCover = effectiveCover,
                            fallbackPlot = effectivePlot,
                            fallbackRating = effectiveRating,
                            index = e + 1
                        )
                        if (epEntity != null) {
                            episodesList.add(epEntity)
                        }
                    }
                }
            } else if (episodesArray != null) {
                for (e in 0 until episodesArray.length()) {
                    val epObj = episodesArray.optJSONObject(e) ?: continue
                    val epEntity = parseEpisode(
                        epObj = epObj,
                        base = base,
                        cleanUser = cleanUser,
                        cleanPass = cleanPass,
                        playlistId = playlistId,
                        seriesName = seriesName,
                        catName = catName,
                        defaultSeason = 1,
                        fallbackCover = effectiveCover,
                        fallbackPlot = effectivePlot,
                        fallbackRating = effectiveRating,
                        index = e + 1
                    )
                    if (epEntity != null) {
                        episodesList.add(epEntity)
                    }
                }
            }
        } catch (_: Exception) { }

        episodesList
    }

    private fun parseEpisode(
        epObj: JSONObject,
        base: String,
        cleanUser: String,
        cleanPass: String,
        playlistId: Long,
        seriesName: String,
        catName: String,
        defaultSeason: Int,
        fallbackCover: String?,
        fallbackPlot: String?,
        fallbackRating: String?,
        index: Int
    ): StreamEntity? {
        // 1. Episode ID: must use REAL episode ID, NOT the series ID!
        val epId = epObj.optString("id").ifBlank {
            epObj.optInt("id", 0).takeIf { it > 0 }?.toString()
                ?: epObj.optString("stream_id").ifBlank {
                    epObj.optInt("stream_id", 0).takeIf { it > 0 }?.toString() ?: ""
                }
        }
        if (epId.isBlank()) return null

        // 2. Season and Episode numbers
        val seasonNum = epObj.optString("season").toIntOrNull()
            ?: epObj.optInt("season", defaultSeason)
        val epNum = epObj.optString("episode_num").toIntOrNull()
            ?: epObj.optInt("episode_num", index)

        // 3. Container extension (mp4, mkv, etc.)
        val ext = epObj.optString("container_extension")
            .trim()
            .trimStart('.')
            .ifBlank { "mp4" }

        // 4. Correct episode playback URL using episode ID and container extension!
        val playUrl = "$base/series/$cleanUser/$cleanPass/$epId.$ext"

        // 5. Episode metadata
        val rawTitle = epObj.optString("title").trim()
        val epTitle = when {
            rawTitle.isNotBlank() && (rawTitle.startsWith("S", ignoreCase = true) || rawTitle.contains("Ep", ignoreCase = true) || rawTitle.contains("حلقة", ignoreCase = true)) -> rawTitle
            rawTitle.isNotBlank() -> "S${seasonNum}E${epNum} - $rawTitle"
            else -> "S${seasonNum}E${epNum}"
        }

        val epInfo = epObj.optJSONObject("info")
        val epPlot = epInfo?.optString("plot")?.takeIf { it.isNotBlank() } ?: fallbackPlot
        val epLogo = epInfo?.optString("movie_image")?.takeIf { it.isNotBlank() } ?: fallbackCover

        return StreamEntity(
            playlistId = playlistId,
            streamId = epId,
            name = epTitle,
            streamUrl = playUrl,
            logoUrl = epLogo,
            category = catName,
            type = ChannelType.SERIES,
            rating = fallbackRating,
            plot = epPlot,
            seriesId = seriesName,
            seasonNumber = seasonNum,
            episodeNumber = epNum
        )
    }

    private suspend fun fetchCategoriesMap(
        base: String,
        user: String,
        pass: String,
        action: String
    ): Map<String, String> {
        val map = mutableMapOf<String, String>()
        try {
            val url = "$base/player_api.php?username=$user&password=$pass&action=$action"
            val array = fetchJsonArray(url)
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val id = obj.optString("category_id")
                val name = obj.optString("category_name")
                if (id.isNotBlank() && name.isNotBlank()) {
                    map[id] = name
                }
            }
        } catch (_: Exception) { }
        return map
    }

    private fun fetchJsonArray(url: String): JSONArray {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept", "application/json, text/plain, */*")
            .build()
        val response = client.newCall(request).execute()
        val body = response.body?.string()?.trim() ?: "[]"
        return if (body.startsWith("[")) {
            JSONArray(body)
        } else {
            JSONArray()
        }
    }

    private fun fetchJsonObject(url: String): JSONObject? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept", "application/json, text/plain, */*")
            .build()
        val response = client.newCall(request).execute()
        val body = response.body?.string()?.trim() ?: return null
        return if (body.startsWith("{")) JSONObject(body) else null
    }
}

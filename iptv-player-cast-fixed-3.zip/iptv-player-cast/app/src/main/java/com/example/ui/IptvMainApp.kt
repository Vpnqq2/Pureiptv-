package com.example.ui

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdsController
import com.example.analytics.AppAnalytics
import com.example.player.VideoPlayerComposable
import com.example.ui.components.AddPlaylistDialog
import com.example.ui.components.CastBottomSheet
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppStrings
import com.example.ui.screens.EpgScreen
import com.example.ui.screens.FavoritesHistoryScreen
import com.example.ui.screens.LiveTvScreen
import com.example.ui.screens.PlaylistsScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SeriesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VodMoviesScreen
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.LiveRed
import com.example.ui.theme.PrimaryBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IptvMainApp(
    viewModel: MainViewModel
) {
    val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val isHwAcceleration by viewModel.isHwAccelerationEnabled.collectAsStateWithLifecycle()
    val isAutoPlayNext by viewModel.isAutoPlayNextEnabled.collectAsStateWithLifecycle()

    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val playingStream by viewModel.currentPlayingStream.collectAsStateWithLifecycle()

    val activePlaylist by viewModel.activePlaylist.collectAsStateWithLifecycle()
    val allPlaylists by viewModel.allPlaylists.collectAsStateWithLifecycle()

    val liveChannels by viewModel.liveChannels.collectAsStateWithLifecycle()
    val liveCategories by viewModel.liveCategorySummaries.collectAsStateWithLifecycle()

    val movies by viewModel.movies.collectAsStateWithLifecycle()
    val movieCategories by viewModel.movieCategorySummaries.collectAsStateWithLifecycle()

    val series by viewModel.series.collectAsStateWithLifecycle()
    val seriesCategories by viewModel.seriesCategorySummaries.collectAsStateWithLifecycle()

    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val epgMap by viewModel.epgMap.collectAsStateWithLifecycle()
    val epgTimeOffsetHours by viewModel.epgTimeOffsetHours.collectAsStateWithLifecycle()
    val isEpgSyncing by viewModel.isEpgSyncing.collectAsStateWithLifecycle()
    val epgSyncStatus by viewModel.epgSyncStatus.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()

    val isAddPlaylistOpen by viewModel.isAddPlaylistOpen.collectAsStateWithLifecycle()
    val isImporting by viewModel.isImporting.collectAsStateWithLifecycle()
    val importMessage by viewModel.importMessage.collectAsStateWithLifecycle()

    val strings = AppStrings.get(currentLanguage)

    val context = LocalContext.current
    var lastBackPressTime by remember { mutableLongStateOf(0L) }
    var isCastDialogOpen by remember { mutableStateOf(false) }

    // Analytics: one screen_view per tab change
    LaunchedEffect(currentScreen) { AppAnalytics.logScreen(currentScreen.name.lowercase()) }

    // Every "tap to watch" goes through here: an interstitial may show first (see AdsController for the timing rules).
    val playStream: (com.example.data.model.StreamItem) -> Unit = { stream ->
        AppAnalytics.logPlay(stream.type.name.lowercase())
        AdsController.maybeShowInterstitial(context as? Activity) { viewModel.setPlayingStream(stream) }
    }

    // Handle System Back button safely
    BackHandler(enabled = true) {
        if (isCastDialogOpen) {
            isCastDialogOpen = false
            lastBackPressTime = 0L
        } else if (playingStream != null) {
            viewModel.setPlayingStream(null)
            lastBackPressTime = 0L
        } else if (isAddPlaylistOpen) {
            viewModel.setAddPlaylistOpen(false)
            lastBackPressTime = 0L
        } else if (searchQuery.isNotBlank()) {
            viewModel.setSearchQuery("")
            lastBackPressTime = 0L
        } else if (viewModel.popScreen()) {
            // Popped to previous screen in history
            lastBackPressTime = 0L
        } else if (currentScreen != AppNavScreen.LIVE_TV) {
            viewModel.setScreen(AppNavScreen.LIVE_TV)
            lastBackPressTime = 0L
        } else {
            val now = System.currentTimeMillis()
            if (now - lastBackPressTime < 2000L) {
                (context as? Activity)?.finish()
            } else {
                lastBackPressTime = now
                val msg = if (currentLanguage == AppLanguage.SPANISH) {
                    "Presione atrás nuevamente para salir"
                } else {
                    "Press back again to exit"
                }
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Main content stays composed underneath the player, so its state
        // (selected category, scroll position...) survives opening/closing a channel.
        Scaffold(
            contentWindowInsets = androidx.compose.foundation.layout.WindowInsets.navigationBars,
            topBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface)
                        .statusBarsPadding()
                ) {
                    // Top Bar: [≡] [playlist_name] [Search] [Cast] [Add] [Language Toggle]
                    TopAppBar(
                        windowInsets = androidx.compose.foundation.layout.WindowInsets(0.dp),
                        navigationIcon = {
                            IconButton(onClick = { viewModel.setScreen(AppNavScreen.SETTINGS) }) {
                                Icon(
                                    Icons.Default.Menu,
                                    contentDescription = "Menu",
                                    tint = Color.White
                                )
                            }
                        },
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable { viewModel.setScreen(AppNavScreen.PLAYLISTS) }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .background(LiveRed, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = activePlaylist?.name ?: strings.appName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        actions = {
                            // Search
                            IconButton(onClick = { viewModel.setScreen(AppNavScreen.SEARCH) }) {
                                Icon(
                                    Icons.Default.Search,
                                    contentDescription = "Search",
                                    tint = if (currentScreen == AppNavScreen.SEARCH) AccentCyan else Color.White
                                )
                            }

                            // Cast Icon
                            IconButton(onClick = { isCastDialogOpen = true }) {
                                Icon(
                                    Icons.Default.Cast,
                                    contentDescription = "Cast",
                                    tint = if (isCastDialogOpen) AccentCyan else Color.White
                                )
                            }

                            // Add Playlist
                            IconButton(onClick = { viewModel.setAddPlaylistOpen(true) }) {
                                Icon(
                                    Icons.Default.Add,
                                    contentDescription = "Add Playlist",
                                    tint = Color.White
                                )
                            }

                            // Quick Language Switcher Button (EN / ES / AR)
                            IconButton(onClick = {
                                val nextLang = when (currentLanguage) {
                                    AppLanguage.ENGLISH -> AppLanguage.SPANISH
                                    AppLanguage.SPANISH -> AppLanguage.ARABIC
                                    AppLanguage.ARABIC -> AppLanguage.ENGLISH
                                }
                                viewModel.setLanguage(nextLang)
                            }) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = DarkSurfaceVariant,
                                    modifier = Modifier.padding(2.dp)
                                ) {
                                    Text(
                                        text = when (currentLanguage) {
                                            AppLanguage.ENGLISH -> "EN"
                                            AppLanguage.SPANISH -> "ES"
                                            AppLanguage.ARABIC -> "AR"
                                        },
                                        color = AccentCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = DarkSurface
                        )
                    )

                    // Top Tab Row: PLAYLISTS | FAVORITES | LIVE | MOVIES | SERIES | EPG | SETTINGS
                    val tabs = listOf(
                        AppNavScreen.PLAYLISTS to strings.navPlaylists,
                        AppNavScreen.FAVORITES to strings.navFavorites,
                        AppNavScreen.LIVE_TV to strings.navLive,
                        AppNavScreen.MOVIES to strings.navMovies,
                        AppNavScreen.SERIES to strings.navSeries,
                        AppNavScreen.EPG to strings.navEpg,
                        AppNavScreen.SETTINGS to strings.navSettings
                    )

                    val selectedIndex = tabs.indexOfFirst { it.first == currentScreen }.coerceAtLeast(0)

                    ScrollableTabRow(
                        selectedTabIndex = selectedIndex,
                        containerColor = DarkSurface,
                        contentColor = PrimaryBlue,
                        edgePadding = 8.dp,
                        indicator = { tabPositions ->
                            if (selectedIndex < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                                    height = 3.dp,
                                    color = PrimaryBlue
                                )
                            }
                        },
                        divider = {},
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        tabs.forEachIndexed { index, (screen, label) ->
                            val isSelected = currentScreen == screen
                            Tab(
                                selected = isSelected,
                                onClick = { viewModel.setScreen(screen) },
                                text = {
                                    Text(
                                        text = label.uppercase(),
                                        color = if (isSelected) Color.White else Color(0xFF9E9E9E),
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 13.sp
                                    )
                                }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition",
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) { screen ->
                when (screen) {
                    AppNavScreen.PLAYLISTS -> PlaylistsScreen(
                        playlists = allPlaylists,
                        activePlaylist = activePlaylist,
                        strings = strings,
                        onSelectActivePlaylist = { id -> viewModel.selectActivePlaylist(id) },
                        onDeletePlaylist = { id -> viewModel.deletePlaylist(id) },
                        onOpenAddPlaylist = { viewModel.setAddPlaylistOpen(true) }
                    )

                    AppNavScreen.LIVE_TV -> LiveTvScreen(
                        channels = liveChannels,
                        categories = liveCategories,
                        strings = strings,
                        onPlayChannel = playStream,
                        onToggleFavorite = { ch -> viewModel.toggleFavorite(ch) },
                        onOpenAddPlaylist = { viewModel.setAddPlaylistOpen(true) },
                        epgMap = epgMap
                    )

                    AppNavScreen.MOVIES -> VodMoviesScreen(
                        movies = movies,
                        categories = movieCategories,
                        strings = strings,
                        onPlayMovie = playStream,
                        onToggleFavorite = { m -> viewModel.toggleFavorite(m) }
                    )

                    AppNavScreen.SERIES -> SeriesScreen(
                        seriesList = series,
                        categories = seriesCategories,
                        strings = strings,
                        onPlayEpisode = playStream,
                        onToggleFavorite = { s -> viewModel.toggleFavorite(s) }
                    )

                    AppNavScreen.EPG -> EpgScreen(
                        channels = liveChannels,
                        epgMap = epgMap,
                        isSyncing = isEpgSyncing,
                        syncStatus = epgSyncStatus,
                        timeOffsetHours = epgTimeOffsetHours,
                        strings = strings,
                        onPlayChannel = playStream,
                        onSyncEpg = { customUrl -> viewModel.syncEpg(customUrl) },
                        onSetTimeOffset = { offset -> viewModel.setEpgTimeOffset(offset) }
                    )

                    AppNavScreen.FAVORITES -> FavoritesHistoryScreen(
                        favorites = favorites,
                        history = history,
                        strings = strings,
                        onPlayStream = playStream,
                        onToggleFavorite = { st -> viewModel.toggleFavorite(st) }
                    )

                    AppNavScreen.SETTINGS -> SettingsScreen(
                        activePlaylist = activePlaylist,
                        currentLanguage = currentLanguage,
                        isHwAcceleration = isHwAcceleration,
                        isAutoPlayNext = isAutoPlayNext,
                        strings = strings,
                        onSelectLanguage = { lang -> viewModel.setLanguage(lang) },
                        onToggleHwAcceleration = { enabled -> viewModel.toggleHwAcceleration(enabled) },
                        onToggleAutoPlayNext = { enabled -> viewModel.toggleAutoPlayNext(enabled) },
                        onClearHistory = { viewModel.clearHistory() },
                        onNavigateToPlaylists = { viewModel.setScreen(AppNavScreen.PLAYLISTS) },
                        onShowWelcome = { viewModel.showWelcomeScreen() }
                    )

                    AppNavScreen.SEARCH -> SearchScreen(
                        searchQuery = searchQuery,
                        onQueryChange = { viewModel.setSearchQuery(it) },
                        searchResults = searchResults,
                        strings = strings,
                        onPlayStream = playStream,
                        onToggleFavorite = { st -> viewModel.toggleFavorite(st) }
                    )
                }
            }
        }

        // Full Video Player overlay (drawn on top; its BackHandler has priority)
        val activeStream = playingStream
        if (activeStream != null) {
            val currentCategoryStreams = when (activeStream.type) {
                com.example.data.model.ChannelType.LIVE -> liveChannels.filter { it.category == activeStream.category }
                com.example.data.model.ChannelType.MOVIE -> movies.filter { it.category == activeStream.category }
                com.example.data.model.ChannelType.SERIES -> series.filter { it.seriesId == activeStream.seriesId }
            }

            val activeEpgPrograms = remember(activeStream, epgMap) {
                epgMap[activeStream.epgChannelId ?: activeStream.streamId] ?: epgMap[activeStream.streamId] ?: epgMap[activeStream.name] ?: emptyList()
            }

            VideoPlayerComposable(
                stream = activeStream,
                allStreamsInCat = currentCategoryStreams,
                epgPrograms = activeEpgPrograms,
                onClosePlayer = { viewModel.setPlayingStream(null) },
                onSelectStream = { newStream -> viewModel.setPlayingStream(newStream) },
                onToggleFavorite = { stream -> viewModel.toggleFavorite(stream) },
                onProgressUpdate = { pos, dur ->
                    viewModel.saveWatchProgress(activeStream.id, pos, dur)
                },
                language = currentLanguage,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Add Playlist Dialog Modal
        if (isAddPlaylistOpen) {
            AddPlaylistDialog(
                strings = strings,
                isLoading = isImporting,
                errorMessage = importMessage,
                onDismiss = { viewModel.setAddPlaylistOpen(false) },
                onImportM3u = { name, url -> viewModel.importM3u(name, url) },
                onImportXtream = { name, server, user, pass ->
                    viewModel.importXtream(name, server, user, pass)
                }
            )
        }

        // Cast to TV BottomSheet
        if (isCastDialogOpen) {
            CastBottomSheet(
                onDismissRequest = { isCastDialogOpen = false },
                activeStream = playingStream,
                language = currentLanguage
            )
        }
    }
}

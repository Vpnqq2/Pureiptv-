package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.EpgProgramEntity
import com.example.data.local.IptvDatabase
import com.example.data.model.CategorySummary
import com.example.data.model.ChannelType
import com.example.data.model.PlaylistItem
import com.example.data.model.PlaylistType
import com.example.data.model.StreamItem
import com.example.data.parser.XmltvParser
import com.example.data.repo.IptvRepository
import com.example.ui.i18n.AppLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppStartupState {
    SPLASH,
    WELCOME,
    MAIN_APP
}

enum class AppNavScreen {
    PLAYLISTS,
    LIVE_TV,
    MOVIES,
    SERIES,
    EPG,
    FAVORITES,
    SETTINGS,
    SEARCH
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = IptvDatabase.getInstance(application)
    private val repository = IptvRepository(db.iptvDao(), database = db)
    private val prefs = application.getSharedPreferences("iptv_player_prefs", Context.MODE_PRIVATE)

    // Startup State (SPLASH -> WELCOME -> MAIN_APP)
    private val _startupState = MutableStateFlow(AppStartupState.SPLASH)
    val startupState: StateFlow<AppStartupState> = _startupState.asStateFlow()

    fun onSplashFinished() {
        val hasCompletedWelcome = prefs.getBoolean("has_completed_welcome", false)
        _startupState.value = if (hasCompletedWelcome) AppStartupState.MAIN_APP else AppStartupState.WELCOME
    }

    fun completeWelcome(
        openAddXtream: Boolean = false,
        openAddM3u: Boolean = false
    ) {
        prefs.edit().putBoolean("has_completed_welcome", true).apply()
        _startupState.value = AppStartupState.MAIN_APP
        if (openAddXtream || openAddM3u) {
            setAddPlaylistOpen(true)
        }
    }

    fun showWelcomeScreen() {
        _startupState.value = AppStartupState.WELCOME
    }

    // Language State (ENGLISH / SPANISH / ARABIC)
    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Player Preferences
    private val _isHwAccelerationEnabled = MutableStateFlow(true)
    val isHwAccelerationEnabled: StateFlow<Boolean> = _isHwAccelerationEnabled.asStateFlow()

    private val _isAutoPlayNextEnabled = MutableStateFlow(true)
    val isAutoPlayNextEnabled: StateFlow<Boolean> = _isAutoPlayNextEnabled.asStateFlow()

    // Navigation State
    private val _currentScreen = MutableStateFlow(AppNavScreen.LIVE_TV)
    val currentScreen: StateFlow<AppNavScreen> = _currentScreen.asStateFlow()

    // Video Player Active Stream
    private val _currentPlayingStream = MutableStateFlow<StreamItem?>(null)
    val currentPlayingStream: StateFlow<StreamItem?> = _currentPlayingStream.asStateFlow()

    // Dialog & Loading
    private val _isAddPlaylistOpen = MutableStateFlow(false)
    val isAddPlaylistOpen: StateFlow<Boolean> = _isAddPlaylistOpen.asStateFlow()

    private val _isImporting = MutableStateFlow(false)
    val isImporting: StateFlow<Boolean> = _isImporting.asStateFlow()

    private val _importMessage = MutableStateFlow<String?>(null)
    val importMessage: StateFlow<String?> = _importMessage.asStateFlow()

    // Playlists
    val allPlaylists: StateFlow<List<PlaylistItem>> = repository.allPlaylists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activePlaylist: StateFlow<PlaylistItem?> = repository.activePlaylist
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Streams by Active Playlist
    val liveChannels: StateFlow<List<StreamItem>> = activePlaylist.flatMapLatest { pl ->
        if (pl != null) repository.getStreams(pl.id, ChannelType.LIVE) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val liveCategories: StateFlow<List<String>> = activePlaylist.flatMapLatest { pl ->
        if (pl != null) repository.getCategories(pl.id, ChannelType.LIVE) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val liveCategorySummaries: StateFlow<List<CategorySummary>> = activePlaylist.flatMapLatest { pl ->
        if (pl != null) repository.getCategoriesWithCounts(pl.id, ChannelType.LIVE) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val movies: StateFlow<List<StreamItem>> = activePlaylist.flatMapLatest { pl ->
        if (pl != null) repository.getStreams(pl.id, ChannelType.MOVIE) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val movieCategories: StateFlow<List<String>> = activePlaylist.flatMapLatest { pl ->
        if (pl != null) repository.getCategories(pl.id, ChannelType.MOVIE) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val movieCategorySummaries: StateFlow<List<CategorySummary>> = activePlaylist.flatMapLatest { pl ->
        if (pl != null) repository.getCategoriesWithCounts(pl.id, ChannelType.MOVIE) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val series: StateFlow<List<StreamItem>> = activePlaylist.flatMapLatest { pl ->
        if (pl != null) repository.getStreams(pl.id, ChannelType.SERIES) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val seriesCategories: StateFlow<List<String>> = activePlaylist.flatMapLatest { pl ->
        if (pl != null) repository.getCategories(pl.id, ChannelType.SERIES) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val seriesCategorySummaries: StateFlow<List<CategorySummary>> = activePlaylist.flatMapLatest { pl ->
        if (pl != null) repository.getCategoriesWithCounts(pl.id, ChannelType.SERIES) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<StreamItem>> = repository.getAllFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<StreamItem>> = repository.getWatchHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- EPG Management (Non-blocking, reactive Flow combining) ---
    private val _epgTimeOffsetHours = MutableStateFlow(prefs.getInt("epg_time_offset_hours", 0))
    val epgTimeOffsetHours: StateFlow<Int> = _epgTimeOffsetHours.asStateFlow()

    private val _isEpgSyncing = MutableStateFlow(false)
    val isEpgSyncing: StateFlow<Boolean> = _isEpgSyncing.asStateFlow()

    private val _epgSyncStatus = MutableStateFlow<String?>(null)
    val epgSyncStatus: StateFlow<String?> = _epgSyncStatus.asStateFlow()

    val epgProgramCount: StateFlow<Int> = repository.getEpgProgramCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val epgMap: StateFlow<Map<String, List<EpgProgramEntity>>> = combine(
        liveChannels,
        repository.getAllUpcomingEpgFlow(),
        _epgTimeOffsetHours
    ) { channels, allPrograms, offsetHours ->
        withContext(Dispatchers.Default) {
            buildEpgMap(channels, allPrograms, offsetHours)
        }
    }.flowOn(Dispatchers.Default)
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<StreamItem>> = combine(
        activePlaylist,
        _searchQuery
    ) { pl: PlaylistItem?, query: String ->
        Pair(pl?.id ?: 0L, query)
    }.flatMapLatest { (playlistId, query) ->
        if (query.isBlank()) {
            flowOf(emptyList())
        } else {
            repository.searchStreams(playlistId, query)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val screenStack = mutableListOf(AppNavScreen.LIVE_TV)

    init {
        viewModelScope.launch {
            repository.purgeSampleData()
            // Ensure EPG data exists immediately if DB is empty
            if (repository.getEpgCountOnce() == 0) {
                repository.loadSampleEpg()
            }
        }
    }

    private fun buildEpgMap(
        channels: List<StreamItem>,
        allPrograms: List<EpgProgramEntity>,
        offsetHours: Int
    ): Map<String, List<EpgProgramEntity>> {
        if (channels.isEmpty() || allPrograms.isEmpty()) return emptyMap()

        val offsetMillis = offsetHours * 3600_000L
        val adjusted = if (offsetMillis == 0L) {
            allPrograms
        } else {
            allPrograms.map { it.copy(startEpoch = it.startEpoch + offsetMillis, endEpoch = it.endEpoch + offsetMillis) }
        }

        val byChannel = adjusted.groupBy { it.channelId }
        val byNormalizedId = mutableMapOf<String, List<EpgProgramEntity>>()
        byChannel.forEach { (id, progs) ->
            val norm = XmltvParser.normalizeName(id)
            if (norm.isNotBlank()) {
                byNormalizedId[norm] = progs
            }
        }

        val map = HashMap<String, List<EpgProgramEntity>>(channels.size * 2)

        channels.forEach { ch ->
            var matched: List<EpgProgramEntity>? = ch.epgChannelId?.let { byChannel[it] }

            if (matched == null) {
                matched = byChannel[ch.streamId]
            }
            if (matched == null) {
                matched = byChannel[ch.name]
            }
            if (matched == null && !ch.epgChannelId.isNullOrBlank()) {
                val normEpg = XmltvParser.normalizeName(ch.epgChannelId)
                matched = byNormalizedId[normEpg]
            }
            if (matched == null) {
                val normName = XmltvParser.normalizeName(ch.name)
                matched = byNormalizedId[normName]
            }

            if (!matched.isNullOrEmpty()) {
                val sorted = matched.sortedBy { it.startEpoch }
                map[ch.streamId] = sorted
                if (!ch.epgChannelId.isNullOrBlank()) {
                    map[ch.epgChannelId] = sorted
                }
                map[ch.name] = sorted
            }
        }

        return map
    }

    fun syncEpg(customUrl: String? = null) {
        viewModelScope.launch {
            _isEpgSyncing.value = true
            _epgSyncStatus.value = if (_currentLanguage.value == AppLanguage.ARABIC) "جاري تحديث دليل البرامج..." else "Syncing EPG data..."
            try {
                val pl = activePlaylist.value
                val targetUrl = customUrl?.trim()?.ifBlank { null } ?: pl?.epgUrl
                val result = when {
                    !targetUrl.isNullOrBlank() -> repository.importXmltv(targetUrl, pl?.id)
                    pl?.type == PlaylistType.XTREAM && !pl.username.isNullOrBlank() -> {
                        repository.importXtreamEpg(pl.sourceUrl, pl.username, pl.password ?: "", pl.id)
                    }
                    else -> {
                        val count = repository.loadSampleEpg()
                        Result.success(count)
                    }
                }
                if (result.isSuccess) {
                    val count = result.getOrDefault(0)
                    _epgSyncStatus.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
                        "تم تحديث الدليل: $count برنامج"
                    } else {
                        "EPG updated: $count programs"
                    }
                } else {
                    val errorMsg = result.exceptionOrNull()?.localizedMessage ?: "Failed"
                    _epgSyncStatus.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
                        "خطأ في تحميل الدليل: $errorMsg"
                    } else {
                        "EPG sync: $errorMsg"
                    }
                }
            } catch (e: Exception) {
                _epgSyncStatus.value = "EPG sync error: ${e.localizedMessage}"
            } finally {
                _isEpgSyncing.value = false
            }
        }
    }

    fun setEpgTimeOffset(hours: Int) {
        val clamped = hours.coerceIn(-12, 12)
        _epgTimeOffsetHours.value = clamped
        prefs.edit().putInt("epg_time_offset_hours", clamped).apply()
    }

    fun setScreen(screen: AppNavScreen) {
        if (_currentScreen.value != screen) {
            screenStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun popScreen(): Boolean {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.lastIndex)
            _currentScreen.value = screenStack.last()
            return true
        }
        return false
    }

    fun setLanguage(lang: AppLanguage) {
        _currentLanguage.value = lang
    }

    fun toggleHwAcceleration(enabled: Boolean) {
        _isHwAccelerationEnabled.value = enabled
    }

    fun toggleAutoPlayNext(enabled: Boolean) {
        _isAutoPlayNextEnabled.value = enabled
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearWatchHistory()
        }
    }

    fun setPlayingStream(stream: StreamItem?) {
        _currentPlayingStream.value = stream
    }

    fun setAddPlaylistOpen(open: Boolean) {
        _isAddPlaylistOpen.value = open
        _importMessage.value = null
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFavorite(stream: StreamItem) {
        viewModelScope.launch {
            repository.toggleFavorite(stream.id, stream.isFavorite)
        }
    }

    fun saveWatchProgress(streamId: Long, progressMs: Long, durationMs: Long) {
        viewModelScope.launch {
            repository.recordWatchProgress(streamId, progressMs, durationMs)
        }
    }

    fun selectActivePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.setActivePlaylist(playlistId)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
        }
    }

    fun importM3u(name: String, url: String, epgUrl: String? = null) {
        viewModelScope.launch {
            _isImporting.value = true
            _importMessage.value = null
            val result = repository.importM3uUrl(name, url, epgUrl)
            _isImporting.value = false
            if (result.isSuccess) {
                _isAddPlaylistOpen.value = false
                // Trigger background EPG sync without blocking channel completion
                syncEpg(epgUrl)
            } else {
                _importMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to import M3U"
            }
        }
    }

    fun importXtream(name: String, server: String, user: String, pass: String, epgUrl: String? = null) {
        viewModelScope.launch {
            _isImporting.value = true
            _importMessage.value = null
            val result = repository.importXtream(name, server, user, pass, epgUrl)
            _isImporting.value = false
            if (result.isSuccess) {
                _isAddPlaylistOpen.value = false
                // Trigger background EPG sync without blocking channel completion
                syncEpg(epgUrl)
            } else {
                _importMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Xtream login error"
            }
        }
    }
}

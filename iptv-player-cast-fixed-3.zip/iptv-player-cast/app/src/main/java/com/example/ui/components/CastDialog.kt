package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PersistableBundle
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.cast.CastDeviceInfo
import com.example.cast.CastError
import com.example.cast.CastManager
import com.example.cast.CastProtocol
import com.example.cast.CastSessionState
import com.example.data.model.StreamItem
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private val ErrorRed = Color(0xFFFF6B6B)

fun castErrorText(strings: AppStrings.Strings, e: CastError): String = when (e) {
    CastError.NO_PLAY_SERVICES -> strings.castErrNoPlayServices
    CastError.NO_WIFI -> strings.castErrNoWifi
    CastError.CONNECTION_FAILED -> strings.castErrConnection
    CastError.DEVICE_LOST -> strings.castErrDeviceLost
    CastError.AUTH_REQUIRED -> strings.castErrAuth
    CastError.NOT_FOUND -> strings.castErrNotFound
    CastError.UNREACHABLE -> strings.castErrUnreachable
    CastError.TLS -> strings.castErrTls
    CastError.UNSUPPORTED_FORMAT -> strings.castErrUnsupported
    CastError.RELAY_FAILED -> strings.castErrRelay
    CastError.INVALID_URL -> strings.castErrInvalidUrl
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CastBottomSheet(
    onDismissRequest: () -> Unit,
    activeStream: StreamItem? = null,
    language: AppLanguage = AppLanguage.ENGLISH
) {
    val context = LocalContext.current
    CastManager.init(context)
    val strings = AppStrings.get(language)
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val state by CastManager.state.collectAsStateWithLifecycle()
    val devices by CastManager.devices.collectAsStateWithLifecycle()
    val status by CastManager.status.collectAsStateWithLifecycle()
    val scanning by CastManager.scanning.collectAsStateWithLifecycle()
    val error by CastManager.lastError.collectAsStateWithLifecycle()
    val googleAvailable by CastManager.googleAvailable.collectAsStateWithLifecycle()

    // Discovery only runs while the picker is visible (battery + privacy).
    DisposableEffect(Unit) {
        CastManager.startDiscovery()
        onDispose { CastManager.stopDiscovery() }
    }

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        containerColor = DarkSurface,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .background(Color.White.copy(alpha = 0.2f), CircleShape)
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(PrimaryBlue.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.CastConnected, contentDescription = "Cast", tint = AccentCyan, modifier = Modifier.size(26.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(strings.castTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(strings.castSubtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
            Spacer(Modifier.height(16.dp))

            // Errors (stream problems, connection problems)
            val shownError: CastError? = error ?: (state as? CastSessionState.Failed)?.error ?: status.error
            if (shownError != null) {
                ErrorCard(castErrorText(strings, shownError))
                Spacer(Modifier.height(12.dp))
            }
            if (googleAvailable == false && shownError == null) {
                Text(strings.castErrNoPlayServices, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                Spacer(Modifier.height(12.dp))
            }

            when (val s = state) {
                is CastSessionState.Connected -> ConnectedPanel(
                    deviceName = s.deviceName,
                    protocol = s.protocol,
                    strings = strings,
                    isPlaying = status.isPlaying,
                    hasMedia = status.hasMedia,
                    volume = status.volume,
                    nowCasting = activeStream?.name,
                    onPlayPause = { if (status.isPlaying) CastManager.pause() else CastManager.play() },
                    onVolume = { CastManager.setVolume(it) },
                    onDisconnect = { CastManager.disconnect() }
                )

                is CastSessionState.Connecting -> BusyRow(String.format(strings.castConnecting, s.deviceName))
                is CastSessionState.Reconnecting -> BusyRow(String.format(strings.castReconnecting, s.deviceName))
                else -> DevicePicker(
                    devices = devices,
                    scanning = scanning,
                    strings = strings,
                    onPick = { CastManager.connect(it) },
                    onRescan = { CastManager.startDiscovery() }
                )
            }

            // Fallbacks: always available, never fake
            if (activeStream != null) {
                Spacer(Modifier.height(18.dp))
                CastOptionCard(
                    icon = Icons.Default.OpenInNew,
                    title = strings.castExternalTitle,
                    subtitle = "${strings.castExternalDesc} (${activeStream.name})",
                    buttonText = strings.castViaApp,
                    onClick = { openExternalPlayer(context, activeStream, strings) }
                )
                Spacer(Modifier.height(10.dp))
                CastOptionCard(
                    icon = Icons.Default.ContentCopy,
                    title = strings.castTempLink,
                    subtitle = strings.castExternalDesc,
                    buttonText = strings.copyUrl,
                    onClick = { copyTemporaryLink(context, activeStream, strings) }
                )
            }
            Spacer(Modifier.height(10.dp))
            CastOptionCard(
                icon = Icons.Default.Tv,
                title = strings.castSettingsTitle,
                subtitle = strings.castMirrorNote,
                buttonText = strings.openSettings,
                onClick = { openSystemCastSettings(context) }
            )

            Spacer(Modifier.height(18.dp))
            HowToCard(strings)

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onDismissRequest,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(44.dp)
            ) { Text(strings.close, color = Color.White, fontWeight = FontWeight.Medium) }
        }
    }
}

@Composable
private fun DevicePicker(
    devices: List<CastDeviceInfo>,
    scanning: Boolean,
    strings: AppStrings.Strings,
    onPick: (CastDeviceInfo) -> Unit,
    onRescan: () -> Unit
) {
    if (devices.isEmpty()) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                if (scanning) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = AccentCyan)
                        Spacer(Modifier.width(10.dp))
                        Text(strings.castScanning, color = TextPrimary, fontSize = 13.sp)
                    }
                } else {
                    Text(strings.castNoDevices, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(strings.castNoDevicesHint, color = TextSecondary, fontSize = 12.sp, lineHeight = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onRescan() }.padding(vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Refresh, null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.castRescan, color = AccentCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        return
    }
    devices.forEach { d ->
        CastOptionCard(
            icon = if (d.protocol == CastProtocol.GOOGLE_CAST) Icons.Default.Cast else Icons.Default.Tv,
            title = d.name,
            subtitle = if (d.protocol == CastProtocol.GOOGLE_CAST) "Google Cast" else "DLNA / UPnP",
            buttonText = "▶",
            onClick = { onPick(d) }
        )
        Spacer(Modifier.height(10.dp))
    }
    if (scanning) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = AccentCyan)
            Spacer(Modifier.width(8.dp))
            Text(strings.castScanning, color = TextSecondary, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ConnectedPanel(
    deviceName: String,
    protocol: CastProtocol,
    strings: AppStrings.Strings,
    isPlaying: Boolean,
    hasMedia: Boolean,
    volume: Float,
    nowCasting: String?,
    onPlayPause: () -> Unit,
    onVolume: (Float) -> Unit,
    onDisconnect: () -> Unit
) {
    var vol by remember(volume) { mutableFloatStateOf(volume) }
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, AccentCyan.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CastConnected, null, tint = AccentCyan, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(String.format(strings.castConnectedTo, deviceName), color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        if (protocol == CastProtocol.GOOGLE_CAST) "Google Cast" else "DLNA / UPnP",
                        color = TextSecondary, fontSize = 11.sp
                    )
                }
                if (hasMedia) {
                    IconButton(onClick = onPlayPause) {
                        Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (nowCasting != null && hasMedia) String.format(strings.castNowCasting, nowCasting) else strings.castPickHint,
                color = TextSecondary, fontSize = 12.sp, lineHeight = 16.sp
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VolumeUp, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                Slider(
                    value = vol,
                    onValueChange = { vol = it },
                    onValueChangeFinished = { onVolume(vol) },
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
            }
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = onDisconnect,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.PhoneAndroid, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(strings.castReturnToPhone, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun BusyRow(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = AccentCyan)
            Spacer(Modifier.width(12.dp))
            Text(text, color = TextPrimary, fontSize = 13.sp)
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ErrorRed.copy(alpha = 0.12f)),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Warning, null, tint = ErrorRed, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(message, color = TextPrimary, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun HowToCard(strings: AppStrings.Strings) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(strings.castInstructionsTitle, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
            Spacer(Modifier.height(10.dp))
            InstructionStep("1", strings.castStep1)
            Spacer(Modifier.height(6.dp))
            InstructionStep("2", strings.castStep2)
            Spacer(Modifier.height(6.dp))
            InstructionStep("3", strings.castStep3)
        }
    }
}

@Composable
private fun CastOptionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    buttonText: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(40.dp).clip(CircleShape).background(PrimaryBlue.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = AccentCyan, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Spacer(Modifier.width(10.dp))
            Surface(shape = RoundedCornerShape(8.dp), color = PrimaryBlue, modifier = Modifier.height(34.dp)) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 12.dp)) {
                    Text(buttonText, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun InstructionStep(step: String, text: String) {
    Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth()) {
        Surface(shape = CircleShape, color = PrimaryBlue.copy(alpha = 0.2f), modifier = Modifier.size(20.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Text(step, color = AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(text, color = TextSecondary, fontSize = 12.sp, lineHeight = 16.sp)
    }
}

private fun openSystemCastSettings(context: Context) {
    val intents = listOf(
        Intent(Settings.ACTION_CAST_SETTINGS),
        Intent("android.settings.WIFI_DISPLAY_SETTINGS"),
        Intent(Settings.ACTION_WIRELESS_SETTINGS)
    )
    for (intent in intents) {
        try {
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            return
        } catch (_: Exception) {}
    }
    Toast.makeText(context, "System Cast Settings not supported on this device", Toast.LENGTH_SHORT).show()
}

/** Hands a credential-free link (never the raw IPTV URL) to an external player. */
private fun openExternalPlayer(context: Context, stream: StreamItem, strings: AppStrings.Strings) {
    val link = CastManager.externalLink(stream)
    if (link == null) {
        Toast.makeText(context, strings.castLinkUnavailable, Toast.LENGTH_LONG).show()
        return
    }
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(link), "video/*")
            putExtra("title", stream.name)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val chooser = Intent.createChooser(intent, strings.castExternalTitle)
        chooser.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(chooser)
    } catch (_: Exception) {
        Toast.makeText(context, "No external video player found", Toast.LENGTH_SHORT).show()
    }
}

private fun copyTemporaryLink(context: Context, stream: StreamItem, strings: AppStrings.Strings) {
    val link = CastManager.externalLink(stream)
    if (link == null) {
        Toast.makeText(context, strings.castLinkUnavailable, Toast.LENGTH_LONG).show()
        return
    }
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Stream link", link)
    // Ask Android 13+ not to show the copied text in the clipboard preview
    clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, strings.copiedToClipboard, Toast.LENGTH_SHORT).show()
}

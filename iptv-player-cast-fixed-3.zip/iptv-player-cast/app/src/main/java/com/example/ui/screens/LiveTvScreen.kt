package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.EpgProgramEntity
import com.example.data.model.CategorySummary
import com.example.data.model.StreamItem
import com.example.ui.components.CategoryGridCard
import com.example.ui.components.ChannelCard
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LiveTvScreen(
    channels: List<StreamItem>,
    categories: List<CategorySummary>,
    strings: AppStrings.Strings,
    onPlayChannel: (StreamItem) -> Unit,
    onToggleFavorite: (StreamItem) -> Unit,
    onOpenAddPlaylist: () -> Unit,
    epgMap: Map<String, List<EpgProgramEntity>> = emptyMap(),
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var categorySearchQuery by remember { mutableStateOf("") }
    var channelSearchQuery by remember { mutableStateOf("") }

    // Intercept back button to return to categories view if inside a category
    BackHandler(enabled = selectedCategory != null) {
        selectedCategory = null
        channelSearchQuery = ""
    }

    AnimatedContent(
        targetState = selectedCategory,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "CategoryTransition",
        modifier = modifier.fillMaxSize()
    ) { currentCat ->
        if (currentCat == null) {
            // VIEW 1: All Categories Grid (Harmonious Theme)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBg)
            ) {
                // Search in Categories
                OutlinedTextField(
                    value = categorySearchQuery,
                    onValueChange = { categorySearchQuery = it },
                    placeholder = { Text(strings.searchCategories, color = TextMuted, fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(20.dp))
                    },
                    trailingIcon = {
                        if (categorySearchQuery.isNotBlank()) {
                            IconButton(onClick = { categorySearchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = DarkSurfaceVariant,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )

                val filteredCategories = remember(categories, categorySearchQuery) {
                    if (categorySearchQuery.isBlank()) categories
                    else categories.filter { it.name.contains(categorySearchQuery, ignoreCase = true) }
                }

                if (categories.isEmpty() && channels.isEmpty()) {
                    // Empty State
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = DarkCard,
                                modifier = Modifier.size(80.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.Tv,
                                        contentDescription = null,
                                        tint = PrimaryBlue,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(18.dp))
                            Text(
                                text = strings.noPlaylists,
                                color = TextPrimary,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = strings.noPlaylistsDesc,
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Button(
                                onClick = onOpenAddPlaylist,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.size(8.dp))
                                Text(strings.addPlaylist, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    // 2-Column Grid of Category Cards
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // "All Channels" card
                        if (categorySearchQuery.isBlank()) {
                            item {
                                CategoryGridCard(
                                    name = strings.allCategories,
                                    count = channels.size,
                                    countLabel = strings.channelsCount,
                                    icon = Icons.Default.Tv,
                                    accentColor = AccentCyan,
                                    onClick = { selectedCategory = "ALL_CHANNELS" }
                                )
                            }
                        }

                        items(filteredCategories, key = { it.name }) { cat ->
                            CategoryGridCard(
                                name = cat.name,
                                count = cat.count,
                                countLabel = strings.channelsCount,
                                icon = Icons.Default.LiveTv,
                                accentColor = PrimaryBlue,
                                onClick = { selectedCategory = cat.name }
                            )
                        }
                    }
                }
            }
        } else {
            // VIEW 2: Inside Selected Category - Channels List
            val categoryChannels = remember(channels, currentCat, channelSearchQuery) {
                val list = if (currentCat == "ALL_CHANNELS") channels
                else channels.filter { it.category.equals(currentCat, ignoreCase = true) }

                if (channelSearchQuery.isBlank()) list
                else list.filter { it.name.contains(channelSearchQuery, ignoreCase = true) }
            }

            val categoryDisplayName = if (currentCat == "ALL_CHANNELS") strings.allCategories else currentCat

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBg)
            ) {
                // Header with Back Button and Category Title
                Surface(
                    color = DarkSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = {
                                selectedCategory = null
                                channelSearchQuery = ""
                            }) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back to categories",
                                    tint = TextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = categoryDisplayName,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${categoryChannels.size} ${strings.channelsCount}",
                                    color = AccentCyan,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        // Search channels within category
                        OutlinedTextField(
                            value = channelSearchQuery,
                            onValueChange = { channelSearchQuery = it },
                            placeholder = { Text(strings.searchHint, color = TextMuted, fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                            },
                            trailingIcon = {
                                if (channelSearchQuery.isNotBlank()) {
                                    IconButton(onClick = { channelSearchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryBlue,
                                unfocusedBorderColor = DarkSurfaceVariant,
                                focusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                                unfocusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                        )
                    }
                }

                if (categoryChannels.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.noChannelsFound,
                            color = TextMuted,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                } else {
                    val now = System.currentTimeMillis()
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(categoryChannels, key = { it.id }) { channel ->
                            val progs = epgMap[channel.epgChannelId ?: channel.streamId]
                                ?: epgMap[channel.streamId]
                                ?: epgMap[channel.name]
                            val currentProg = progs?.firstOrNull { now in it.startEpoch..it.endEpoch }
                                ?: progs?.firstOrNull { it.startEpoch > now }
                            val upcomingProg = if (currentProg != null) {
                                progs?.firstOrNull { it.startEpoch > currentProg.endEpoch }
                            } else null

                            ChannelCard(
                                stream = channel,
                                onPlay = { onPlayChannel(channel) },
                                onToggleFavorite = { onToggleFavorite(channel) },
                                currentProgram = currentProg?.title,
                                upcomingProgram = upcomingProg?.title
                            )
                        }
                    }
                }
            }
        }
    }
}

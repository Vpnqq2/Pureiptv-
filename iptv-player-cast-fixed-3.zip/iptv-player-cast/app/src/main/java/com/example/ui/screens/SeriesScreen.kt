package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategorySummary
import com.example.data.model.StreamItem
import com.example.ui.components.CategoryGridCard
import com.example.ui.components.MoviePosterCard
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SeriesScreen(
    seriesList: List<StreamItem>,
    categories: List<CategorySummary>,
    strings: AppStrings.Strings,
    onPlayEpisode: (StreamItem) -> Unit,
    onToggleFavorite: (StreamItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var selectedSeriesGroup by remember { mutableStateOf<String?>(null) }
    var categorySearchQuery by remember { mutableStateOf("") }
    var seriesSearchQuery by remember { mutableStateOf("") }

    BackHandler(enabled = selectedSeriesGroup != null || selectedCategory != null) {
        if (selectedSeriesGroup != null) {
            selectedSeriesGroup = null
        } else if (selectedCategory != null) {
            selectedCategory = null
            seriesSearchQuery = ""
        }
    }

    val groupedSeries = remember(seriesList) {
        seriesList.groupBy { it.seriesId ?: it.name }
    }

    AnimatedContent(
        targetState = Pair(selectedCategory, selectedSeriesGroup),
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "SeriesNavTransition",
        modifier = modifier.fillMaxSize()
    ) { (cat, seriesGroup) ->
        if (cat == null) {
            // VIEW 1: Categories Grid
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBg)
            ) {
                OutlinedTextField(
                    value = categorySearchQuery,
                    onValueChange = { categorySearchQuery = it },
                    placeholder = { Text(strings.searchCategories, color = TextMuted, fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(20.dp))
                    },
                    trailingIcon = {
                        if (categorySearchQuery.isNotBlank()) {
                            IconButton(onClick = { categorySearchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = DarkSurfaceVariant,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )

                val filteredCategories = remember(categories, categorySearchQuery) {
                    if (categorySearchQuery.isBlank()) categories
                    else categories.filter { it.name.contains(categorySearchQuery, ignoreCase = true) }
                }

                if (categories.isEmpty() && seriesList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.noChannelsFound,
                            color = TextMuted,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        if (categorySearchQuery.isBlank()) {
                            item {
                                CategoryGridCard(
                                    name = strings.allCategories,
                                    count = seriesList.size,
                                    countLabel = strings.seriesCount,
                                    icon = Icons.Default.Tv,
                                    accentColor = AccentEmerald,
                                    onClick = { selectedCategory = "ALL_SERIES" }
                                )
                            }
                        }

                        items(filteredCategories, key = { it.name }) { item ->
                            CategoryGridCard(
                                name = item.name,
                                count = item.count,
                                countLabel = strings.seriesCount,
                                icon = Icons.Default.LiveTv,
                                accentColor = AccentEmerald,
                                onClick = { selectedCategory = item.name }
                            )
                        }
                    }
                }
            }
        } else if (seriesGroup == null) {
            // VIEW 2: Series list inside selected category
            val seriesInCat = remember(groupedSeries, cat, seriesSearchQuery) {
                groupedSeries.values.mapNotNull { episodes ->
                    val first = episodes.firstOrNull() ?: return@mapNotNull null
                    val matchesCat = cat == "ALL_SERIES" || first.category.equals(cat, ignoreCase = true)
                    val seriesTitle = first.seriesId ?: first.name
                    val matchesQuery = seriesSearchQuery.isBlank() ||
                        seriesTitle.contains(seriesSearchQuery, ignoreCase = true) ||
                        first.name.contains(seriesSearchQuery, ignoreCase = true)
                    if (matchesCat && matchesQuery) first else null
                }
            }

            val categoryDisplayName = if (cat == "ALL_SERIES") strings.allCategories else cat

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBg)
            ) {
                Surface(
                    color = DarkSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = {
                                selectedCategory = null
                                seriesSearchQuery = ""
                            }) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = categoryDisplayName,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${seriesInCat.size} ${strings.seriesCount}",
                                    color = AccentCyan,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        OutlinedTextField(
                            value = seriesSearchQuery,
                            onValueChange = { seriesSearchQuery = it },
                            placeholder = { Text(strings.searchHint, color = TextMuted, fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                            },
                            trailingIcon = {
                                if (seriesSearchQuery.isNotBlank()) {
                                    IconButton(onClick = { seriesSearchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryBlue,
                                unfocusedBorderColor = DarkSurfaceVariant,
                                focusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                                unfocusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                        )
                    }
                }

                if (seriesInCat.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.noChannelsFound,
                            color = TextMuted,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 145.dp),
                        contentPadding = PaddingValues(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(seriesInCat, key = { it.id }) { item ->
                            val groupKey = item.seriesId ?: item.name
                            MoviePosterCard(
                                stream = item,
                                titleOverride = groupKey,
                                onPlay = { selectedSeriesGroup = groupKey },
                                onToggleFavorite = { onToggleFavorite(item) }
                            )
                        }
                    }
                }
            }
        } else {
            // VIEW 3: Episodes list for selected series
            val episodes = groupedSeries[seriesGroup] ?: emptyList()
            val sortedEpisodes = remember(episodes) {
                episodes.sortedWith(
                    compareBy<StreamItem> { it.seasonNumber ?: 1 }
                        .thenBy { it.episodeNumber ?: 1 }
                        .thenBy { it.name }
                )
            }
            val seasons = remember(sortedEpisodes) {
                sortedEpisodes.mapNotNull { it.seasonNumber }.distinct().sorted()
            }
            var selectedSeason by remember(seriesGroup) { mutableStateOf<Int?>(null) }
            val displayedEpisodes = remember(sortedEpisodes, selectedSeason) {
                if (selectedSeason == null) sortedEpisodes
                else sortedEpisodes.filter { it.seasonNumber == selectedSeason }
            }
            val seriesInfo = episodes.firstOrNull()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBg)
            ) {
                Surface(
                    color = DarkSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { selectedSeriesGroup = null }) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = seriesGroup,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${episodes.size} ${strings.episodes}",
                                style = MaterialTheme.typography.bodySmall,
                                color = AccentCyan
                            )
                        }
                    }
                }

                if (!seriesInfo?.plot.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkCard,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = seriesInfo!!.plot!!,
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                if (seasons.size > 1) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = if (selectedSeason == null) PrimaryBlue else DarkSurfaceVariant,
                                modifier = Modifier.clickable { selectedSeason = null }
                            ) {
                                Text(
                                    text = strings.allCategories,
                                    color = if (selectedSeason == null) Color.White else TextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                        }
                        items(seasons) { sNum ->
                            val isSelected = selectedSeason == sNum
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = if (isSelected) PrimaryBlue else DarkSurfaceVariant,
                                modifier = Modifier.clickable { selectedSeason = sNum }
                            ) {
                                Text(
                                    text = "${strings.season} $sNum",
                                    color = if (isSelected) Color.White else TextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(displayedEpisodes, key = { it.id }) { ep ->
                        Card(
                            onClick = { onPlayEpisode(ep) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = DarkSurfaceVariant,
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Default.PlayCircle,
                                            contentDescription = "Play",
                                            tint = PrimaryBlue,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = ep.name,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val epDetail = buildString {
                                        if (ep.seasonNumber != null) append("${strings.season} ${ep.seasonNumber} • ")
                                        if (ep.episodeNumber != null) append("${strings.episode} ${ep.episodeNumber}")
                                    }
                                    if (epDetail.isNotBlank()) {
                                        Text(
                                            text = epDetail,
                                            color = TextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

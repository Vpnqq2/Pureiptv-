package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.Coil
import com.example.data.model.PlaylistItem
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentGold
import com.example.ui.theme.AccentRed
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

// ---- Design tokens: every card/row on this screen uses the same values ----
private val ScreenPadding = 16.dp
private val CardShape = RoundedCornerShape(16.dp)
private val TileShape = RoundedCornerShape(12.dp)
private val TileSize = 40.dp
private val RowPaddingH = 16.dp
private val RowPaddingV = 14.dp
private val SectionGap = 24.dp

// Divider starts after the icon tile so it lines up with the row text
private val DividerInset = RowPaddingH + TileSize + 12.dp

@Composable
fun SettingsScreen(
    activePlaylist: PlaylistItem?,
    currentLanguage: AppLanguage,
    isHwAcceleration: Boolean,
    isAutoPlayNext: Boolean,
    strings: AppStrings.Strings,
    onSelectLanguage: (AppLanguage) -> Unit,
    onToggleHwAcceleration: (Boolean) -> Unit,
    onToggleAutoPlayNext: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    onNavigateToPlaylists: () -> Unit,
    onShowWelcome: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    var selectedBufferMode by remember { mutableIntStateOf(1) } // 0: 1s, 1: 4s, 2: 8s

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .verticalScroll(scrollState)
            .padding(horizontal = ScreenPadding)
            .padding(top = 12.dp, bottom = 32.dp)
    ) {
        Text(
            text = strings.navSettings,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(start = 4.dp, bottom = 20.dp)
        )

        // ---- Language ----
        SettingsSection(title = strings.language) {
            val languages = listOf(
                Triple(AppLanguage.ENGLISH, "English" to "US / UK", "EN"),
                Triple(AppLanguage.SPANISH, "Español" to "ES / Latam", "ES"),
                Triple(AppLanguage.ARABIC, "العربية" to "عربي", "AR")
            )
            languages.forEachIndexed { index, (language, names, badge) ->
                val isSelected = currentLanguage == language
                if (index > 0) RowDivider()
                SettingsRow(
                    leading = { BadgeTile(text = badge, selected = isSelected) },
                    title = names.first,
                    subtitle = names.second,
                    onClick = { onSelectLanguage(language) },
                    trailing = {
                        RadioButton(
                            selected = isSelected,
                            onClick = null,
                            colors = RadioButtonDefaults.colors(
                                selectedColor = PrimaryBlue,
                                unselectedColor = TextMuted
                            )
                        )
                    }
                )
            }
        }

        Spacer(Modifier.height(SectionGap))

        // ---- Playlists ----
        SettingsSection(title = strings.navPlaylists) {
            SettingsRow(
                leading = { IconTile(Icons.Default.PlaylistPlay, PrimaryBlue) },
                title = strings.activePlaylist,
                subtitle = activePlaylist?.name ?: strings.noPlaylists,
                subtitleColor = if (activePlaylist != null) AccentEmerald else TextMuted,
                onClick = onNavigateToPlaylists,
                trailing = { Chevron() }
            )
        }

        Spacer(Modifier.height(SectionGap))

        // ---- Playback ----
        SettingsSection(title = strings.playerSettings) {
            SettingsRow(
                leading = { IconTile(Icons.Default.Memory, AccentGold) },
                title = strings.decoderMode,
                subtitle = strings.decoderDesc,
                trailing = {
                    SettingsSwitch(checked = isHwAcceleration, onCheckedChange = onToggleHwAcceleration)
                }
            )
            RowDivider()
            SettingsRow(
                leading = { IconTile(Icons.Default.Timer, AccentCyan) },
                title = strings.bufferSize,
                subtitle = strings.bufferDesc
            )
            SegmentedChoice(
                options = listOf("1s", "4s", "8s"),
                selectedIndex = selectedBufferMode,
                onSelect = { selectedBufferMode = it },
                modifier = Modifier.padding(start = RowPaddingH, end = RowPaddingH, bottom = RowPaddingV)
            )
            RowDivider()
            SettingsRow(
                leading = { IconTile(Icons.Default.SkipNext, AccentEmerald) },
                title = strings.autoPlayNext,
                subtitle = strings.autoPlayDesc,
                trailing = {
                    SettingsSwitch(checked = isAutoPlayNext, onCheckedChange = onToggleAutoPlayNext)
                }
            )
        }

        Spacer(Modifier.height(SectionGap))

        // ---- Storage ----
        SettingsSection(title = strings.storageCache) {
            SettingsRow(
                leading = { IconTile(Icons.Default.CleaningServices, AccentCyan) },
                title = strings.clearLogoCache,
                subtitle = strings.clearLogoCacheDesc,
                onClick = {
                    Coil.imageLoader(context).memoryCache?.clear()
                    Toast.makeText(context, strings.cacheClearedNotice, Toast.LENGTH_SHORT).show()
                }
            )
            RowDivider()
            SettingsRow(
                leading = { IconTile(Icons.Default.History, AccentRed) },
                title = strings.clearHistory,
                subtitle = strings.clearHistoryDesc,
                onClick = {
                    onClearHistory()
                    Toast.makeText(context, strings.historyClearedNotice, Toast.LENGTH_SHORT).show()
                }
            )
        }

        Spacer(Modifier.height(SectionGap))

        // ---- About ----
        SettingsSection(title = strings.aboutApp) {
            InfoRow(strings.appEditionLabel, strings.appVersion)
            RowDivider(inset = RowPaddingH)
            InfoRow(strings.mediaEngineLabel, strings.engineVersion)
            RowDivider(inset = RowPaddingH)
            InfoRow(strings.connectivityLabel, strings.networkStatus)
            RowDivider(inset = RowPaddingH)
            InfoRow(strings.protocolsLabel, "HLS (.m3u8), TS, MP4, MKV")
            RowDivider(inset = RowPaddingH)
            InfoRow(strings.decodersLabel, "H.264 (AVC), H.265 (HEVC), AAC, AC3")
            RowDivider(inset = RowPaddingH)
            SettingsRow(
                leading = { IconTile(Icons.Default.PlayArrow, PrimaryBlue) },
                title = strings.revisitWelcome,
                onClick = onShowWelcome,
                trailing = { Chevron() }
            )
        }
    }
}

// ================= Building blocks =================

/** Small section label above a card, then one card holding all rows of the group. */
@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        text = title,
        color = TextSecondary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
    )
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        border = BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(content = content)
    }
}

/** One standard row: [tile] title / subtitle ........ [trailing]. Whole row is tappable when onClick is set. */
@Composable
private fun SettingsRow(
    leading: @Composable () -> Unit,
    title: String,
    subtitle: String? = null,
    subtitleColor: Color = TextSecondary,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 64.dp)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = RowPaddingH, vertical = RowPaddingV)
    ) {
        leading()
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    color = subtitleColor,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

@Composable
private fun IconTile(icon: ImageVector, tint: Color) {
    Surface(
        shape = TileShape,
        color = tint.copy(alpha = 0.15f),
        modifier = Modifier.size(TileSize)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun BadgeTile(text: String, selected: Boolean) {
    Surface(
        shape = TileShape,
        color = if (selected) PrimaryBlue.copy(alpha = 0.2f) else DarkSurfaceVariant,
        modifier = Modifier.size(TileSize)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = text,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (selected) PrimaryBlue else TextSecondary
            )
        }
    }
}

@Composable
private fun SettingsSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = PrimaryBlue,
            uncheckedThumbColor = TextSecondary,
            uncheckedTrackColor = DarkSurfaceVariant,
            uncheckedBorderColor = DarkCardBorder
        )
    )
}

@Composable
private fun Chevron() {
    Icon(
        Icons.AutoMirrored.Filled.KeyboardArrowRight,
        contentDescription = null,
        tint = TextMuted,
        modifier = Modifier.size(22.dp)
    )
}

@Composable
private fun RowDivider(inset: androidx.compose.ui.unit.Dp = DividerInset) {
    HorizontalDivider(
        color = DarkCardBorder,
        modifier = Modifier.padding(start = inset)
    )
}

@Composable
private fun SegmentedChoice(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DarkSurfaceVariant,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(3.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            options.forEachIndexed { index, label ->
                val isSelected = index == selectedIndex
                Surface(
                    onClick = { onSelect(index) },
                    shape = RoundedCornerShape(9.dp),
                    color = if (isSelected) PrimaryBlue else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

/** Read-only label/value row, stacked so long values wrap cleanly on a phone. */
@Composable
private fun InfoRow(label: String, value: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = RowPaddingH, vertical = 12.dp)
    ) {
        Text(text = label, color = TextSecondary, fontSize = 12.sp)
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

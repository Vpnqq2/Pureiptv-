package com.example.util

object CategorySanitizer {

    /**
     * Cleans category names to be concise and free of separators:
     * - Removes punctuation/separators like |, :, -, _, /, \, ,, ;, &, +, (), [], {}
     * - Strips common redundant prefixes (e.g. VIP, FHD, 4K, HD, AR, EN, FR, US, UK)
     * - Trims to at most 1-2 words so it stays concise and clean
     */
    fun clean(raw: String?): String {
        if (raw.isNullOrBlank()) return "General"

        var text = raw.trim()

        // 1. Remove bracketed content like [HD], (4K), {VIP}
        text = text.replace(Regex("""\([^)]*\)"""), " ")
        text = text.replace(Regex("""\[[^\]]*\]"""), " ")
        text = text.replace(Regex("""\{[^}]*\}"""), " ")

        // 2. Replace separators and punctuation with space: | : - _ / \ , ; & + • ~ * #
        text = text.replace(Regex("""[|:\-_/\\,;&+•~*#!?^=]"""), " ")

        // 3. Remove common noisy single prefixes or tokens (like VIP, FHD, 4K, HEVC)
        val tokens = text.split(Regex("""\s+""")).filter { it.isNotBlank() }
        val filteredTokens = tokens.filterNot { token ->
            val upper = token.uppercase()
            upper in listOf("VIP", "4K", "FHD", "HD", "SD", "HEVC", "UHD", "RAW", "H265")
        }

        val candidate = if (filteredTokens.isNotEmpty()) filteredTokens else tokens

        // Take at most first 2 concise words
        val conciseWords = candidate.take(2).joinToString(" ") { word ->
            // Capitalize nicely
            word.lowercase().replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }

        return conciseWords.ifBlank { "General" }
    }
}

package com.example.cast

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DlnaProtocolTest {

    private val description = """<?xml version="1.0"?>
<root xmlns="urn:schemas-upnp-org:device-1-0">
 <device>
  <friendlyName>Living Room TV</friendlyName>
  <UDN>uuid:1234</UDN>
  <serviceList>
   <service><serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType><controlURL>/AVT/control</controlURL></service>
   <service><serviceType>urn:schemas-upnp-org:service:RenderingControl:1</serviceType><controlURL>/RC/control</controlURL></service>
  </serviceList>
 </device>
</root>"""

    @Test fun parsesRenderer() {
        val r = DlnaProtocol.parseDescription(description, "http://192.168.1.50:9197/dmr")
        assertNotNull(r)
        assertEquals("Living Room TV", r!!.name)
        assertEquals("http://192.168.1.50:9197/AVT/control", r.avTransportControlUrl)
        assertEquals("http://192.168.1.50:9197/RC/control", r.renderingControlUrl)
    }

    @Test fun deviceWithoutAvTransportIsIgnored() {
        val xml = "<root><device><friendlyName>Router</friendlyName></device></root>"
        assertNull(DlnaProtocol.parseDescription(xml, "http://192.168.1.1/d.xml"))
    }

    @Test fun rejectsDoctype() {
        val xml = "<!DOCTYPE x [<!ENTITY a SYSTEM \"file:///etc/passwd\">]><root><device><friendlyName>&a;</friendlyName></device></root>"
        assertNull(DlnaProtocol.parseDescription(xml, "http://192.168.1.1/d.xml"))
    }

    @Test fun ssdpLocation() {
        val p = "HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\nLocation: http://192.168.1.50:9197/dmr\r\nST: x\r\n\r\n"
        assertEquals("http://192.168.1.50:9197/dmr", DlnaProtocol.parseSsdpLocation(p))
        assertNull(DlnaProtocol.parseSsdpLocation("HTTP/1.1 404 Not Found\r\n\r\n"))
    }

    @Test fun didlEscapesTitleAndUrl() {
        val d = DlnaProtocol.didl("A & B <x>", "http://h/a?x=1&y=2", "video/mp4", false)
        assertTrue(d.contains("A &amp; B &lt;x&gt;"))
        assertTrue(d.contains("http://h/a?x=1&amp;y=2"))
    }

    @Test fun soapBodiesAreEscaped() {
        val b = DlnaProtocol.setUriBody("http://h/a?x=1&y=2", "<DIDL-Lite/>")
        assertTrue(b.contains("&lt;DIDL-Lite/&gt;"))
        assertTrue(b.contains("<u:SetAVTransportURI"))
    }

    @Test fun timeFormatting() {
        assertEquals("01:02:03", DlnaProtocol.formatTime(3_723_000))
        assertEquals(3_723_000L, DlnaProtocol.parseTime("01:02:03.500"))
        assertEquals(0L, DlnaProtocol.parseTime("NOT_IMPLEMENTED"))
    }

    @Test fun tagExtraction() {
        assertEquals("PLAYING", DlnaProtocol.tag("<u:R><CurrentTransportState>PLAYING</CurrentTransportState></u:R>", "CurrentTransportState"))
    }
}

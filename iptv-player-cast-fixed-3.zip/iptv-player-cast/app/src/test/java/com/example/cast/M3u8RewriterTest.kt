package com.example.cast

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class M3u8RewriterTest {

    @Test fun rewritesRelativeAbsoluteAndKeyUris() {
        val seen = mutableListOf<String>()
        val body = "#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"key.bin\"\n#EXTINF:6.0,\nseg1.ts\n#EXTINF:6.0,\nhttp://other/seg2.ts\n"
        val out = M3u8Rewriter.rewrite(body, "http://h/live/u/p/1.m3u8") { u -> seen += u; "R${seen.size}" }
        assertEquals(listOf("http://h/live/u/p/key.bin", "http://h/live/u/p/seg1.ts", "http://other/seg2.ts"), seen)
        assertTrue(out.contains("URI=\"R1\""))
        assertTrue(out.lines().contains("R2"))
        assertTrue(out.lines().contains("R3"))
        assertFalse(out.contains("http://"))
    }

    @Test fun keepsTagsAndBlankLines() {
        val out = M3u8Rewriter.rewrite("#EXTM3U\n#EXT-X-VERSION:3\n\n#EXT-X-ENDLIST\n", "http://h/a.m3u8") { "X" }
        assertEquals("#EXTM3U\n#EXT-X-VERSION:3\n\n#EXT-X-ENDLIST\n", out)
    }

    @Test fun detectsPlaylist() {
        assertTrue(M3u8Rewriter.looksLikePlaylist("  #EXTM3U\n"))
        assertFalse(M3u8Rewriter.looksLikePlaylist("<html>"))
    }
}

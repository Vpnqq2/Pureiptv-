package com.example.player

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.cast.CastManager
import com.example.cast.CastSessionState
import com.example.ui.components.castErrorText
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.local.EpgProgramEntity
import com.example.data.model.ChannelType
import com.example.data.model.StreamItem
import com.example.ui.components.CastBottomSheet
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCard
import com.example.ui.theme.FavoriteGold
import com.example.ui.theme.LiveRed
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerComposable(
    stream: StreamItem,
    allStreamsInCat: List<StreamItem> = emptyList(),
    epgPrograms: List<EpgProgramEntity> = emptyList(),
    onClosePlayer: () -> Unit,
    onSelectStream: (StreamItem) -> Unit,
    onToggleFavorite: (StreamItem) -> Unit,
    onProgressUpdate: (Long, Long) -> Unit,
    language: AppLanguage = AppLanguage.ENGLISH,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val strings = AppStrings.get(language)

    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var isControlsVisible by remember { mutableStateOf(true) }
    var isFullscreen by remember { mutableStateOf(false) }
    var aspectMode by remember { mutableStateOf(AspectRatioMode.FIT) }
    var isChannelDrawerOpen by remember { mutableStateOf(false) }
    var isCastSheetOpen by remember { mutableStateOf(false) }

    // --- TV casting state (Google Cast / DLNA). While casting, the phone is only a remote control. ---
    remember { CastManager.init(context) }
    val castState by CastManager.state.collectAsStateWithLifecycle()
    val remote by CastManager.status.collectAsStateWithLifecycle()
    val castError by CastManager.lastError.collectAsStateWithLifecycle()
    val casting = castState is CastSessionState.Connected
    var wasCasting by remember { mutableStateOf(false) }
    var lastCastPositionMs by remember { mutableLongStateOf(0L) }

    // Auto-retry state when stream stops or encounters errors
    var retryAttempt by remember { mutableIntStateOf(0) }
    var isAutoRetrying by remember { mutableStateOf(false) }
    var retryCountdownSec by remember { mutableIntStateOf(0) }
    var retryReason by remember { mutableStateOf<String?>(null) }
    var retryJob by remember { mutableStateOf<Job?>(null) }
    val maxRetryAttempts = 20

    val isLive = stream.type == ChannelType.LIVE

    // ExoPlayer creation
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = true
        }
    }

    // Auto-Retry Trigger function
    fun triggerAutoRetry(immediate: Boolean = false, reason: String? = null) {
        if (CastManager.isCasting) return // local player is stopped on purpose while casting
        if (retryAttempt >= maxRetryAttempts) {
            isAutoRetrying = false
            errorMessage = strings.streamMaxRetries
            return
        }

        retryJob?.cancel()
        retryJob = scope.launch {
            isAutoRetrying = true
            errorMessage = null
            retryAttempt++
            retryReason = reason ?: strings.streamInterrupted

            val waitSec = if (immediate) 1 else minOf(2 + (retryAttempt / 3), 5)
            for (sec in waitSec downTo 1) {
                retryCountdownSec = sec
                delay(1000)
            }
            retryCountdownSec = 0
            isBuffering = true
            errorMessage = null

            try {
                exoPlayer.stop()
                val mediaItem = MediaItem.fromUri(Uri.parse(stream.streamUrl))
                exoPlayer.setMediaItem(mediaItem)
                if (stream.watchProgressMs > 0 && !isLive) {
                    val pos = if (currentPositionMs > 0) currentPositionMs else stream.watchProgressMs
                    exoPlayer.seekTo(pos)
                }
                exoPlayer.prepare()
                exoPlayer.play()
            } catch (e: Exception) {
                isBuffering = false
                triggerAutoRetry(immediate = false, reason = e.localizedMessage ?: "Connection error")
            }
        }
    }

    // Load Stream (locally, or on the TV when a cast session is connected)
    LaunchedEffect(stream.streamUrl, casting) {
        val returningFromCast = wasCasting && !casting
        wasCasting = casting
        isBuffering = true
        errorMessage = null
        retryAttempt = 0
        isAutoRetrying = false
        retryJob?.cancel()
        if (casting) {
            // Hand the stream to the TV. Stop (not pause) the local player so it releases the
            // provider connection (many IPTV accounts allow one) and stays silent.
            val startMs = if (!isLive) maxOf(currentPositionMs, stream.watchProgressMs) else 0L
            exoPlayer.stop()
            isBuffering = false
            CastManager.castStream(stream, startMs)
            return@LaunchedEffect
        }
        try {
            val mediaItem = MediaItem.fromUri(Uri.parse(stream.streamUrl))
            exoPlayer.setMediaItem(mediaItem)
            val resumeMs = if (returningFromCast && !isLive) lastCastPositionMs else stream.watchProgressMs
            if (resumeMs > 0 && !isLive) {
                exoPlayer.seekTo(resumeMs)
            }
            exoPlayer.prepare()
            exoPlayer.play()
        } catch (e: Exception) {
            errorMessage = e.localizedMessage ?: "Failed to open stream"
            isBuffering = false
            triggerAutoRetry(immediate = false, reason = "Failed to open stream")
        }
    }

    // While casting: mirror the TV's position/duration into the same UI state the local player uses
    LaunchedEffect(casting) {
        while (casting) {
            currentPositionMs = CastManager.positionMs()
            lastCastPositionMs = currentPositionMs
            durationMs = CastManager.status.value.durationMs
            delay(1000)
        }
    }

    // Player events listener
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        isBuffering = true
                    }
                    Player.STATE_READY -> {
                        isBuffering = false
                        errorMessage = null
                        isAutoRetrying = false
                        retryAttempt = 0
                        retryCountdownSec = 0
                        retryReason = null
                        retryJob?.cancel()
                        durationMs = exoPlayer.duration.coerceAtLeast(0L)
                    }
                    Player.STATE_ENDED -> {
                        isBuffering = false
                        if (isLive) {
                            // Live stream unexpectedly ended (server cut off segments) -> auto-reconnect!
                            triggerAutoRetry(immediate = false, reason = strings.streamInterrupted)
                        }
                    }
                    Player.STATE_IDLE -> {}
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                if (playing) {
                    errorMessage = null
                    isAutoRetrying = false
                    retryAttempt = 0
                    retryCountdownSec = 0
                    retryReason = null
                    retryJob?.cancel()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                val code = error.errorCodeName
                // Automatically retry when stream stops due to network or server error
                triggerAutoRetry(immediate = false, reason = "${strings.streamInterrupted} ($code)")
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            val lastPos = exoPlayer.currentPosition
            val dur = exoPlayer.duration
            onProgressUpdate(lastPos, dur)
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            CastManager.stopPlayback()
            CastManager.releaseExternalLinks()
            retryJob?.cancel()

            // Restore portrait orientation on exit if in fullscreen
            val activity = context as? Activity
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    // Watchdog for live streams: If buffering freezes/stalls for > 10s, auto-reconnect!
    LaunchedEffect(isBuffering, isAutoRetrying, isLive) {
        if (isBuffering && !isAutoRetrying && isLive && !casting) {
            delay(10_000)
            if (isBuffering && !isAutoRetrying) {
                triggerAutoRetry(immediate = true, reason = strings.streamInterrupted)
            }
        }
    }

    // Track position timer
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            currentPositionMs = exoPlayer.currentPosition
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            delay(1000)
        }
    }

    // Auto-hide controls timer
    LaunchedEffect(isControlsVisible) {
        if (isControlsVisible) {
            delay(4000)
            if (isPlaying && !isChannelDrawerOpen) {
                isControlsVisible = false
            }
        }
    }

    // Safe Player Exit
    fun closePlayerSafely() {
        retryJob?.cancel()
        isAutoRetrying = false
        isCastSheetOpen = false
        if (isFullscreen) {
            val activity = context as? Activity
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            isFullscreen = false
        }
        try {
            onProgressUpdate(exoPlayer.currentPosition, exoPlayer.duration.coerceAtLeast(0L))
            exoPlayer.stop()
        } catch (_: Exception) {}
        onClosePlayer()
    }

    // Intercept Back button inside Player (Highest Priority)
    BackHandler(enabled = true) {
        if (isCastSheetOpen) {
            isCastSheetOpen = false
        } else if (isChannelDrawerOpen) {
            isChannelDrawerOpen = false
        } else if (isFullscreen) {
            val activity = context as? Activity
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            isFullscreen = false
        } else {
            closePlayerSafely()
        }
    }

    // Handle Fullscreen orientation
    fun toggleFullscreen() {
        val activity = context as? Activity ?: return
        val newFs = !isFullscreen
        isFullscreen = newFs
        if (newFs) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                isControlsVisible = !isControlsVisible
            }
    ) {
        // 1. Media3 PlayerView
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    isFocusable = false
                    isFocusableInTouchMode = false
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                playerView.resizeMode = when (aspectMode) {
                    AspectRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    AspectRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    AspectRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    AspectRatioMode.RATIO_16_9 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                    AspectRatioMode.RATIO_4_3 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // 2. Loading Spinner (Buffering or Auto-Reconnecting)
        if ((isBuffering || isAutoRetrying) && errorMessage == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = AccentCyan,
                    strokeWidth = 3.5.dp,
                    modifier = Modifier.size(52.dp)
                )
            }
        }

        // 3. Error Overlay (Shown ONLY when not auto-retrying and all retries failed)
        if (!isAutoRetrying && errorMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = LiveRed,
                        modifier = Modifier.size(44.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = strings.streamStopped,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = errorMessage ?: strings.streamMaxRetries,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Reconnect button
                        Surface(
                            onClick = {
                                retryAttempt = 0
                                triggerAutoRetry(immediate = true, reason = strings.streamManualAttempt)
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = PrimaryBlue,
                            modifier = Modifier.height(42.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 18.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Retry", tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.reconnectNow, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        // Exit player safely
                        Surface(
                            onClick = { closePlayerSafely() },
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                            modifier = Modifier.height(42.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            ) {
                                Text(strings.backToChannels, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        // 4. Overlays & Controls
        AnimatedVisibility(
            visible = isControlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.8f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            ) {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { closePlayerSafely() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Column(modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isLive) {
                                Surface(
                                    color = LiveRed,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "LIVE",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text(
                                text = stream.name,
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        val now = System.currentTimeMillis()
                        val currentProg = if (isLive && epgPrograms.isNotEmpty()) {
                            epgPrograms.firstOrNull { now in it.startEpoch..it.endEpoch }
                                ?: epgPrograms.firstOrNull { it.startEpoch > now }
                        } else null
                        val upcomingProg = if (isLive && epgPrograms.isNotEmpty() && currentProg != null) {
                            epgPrograms.firstOrNull { it.startEpoch > currentProg.endEpoch }
                        } else null

                        if (currentProg != null) {
                            Text(
                                text = "${strings.nowPlaying}: ${currentProg.title}" +
                                        (upcomingProg?.let { " | ${strings.upcoming}: ${it.title}" } ?: ""),
                                color = AccentCyan,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        } else {
                            Text(
                                text = stream.category,
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    // Aspect ratio cycle button
                    IconButton(
                        onClick = {
                            aspectMode = when (aspectMode) {
                                AspectRatioMode.FIT -> AspectRatioMode.ZOOM
                                AspectRatioMode.ZOOM -> AspectRatioMode.FILL
                                AspectRatioMode.FILL -> AspectRatioMode.RATIO_16_9
                                AspectRatioMode.RATIO_16_9 -> AspectRatioMode.RATIO_4_3
                                AspectRatioMode.RATIO_4_3 -> AspectRatioMode.FIT
                            }
                        }
                    ) {
                        Icon(
                            Icons.Default.AspectRatio,
                            contentDescription = "Aspect Ratio",
                            tint = Color.White
                        )
                    }

                    // Favorite toggle
                    IconButton(onClick = { onToggleFavorite(stream) }) {
                        Icon(
                            imageVector = if (stream.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (stream.isFavorite) FavoriteGold else Color.White
                        )
                    }

                    // Cast to TV button
                    IconButton(onClick = { isCastSheetOpen = true }) {
                        Icon(
                            imageVector = Icons.Default.Cast,
                            contentDescription = "Cast to TV",
                            tint = if (isCastSheetOpen) AccentCyan else Color.White
                        )
                    }

                    // Quick channel drawer toggle
                    if (allStreamsInCat.isNotEmpty()) {
                        IconButton(onClick = { isChannelDrawerOpen = !isChannelDrawerOpen }) {
                            Icon(
                                Icons.Default.Tv,
                                contentDescription = "Channels",
                                tint = if (isChannelDrawerOpen) AccentCyan else Color.White
                            )
                        }
                    }
                }

                // Center Play/Pause & Quick Seek Buttons
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isLive) {
                        IconButton(
                            onClick = {
                                if (casting) CastManager.seek((CastManager.positionMs() - 10000).coerceAtLeast(0))
                                else exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0))
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(
                                Icons.Default.Replay10,
                                contentDescription = "Rewind 10s",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    Surface(
                        onClick = {
                            if (casting) {
                                if (remote.isPlaying) CastManager.pause() else CastManager.play()
                            } else if (exoPlayer.isPlaying) {
                                exoPlayer.pause()
                            } else {
                                exoPlayer.play()
                            }
                        },
                        shape = CircleShape,
                        color = PrimaryBlue,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (if (casting) remote.isPlaying else isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (if (casting) remote.isPlaying else isPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    if (!isLive) {
                        IconButton(
                            onClick = {
                                if (casting) CastManager.seek((CastManager.positionMs() + 10000).coerceAtMost(durationMs))
                                else exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(durationMs))
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(
                                Icons.Default.Forward10,
                                contentDescription = "Forward 10s",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }

                // Bottom Bar Controls
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    if (!isLive && durationMs > 0) {
                        Slider(
                            value = (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f),
                            onValueChange = { fraction ->
                                val seekTo = (fraction * durationMs).toLong()
                                currentPositionMs = seekTo
                                if (!casting) exoPlayer.seekTo(seekTo)
                            },
                            onValueChangeFinished = {
                                if (casting) CastManager.seek(currentPositionMs)
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = PrimaryBlue,
                                activeTrackColor = PrimaryBlue,
                                inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!isLive && durationMs > 0) {
                            Text(
                                text = "${formatDuration(currentPositionMs)} / ${formatDuration(durationMs)}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(LiveRed, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Live Stream (HLS/TS)",
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        IconButton(onClick = { toggleFullscreen() }) {
                            Icon(
                                imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                contentDescription = "Fullscreen",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }

        // Quick Channel Changer Drawer (Side Overlay)
        AnimatedVisibility(
            visible = isChannelDrawerOpen,
            enter = slideInHorizontally(initialOffsetX = { it }),
            exit = slideOutHorizontally(targetOffsetX = { it }),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(280.dp)
        ) {
            Surface(
                color = DarkBg.copy(alpha = 0.95f),
                modifier = Modifier.fillMaxSize()
            ) {
                Column(
                    modifier = Modifier
                        .systemBarsPadding()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Quick Channels (${allStreamsInCat.size})",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(allStreamsInCat) { item ->
                            val isSelected = item.id == stream.id
                            Surface(
                                onClick = {
                                    onSelectStream(item)
                                    isChannelDrawerOpen = false
                                },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) PrimaryBlue.copy(alpha = 0.25f) else DarkCard,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.name,
                                        color = if (isSelected) AccentCyan else TextPrimary,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // "Playing on TV" overlay: the local video surface is stopped while casting
        if (casting) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.92f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(Icons.Default.Cast, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = String.format(
                            strings.castNowCasting,
                            (castState as? CastSessionState.Connected)?.deviceName ?: ""
                        ),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    val shownError = castError ?: remote.error
                    if (shownError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = castErrorText(strings, shownError),
                            color = LiveRed,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    } else if (remote.isBuffering) {
                        Spacer(modifier = Modifier.height(10.dp))
                        CircularProgressIndicator(color = AccentCyan, strokeWidth = 2.5.dp, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }

        // Cast to TV Sheet
        if (isCastSheetOpen) {
            CastBottomSheet(
                onDismissRequest = { isCastSheetOpen = false },
                activeStream = stream,
                language = language
            )
        }
    }
}

private fun formatDuration(millis: Long): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

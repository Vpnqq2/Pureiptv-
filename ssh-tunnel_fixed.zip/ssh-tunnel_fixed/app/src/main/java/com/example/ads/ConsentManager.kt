package com.example.ads

import android.app.Activity
import com.example.core.logs.LogManager
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Google UMP consent (GDPR / EEA, UK, etc.). Ads are only initialised once consent allows it.
 * The form itself is configured in AdMob > Privacy & messaging.
 */
object ConsentManager {

    fun gather(activity: Activity, onCanRequestAds: () -> Unit) {
        val info = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder().build()

        info.requestConsentInfoUpdate(
            activity, params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { error ->
                    if (error != null) LogManager.w("Consent form: ${error.message}")
                    if (info.canRequestAds()) onCanRequestAds()
                }
            },
            { error ->
                LogManager.w("Consent info update failed: ${error.message}")
                if (info.canRequestAds()) onCanRequestAds()
            }
        )
        // Consent from a previous session may already allow ads: start right away.
        if (info.canRequestAds()) onCanRequestAds()
    }

    fun privacyOptionsRequired(activity: Activity): Boolean =
        UserMessagingPlatform.getConsentInformation(activity).privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { error ->
            if (error != null) LogManager.w("Privacy options: ${error.message}")
        }
    }
}

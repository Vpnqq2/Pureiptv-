package com.example.core.logs

import com.example.data.model.LogEntry
import com.example.data.model.LogLevel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.CopyOnWriteArrayList

object LogManager {

    private const val MAX_LOGS = 300
    private val buffer = CopyOnWriteArrayList<LogEntry>()
    private val _logsFlow = MutableStateFlow<List<LogEntry>>(emptyList())
    val logsFlow: StateFlow<List<LogEntry>> = _logsFlow.asStateFlow()

    @Volatile private var redacting = false
    @Volatile private var secrets: List<String> = emptyList()
    private val ipv4 = Regex("""\b(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\b""")

    /** True while a locked config is in use: logs and states must not reveal its details. */
    val isRedacting: Boolean get() = redacting

    /** Enables/disables redaction. While enabled, [secrets] and public IPv4 addresses are masked. */
    fun setRedaction(enabled: Boolean, secrets: Collection<String> = emptyList()) {
        this.secrets = secrets.map { it.trim() }.filter { it.length >= 3 }.distinct().sortedByDescending { it.length }
        this.redacting = enabled
    }

    fun redact(text: String): String {
        if (!redacting) return text
        var out = text
        for (secret in secrets) out = out.replace(secret, "***", ignoreCase = true)
        return ipv4.replace(out) { m ->
            val a = m.groupValues[1]
            val b = m.groupValues[2]
            if (a == "127" || a == "10" || (a == "198" && b == "18") || (a == "100" && (b.toIntOrNull() ?: -1) in 64..127)) m.value else "***"
        }
    }

    fun log(message: String, level: LogLevel = LogLevel.INFO) {
        val entry = LogEntry(
            message = redact(message),
            level = level
        )
        buffer.add(entry)
        while (buffer.size > MAX_LOGS) {
            buffer.removeAt(0)
        }
        _logsFlow.value = buffer.toList()
    }

    fun i(message: String) = log(message, LogLevel.INFO)
    fun s(message: String) = log(message, LogLevel.SUCCESS)
    fun w(message: String) = log(message, LogLevel.WARN)
    fun e(message: String) = log(message, LogLevel.ERROR)

    fun clear() {
        buffer.clear()
        _logsFlow.value = emptyList()
    }
}

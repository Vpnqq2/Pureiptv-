package com.example.core.payload

object PayloadEngine {

    private const val VAR_HOST = "[host]"
    private const val VAR_PORT = "[port]"
    private const val VAR_HOST_PORT = "[host_port]"
    private const val VAR_CRLF = "[crlf]"
    private const val VAR_LF = "[lf]"
    private const val VAR_CR = "[cr]"
    private const val VAR_PROTOCOL = "[protocol]"
    private const val VAR_UA = "[ua]"
    private const val VAR_SPLIT = "[split]"

    const val DEFAULT_PAYLOAD = "CONNECT [host]:[port] HTTP/1.1[crlf]Host: [host][crlf]Connection: keep-alive[crlf][crlf]"

    /**
     * Resolves payload template variables with concrete SSH target host and port.
     */
    fun resolve(
        rawTemplate: String,
        sshHost: String,
        sshPort: Int,
        protocol: String = "HTTP/1.1"
    ): String {
        if (rawTemplate.isBlank()) {
            return "CONNECT $sshHost:$sshPort HTTP/1.1\r\nHost: $sshHost\r\nConnection: keep-alive\r\n\r\n"
        }

        var result = rawTemplate
            .replace(VAR_HOST_PORT, "$sshHost:$sshPort", ignoreCase = true)
            .replace(VAR_HOST, sshHost, ignoreCase = true)
            .replace(VAR_PORT, sshPort.toString(), ignoreCase = true)
            .replace(VAR_PROTOCOL, protocol, ignoreCase = true)
            .replace(VAR_UA, "Mozilla/5.0 (Android; Mobile; rv:109.0) Gecko/109.0 Firefox/119.0", ignoreCase = true)
            .replace(VAR_CRLF, "\r\n", ignoreCase = true)
            .replace(VAR_LF, "\n", ignoreCase = true)
            .replace(VAR_CR, "\r", ignoreCase = true)

        return result
    }

    /**
     * Checks if the payload contains a [split] directive for chunked transmission.
     */
    fun containsSplit(payload: String): Boolean {
        return payload.contains(VAR_SPLIT, ignoreCase = true)
    }

    /**
     * Splits payload into segments based on [split] tag, for evasion or special proxy tricks.
     */
    fun getChunks(resolvedPayloadWithSplit: String): List<ByteArray> {
        val parts = resolvedPayloadWithSplit.split(Regex("(?i)\\[split\\]"))
        return parts.map { it.toByteArray(Charsets.ISO_8859_1) }
    }

    /**
     * Converts resolved payload string to bytes, using standard HTTP US-ASCII or ISO-8859-1 encoding.
     */
    fun toBytes(resolvedPayload: String): ByteArray {
        val clean = resolvedPayload.replace(VAR_SPLIT, "", ignoreCase = true)
        return clean.toByteArray(Charsets.ISO_8859_1)
    }
}

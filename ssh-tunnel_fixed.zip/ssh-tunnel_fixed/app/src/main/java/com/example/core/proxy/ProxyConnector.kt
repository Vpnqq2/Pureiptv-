package com.example.core.proxy

import android.util.Base64
import com.example.core.logs.LogManager
import com.example.core.payload.PayloadEngine
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketAddress
import java.net.SocketTimeoutException
import java.io.ByteArrayInputStream
import java.io.OutputStream
import java.io.SequenceInputStream
import java.net.InetAddress

class ProxyException(message: String) : IOException(message)

object ProxyConnector {

    fun connect(
        proxyHost: String,
        proxyPort: Int,
        payloadTemplate: String,
        sshHost: String,
        sshPort: Int,
        proxyUsername: String = "",
        proxyPassword: String = "",
        timeoutMs: Int = 15000,
        socketProtector: (Socket) -> Boolean
    ): Socket {
        LogManager.i("Connecting to proxy $proxyHost:$proxyPort")
        val socket = Socket()
        socket.tcpNoDelay = true
        socket.soTimeout = timeoutMs

        val protected = socketProtector(socket)
        if (!protected) {
            LogManager.w("Could not protect proxy socket through VPN service")
        }

        socket.connect(InetSocketAddress(proxyHost, proxyPort), timeoutMs)
        LogManager.s("Proxy connected")

        LogManager.i("Sending payload...")
        var resolved = PayloadEngine.resolve(payloadTemplate, sshHost, sshPort)
        if (!LogManager.isRedacting) {
            LogManager.i("Payload: " + resolved.replace("\r", "\\r").replace("\n", "\\n"))
        }

        // Inject Proxy-Authorization if credentials provided and header not already included
        if (proxyUsername.isNotBlank() && !resolved.contains("Proxy-Authorization:", ignoreCase = true)) {
            val authStr = "$proxyUsername:$proxyPassword"
            val encodedAuth = Base64.encodeToString(authStr.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val authHeader = "Proxy-Authorization: Basic $encodedAuth\r\n"

            // Insert before trailing CRLF CRLF
            val crlf2 = "\r\n\r\n"
            if (resolved.contains(crlf2)) {
                val idx = resolved.lastIndexOf(crlf2)
                resolved = resolved.substring(0, idx) + "\r\n" + authHeader + "\r\n"
            } else {
                resolved += authHeader
            }
        }

        writePayload(socket.getOutputStream(), resolved)

        // Many HTTP-injection proxies answer with "200"/"101", but some stay silent (or send the SSH
        // banner directly) and simply wait for the client. So wait only briefly for a reply and then
        // carry on with the SSH handshake instead of hanging on this step.
        val input = socket.getInputStream()
        val waitMs = minOf(timeoutMs, 6000)
        socket.soTimeout = waitMs
        LogManager.i("Reading proxy response (waiting up to ${waitMs / 1000}s)...")

        var prefix: ByteArray? = null
        try {
            val statusLine = readLine(input)
            LogManager.i("Proxy status: $statusLine")

            if (statusLine.startsWith("HTTP/", ignoreCase = true)) {
                val code = statusLine.split(" ").getOrNull(1)?.toIntOrNull()
                if (code == null || code !in 100..299) {
                    socket.close()
                    throw ProxyException("Proxy rejected connection: $statusLine")
                }
                consumeHeaders(input)
                LogManager.s("Proxy accepted the payload ($statusLine)")
            } else {
                // Not an HTTP reply (e.g. the SSH banner itself): hand it back to the SSH client
                prefix = (statusLine + "\r\n").toByteArray(Charsets.ISO_8859_1)
                LogManager.w("Proxy sent a non-HTTP reply; passing it on to SSH")
            }
        } catch (e: SocketTimeoutException) {
            LogManager.w("No reply to the payload within ${waitMs / 1000}s; continuing with the SSH handshake")
        }

        // Reset soTimeout for subsequent SSH traffic
        socket.soTimeout = 0
        return if (prefix != null) PrefixedSocket(socket, prefix) else socket
    }

    /** Writes the resolved payload, honouring [split] (chunks sent separately with a small delay). */
    internal fun writePayload(out: OutputStream, resolved: String) {
        if (PayloadEngine.containsSplit(resolved)) {
            for (chunk in PayloadEngine.getChunks(resolved)) {
                out.write(chunk)
                out.flush()
                Thread.sleep(50)
            }
        } else {
            out.write(PayloadEngine.toBytes(resolved))
            out.flush()
        }
    }

    /** Socket whose input stream first replays bytes that were already read from the proxy. */
    private class PrefixedSocket(private val d: Socket, private val prefix: ByteArray) : Socket() {
        override fun connect(endpoint: SocketAddress?, timeout: Int) {}
        override fun isConnected(): Boolean = d.isConnected
        override fun isBound(): Boolean = d.isBound
        override fun getInputStream(): InputStream = SequenceInputStream(ByteArrayInputStream(prefix), d.getInputStream())
        override fun getOutputStream(): OutputStream = d.getOutputStream()
        override fun close() = d.close()
        override fun isClosed(): Boolean = d.isClosed
        override fun setSoTimeout(timeout: Int) { d.soTimeout = timeout }
        override fun getSoTimeout(): Int = d.soTimeout
        override fun setTcpNoDelay(on: Boolean) { d.tcpNoDelay = on }
        override fun getTcpNoDelay(): Boolean = d.tcpNoDelay
        override fun setKeepAlive(on: Boolean) { d.keepAlive = on }
        override fun getKeepAlive(): Boolean = d.keepAlive
        override fun getInetAddress(): InetAddress? = d.inetAddress
        override fun getPort(): Int = d.port
        override fun getLocalAddress(): InetAddress? = d.localAddress
        override fun getLocalPort(): Int = d.localPort
    }

    private fun readLine(input: InputStream): String {
        val baos = ByteArrayOutputStream()
        var c = input.read()
        while (c != -1) {
            if (c == '\n'.code) {
                break
            }
            if (c != '\r'.code) {
                baos.write(c)
            }
            c = input.read()
        }
        if (c == -1 && baos.size() == 0) {
            throw IOException("Premature EOF while reading proxy response")
        }
        return baos.toString("ISO-8859-1")
    }

    private fun consumeHeaders(input: InputStream) {
        // The status line is already consumed: skip header lines up to and including the blank line.
        while (true) {
            if (readLine(input).isEmpty()) break
        }
    }
}

package com.example.core.ssh

import com.example.core.logs.LogManager
import net.schmizz.sshj.SSHClient
import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class LocalSocks5Server(
    private val sshClientProvider: () -> SSHClient?,
    val port: Int = 0, // 0 means allocate ephemeral free port
    private val udpgwPort: Int = 0 // >0: relay non-DNS UDP through badvpn-udpgw on the SSH server
) : Closeable {

    private var serverSocket: ServerSocket? = null
    val isRunning = AtomicBoolean(false)
    val actualPort: Int get() = serverSocket?.localPort ?: port

    val totalDownloaded = AtomicLong(0)
    val totalUploaded = AtomicLong(0)

    private val executor: ExecutorService = Executors.newCachedThreadPool()
    private val scheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var udpgwBackoffUntil = 0L
    private val dnsFailures = AtomicLong(0)
    private val activeConnections = ConcurrentHashMap<Socket, Boolean>()

    fun start(): Int {
        val server = ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))
        serverSocket = server
        isRunning.set(true)

        executor.submit {
            while (isRunning.get() && !server.isClosed) {
                try {
                    val clientSocket = server.accept()
                    clientSocket.tcpNoDelay = true
                    activeConnections[clientSocket] = true
                    executor.submit {
                        handleClient(clientSocket)
                    }
                } catch (e: Exception) {
                    if (isRunning.get()) {
                        LogManager.w("SOCKS5 accept error: ${e.message}")
                    }
                }
            }
        }

        LogManager.i("Local SOCKS5 proxy listening on 127.0.0.1:$actualPort")
        return actualPort
    }

    private fun handleClient(clientSocket: Socket) {
        var sshChannel: Closeable? = null
        try {
            val input = clientSocket.getInputStream()
            val output = clientSocket.getOutputStream()

            // 1. SOCKS5 Greeting
            val socksVersion = input.read()
            if (socksVersion != 0x05) {
                clientSocket.close()
                return
            }

            val nMethods = input.read()
            val methods = ByteArray(nMethods)
            readFully(input, methods)

            // Respond: SOCKS5, No Authentication Required (0x00)
            output.write(byteArrayOf(0x05, 0x00))
            output.flush()

            // 2. SOCKS5 Request
            val ver = input.read()
            val cmd = input.read()
            val rsv = input.read()
            val atyp = input.read()

            if (ver != 0x05) {
                clientSocket.close()
                return
            }

            val targetHost = when (atyp) {
                0x01 -> { // IPv4
                    val ip = ByteArray(4)
                    readFully(input, ip)
                    InetAddress.getByAddress(ip).hostAddress ?: "127.0.0.1"
                }
                0x03 -> { // Domain name
                    val len = input.read()
                    val domainBytes = ByteArray(len)
                    readFully(input, domainBytes)
                    String(domainBytes, Charsets.US_ASCII)
                }
                0x04 -> { // IPv6
                    val ip = ByteArray(16)
                    readFully(input, ip)
                    InetAddress.getByAddress(ip).hostAddress ?: "::1"
                }
                else -> {
                    output.write(byteArrayOf(0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                    output.flush()
                    clientSocket.close()
                    return
                }
            }

            val portH = input.read()
            val portL = input.read()
            val targetPort = (portH shl 8) or (portL and 0xFF)

            when (cmd) {
                0x01 -> Unit // CONNECT: handled below
                0x03 -> { // UDP ASSOCIATE: used by HEV for DNS (relayed over SSH as DNS-over-TCP)
                    handleUdpAssociate(output, input)
                    return
                }
                else -> {
                    output.write(byteArrayOf(0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                    output.flush()
                    return
                }
            }

            val sshClient = sshClientProvider()
            if (sshClient == null || !sshClient.isConnected) {
                // Network unreachable
                output.write(byteArrayOf(0x05, 0x03, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                output.flush()
                clientSocket.close()
                return
            }

            // Open direct-tcpip channel via SSH
            val directConn = sshClient.newDirectConnection(targetHost, targetPort)
            sshChannel = directConn

            // Respond success: SOCKS5, 0x00 Success, RSV 0x00, ATYP 0x01, IP 0.0.0.0, Port 0
            output.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
            output.flush()

            val sshIn = directConn.inputStream
            val sshOut = directConn.outputStream

            // Bidirectional streaming with counters
            val t1 = Thread {
                pipe(input, sshOut, totalUploaded)
            }
            val t2 = Thread {
                pipe(sshIn, output, totalDownloaded)
            }

            t1.start()
            t2.start()
            t1.join()
            t2.join()

        } catch (_: Exception) {
            // Channel or socket closed
        } finally {
            activeConnections.remove(clientSocket)
            try { sshChannel?.close() } catch (_: Exception) {}
            try { clientSocket.close() } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------------
    // UDP ASSOCIATE (RFC 1928). SSH cannot carry UDP, so only DNS (port 53)
    // datagrams are supported: each query is forwarded through the SSH tunnel
    // as DNS-over-TCP (RFC 7766) and the answer is returned as a UDP datagram.
    // Any other UDP traffic is dropped, so apps fall back to TCP.
    // ---------------------------------------------------------------------

    private class UdpRequest(val header: ByteArray, val host: String, val port: Int, val payload: ByteArray)

    private fun handleUdpAssociate(output: OutputStream, controlInput: InputStream) {
        val udp = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
        try {
            val bound = udp.localPort
            output.write(
                byteArrayOf(
                    0x05, 0x00, 0x00, 0x01, 127, 0, 0, 1,
                    (bound shr 8).toByte(), (bound and 0xFF).toByte()
                )
            )
            output.flush()

            val gw = if (udpgwPort > 0) UdpgwSession(udp) else null
            val relay = executor.submit(Runnable { udpRelayLoop(udp, gw) })
            // The association lives as long as the TCP control connection.
            try {
                while (controlInput.read() != -1) { /* discard */ }
            } catch (_: Exception) {
            }
            relay.cancel(true)
            gw?.close()
        } finally {
            try { udp.close() } catch (_: Exception) {}
        }
    }

    private fun udpRelayLoop(udp: DatagramSocket, gw: UdpgwSession?) {
        val buf = ByteArray(65535)
        while (isRunning.get() && !udp.isClosed) {
            val pkt = DatagramPacket(buf, buf.size)
            try {
                udp.receive(pkt)
            } catch (_: Exception) {
                break
            }
            val req = parseUdpRequest(pkt.data, pkt.length) ?: continue
            val clientAddr = pkt.address
            val clientPort = pkt.port
            if (req.port != 53) {
                // Non-DNS UDP: only possible through UDPGW, otherwise dropped
                gw?.send(req, clientAddr, clientPort)
                continue
            }
            if (req.payload.size < 12) continue
            try {
                executor.submit(Runnable { relayDnsQuery(udp, req, clientAddr, clientPort) })
            } catch (_: Exception) {
                break
            }
        }
    }

    private fun parseUdpRequest(data: ByteArray, length: Int): UdpRequest? {
        if (length < 10) return null
        if (data[0].toInt() != 0 || data[1].toInt() != 0 || data[2].toInt() != 0) return null // RSV / FRAG
        var pos = 4
        val host: String = when (data[3].toInt()) {
            0x01 -> {
                if (length < pos + 4 + 2) return null
                val h = InetAddress.getByAddress(data.copyOfRange(pos, pos + 4)).hostAddress
                pos += 4
                h ?: return null
            }
            0x03 -> {
                val len = data[pos].toInt() and 0xFF
                pos += 1
                if (length < pos + len + 2) return null
                val h = String(data, pos, len, Charsets.US_ASCII)
                pos += len
                h
            }
            0x04 -> {
                if (length < pos + 16 + 2) return null
                val h = InetAddress.getByAddress(data.copyOfRange(pos, pos + 16)).hostAddress
                pos += 16
                h ?: return null
            }
            else -> return null
        }
        val port = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
        pos += 2
        return UdpRequest(
            header = data.copyOfRange(0, pos),
            host = host,
            port = port,
            payload = data.copyOfRange(pos, length)
        )
    }

    private fun relayDnsQuery(udp: DatagramSocket, req: UdpRequest, clientAddr: InetAddress, clientPort: Int) {
        val ssh = sshClientProvider()
        if (ssh == null || !ssh.isConnected) return

        var channel: Closeable? = null
        // Hard timeout: closing the channel unblocks any pending read.
        val watchdog = scheduler.schedule(Runnable {
            try { channel?.close() } catch (_: Exception) {}
        }, 5, TimeUnit.SECONDS)

        try {
            val conn = ssh.newDirectConnection(req.host, 53)
            channel = conn

            val out = conn.outputStream
            val framed = ByteArray(2 + req.payload.size)
            framed[0] = (req.payload.size shr 8).toByte()
            framed[1] = (req.payload.size and 0xFF).toByte()
            System.arraycopy(req.payload, 0, framed, 2, req.payload.size)
            out.write(framed)
            out.flush()
            totalUploaded.addAndGet(req.payload.size.toLong())

            val inp = conn.inputStream
            val hi = inp.read()
            val lo = inp.read()
            if (hi < 0 || lo < 0) return
            val len = (hi shl 8) or lo
            val answer = ByteArray(len)
            readFully(inp, answer)
            totalDownloaded.addAndGet(len.toLong())

            val reply = ByteArray(req.header.size + len)
            System.arraycopy(req.header, 0, reply, 0, req.header.size)
            System.arraycopy(answer, 0, reply, req.header.size, len)
            udp.send(DatagramPacket(reply, reply.size, clientAddr, clientPort))
        } catch (e: Exception) {
            // Timeout / channel closed: the app will retry or fall back to its secondary DNS
            if (dnsFailures.incrementAndGet() <= 5) {
                LogManager.w("DNS-over-TCP to ${req.host}:53 through SSH failed: ${e.message ?: e.javaClass.simpleName}")
            }
        } finally {
            watchdog.cancel(false)
            try { channel?.close() } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------------
    // UDPGW client (badvpn-udpgw protocol). One SSH direct-tcpip channel to
    // 127.0.0.1:<udpgwPort> on the server per UDP association. Framing:
    //   [len: u16 LE] [flags: u8] [conid: u16 LE] [addr: ip(4|16) + port(u16 BE)] [data]
    // flags: 0x01 keepalive, 0x02 rebind, 0x04 dns, 0x08 ipv6.
    // The server echoes the original destination address in replies.
    // ---------------------------------------------------------------------

    private inner class UdpgwSession(private val udp: DatagramSocket) : Closeable {
        private var channel: Closeable? = null
        private var out: OutputStream? = null
        private var openedAt = 0L
        @Volatile private var receivedAny = false
        private val conIds = HashMap<String, Int>()
        private val headers = ConcurrentHashMap<Int, ByteArray>()
        private var nextConId = 1
        @Volatile private var clientAddr: InetAddress? = null
        @Volatile private var clientPort = 0
        @Volatile private var closed = false

        @Synchronized
        fun send(req: UdpRequest, addr: InetAddress, port: Int) {
            if (closed) return
            val atyp = req.header[3].toInt()
            if (atyp != 0x01 && atyp != 0x04) return // udpgw has no domain-name destinations
            clientAddr = addr
            clientPort = port
            val o = ensureChannel() ?: return

            val dest = req.header.copyOfRange(4, req.header.size) // ip + port (big endian)
            val key = "$atyp:" + dest.joinToString(",")
            if (conIds.size >= 4096) { conIds.clear(); headers.clear(); nextConId = 1 }
            val conId = conIds.getOrPut(key) {
                val id = nextConId
                nextConId = if (id >= 0xFFFF) 1 else id + 1
                headers[id] = req.header
                id
            }

            val payloadLen = 3 + dest.size + req.payload.size
            if (payloadLen > 0xFFFF) return
            val frame = ByteArray(2 + payloadLen)
            frame[0] = (payloadLen and 0xFF).toByte()
            frame[1] = (payloadLen shr 8).toByte()
            frame[2] = (if (atyp == 0x04) 0x08 else 0x00).toByte()
            frame[3] = (conId and 0xFF).toByte()
            frame[4] = (conId shr 8).toByte()
            System.arraycopy(dest, 0, frame, 5, dest.size)
            System.arraycopy(req.payload, 0, frame, 5 + dest.size, req.payload.size)
            try {
                o.write(frame)
                o.flush()
                totalUploaded.addAndGet(req.payload.size.toLong())
            } catch (_: Exception) {
                resetChannel()
            }
        }

        private fun ensureChannel(): OutputStream? {
            out?.let { return it }
            if (System.currentTimeMillis() < udpgwBackoffUntil) return null
            val ssh = sshClientProvider()
            if (ssh == null || !ssh.isConnected) return null
            return try {
                val conn = ssh.newDirectConnection("127.0.0.1", udpgwPort)
                channel = conn
                out = conn.outputStream
                openedAt = System.currentTimeMillis()
                receivedAny = false
                val input = conn.inputStream
                executor.submit(Runnable { readLoop(input, conn) })
                out
            } catch (e: Exception) {
                markUnavailable("cannot open channel: ${e.message}")
                null
            }
        }

        private fun markUnavailable(reason: String) {
            if (System.currentTimeMillis() >= udpgwBackoffUntil) {
                LogManager.w("UDPGW unavailable on server (127.0.0.1:$udpgwPort): $reason. UDP apps will not work; DNS still does.")
            }
            udpgwBackoffUntil = System.currentTimeMillis() + 30_000
        }

        private fun readLoop(input: InputStream, conn: Closeable) {
            try {
                while (!closed) {
                    val lo = input.read()
                    val hi = input.read()
                    if (lo < 0 || hi < 0) break
                    val len = (hi shl 8) or lo
                    val p = ByteArray(len)
                    readFully(input, p)
                    if (len < 3) continue
                    receivedAny = true
                    val flags = p[0].toInt() and 0xFF
                    if ((flags and 0x01) != 0) continue // keepalive
                    val conId = (p[1].toInt() and 0xFF) or ((p[2].toInt() and 0xFF) shl 8)
                    val addrLen = if ((flags and 0x08) != 0) 18 else 6
                    if (len < 3 + addrLen) continue
                    val header = headers[conId] ?: continue
                    val dataLen = len - 3 - addrLen
                    val reply = ByteArray(header.size + dataLen)
                    System.arraycopy(header, 0, reply, 0, header.size)
                    System.arraycopy(p, 3 + addrLen, reply, header.size, dataLen)
                    val ca = clientAddr ?: continue
                    udp.send(DatagramPacket(reply, reply.size, ca, clientPort))
                    totalDownloaded.addAndGet(dataLen.toLong())
                }
            } catch (_: Exception) {
            } finally {
                synchronized(this) {
                    if (channel === conn) {
                        // Closed right after opening without any data: server has no udpgw listening
                        if (!closed && !receivedAny && System.currentTimeMillis() - openedAt < 3000) {
                            markUnavailable("server closed the channel immediately")
                        }
                        resetChannel()
                    }
                }
            }
        }

        private fun resetChannel() {
            try { channel?.close() } catch (_: Exception) {}
            channel = null
            out = null
            conIds.clear()
            headers.clear()
        }

        @Synchronized
        override fun close() {
            closed = true
            resetChannel()
        }
    }

    private fun pipe(input: InputStream, output: OutputStream, counter: AtomicLong) {
        val buffer = ByteArray(16384)
        try {
            var read: Int
            while (isRunning.get()) {
                read = input.read(buffer)
                if (read == -1) break
                output.write(buffer, 0, read)
                output.flush()
                counter.addAndGet(read.toLong())
            }
        } catch (_: Exception) {
        } finally {
            try { output.close() } catch (_: Exception) {}
        }
    }

    private fun readFully(input: InputStream, buffer: ByteArray) {
        var offset = 0
        while (offset < buffer.size) {
            val count = input.read(buffer, offset, buffer.size - offset)
            if (count == -1) throw IOException("Unexpected end of stream")
            offset += count
        }
    }

    override fun close() {
        isRunning.set(false)
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        activeConnections.keys.forEach { socket ->
            try { socket.close() } catch (_: Exception) {}
        }
        activeConnections.clear()
        executor.shutdownNow()
        scheduler.shutdownNow()
    }
}

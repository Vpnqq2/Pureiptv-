package com.example.core.tls

import android.annotation.SuppressLint
import java.net.Socket
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Wraps an already connected socket in TLS, announcing a chosen SNI (server name).
 *
 * Typical use: the SSH server (or a front such as stunnel / nginx stream / haproxy) listens for TLS on
 * port 443 and the SNI sent in the ClientHello is a host that the network treats specially.
 *
 * When [verify] is false the server certificate is NOT checked (it will rarely match an arbitrary SNI).
 * That is acceptable here only because the SSH session that runs inside the tunnel authenticates the
 * server itself (host key is pinned on first use) - do not reuse this for anything else.
 */
object TlsConnector {

    @SuppressLint("CustomX509TrustManager", "TrustAllX509TrustManager")
    private object TrustAll : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    fun wrap(
        socket: Socket,
        sni: String,
        serverHost: String,
        port: Int,
        verify: Boolean,
        timeoutMs: Int
    ): SSLSocket {
        val context = SSLContext.getInstance("TLS")
        if (verify) {
            context.init(null, null, null)
        } else {
            context.init(null, arrayOf<TrustManager>(TrustAll), SecureRandom())
        }

        val name = sni.trim().ifEmpty { serverHost }
        val ssl = context.socketFactory.createSocket(socket, name, port, true) as SSLSocket

        val params = ssl.sslParameters
        // IP literals cannot be sent as SNI
        if (!isIpLiteral(name)) {
            params.serverNames = listOf(SNIHostName(name))
        }
        if (verify) {
            params.endpointIdentificationAlgorithm = "HTTPS"
        }
        ssl.sslParameters = params

        ssl.soTimeout = timeoutMs
        ssl.startHandshake()
        ssl.soTimeout = 0
        return ssl
    }

    private fun isIpLiteral(host: String): Boolean =
        host.contains(':') || host.matches(Regex("""\d{1,3}(\.\d{1,3}){3}"""))
}

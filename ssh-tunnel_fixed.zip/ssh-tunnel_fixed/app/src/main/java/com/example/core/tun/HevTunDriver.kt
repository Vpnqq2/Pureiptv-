package com.example.core.tun

import android.content.Context
import android.os.ParcelFileDescriptor
import com.example.core.logs.LogManager
import com.example.data.model.TrafficStats
import hev.htproxy.TProxyService
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class HevTunDriver(
    private val context: Context,
    private val socksStatsProvider: () -> Pair<Long, Long> = { 0L to 0L }
) : TunDriver {

    private var configFile: File? = null
    private val isStarted = AtomicBoolean(false)

    override fun start(
        pfd: ParcelFileDescriptor,
        socksHost: String,
        socksPort: Int,
        mtu: Int,
        dnsServers: List<String>
    ): Boolean {
        LogManager.i("Creating HEV configuration for 127.0.0.1:$socksPort (MTU: $mtu)...")

        val useMapDns = dnsServers.contains(TunDriver.MAP_DNS_ADDRESS)
        val mapDnsBlock = if (useMapDns) """

mapdns:
  address: ${TunDriver.MAP_DNS_ADDRESS}
  port: 53
  network: 100.64.0.0
  netmask: 255.192.0.0
  cache-size: 10000
""" else ""

        val configContent = """
tunnel:
  name: tun0
  mtu: $mtu
  multi-queue: false
  ipv4: 198.18.0.1
  ipv6: 'fc00::1'

socks5:
  address: $socksHost
  port: $socksPort
  udp: 'udp'
""".trimIndent() + mapDnsBlock

        val file = File(context.filesDir, "hev-tunnel.yaml")
        try {
            file.writeText(configContent)
            this.configFile = file
            LogManager.i("HEV configuration written to ${file.absolutePath}")
        } catch (e: Exception) {
            LogManager.e("Failed to create HEV config: ${e.message}")
            return false
        }

        val tunFd = pfd.fd
        LogManager.i("Starting TProxyService with tunFd=$tunFd...")

        val startResult = try {
            TProxyService.TProxyStartService(file.absolutePath, tunFd)
        } catch (e: Exception) {
            LogManager.e("Exception while calling TProxyStartService: ${e.message}")
            file.delete()
            return false
        }

        val isRunning = try {
            TProxyService.TProxyIsRunning()
        } catch (_: Exception) {
            false
        }

        if (!startResult || !isRunning) {
            LogManager.e("HEV TProxyService failed to start (startResult=$startResult, isRunning=$isRunning)")
            try {
                TProxyService.TProxyStopService()
            } catch (_: Exception) {}
            file.delete()
            configFile = null
            isStarted.set(false)
            return false
        }

        isStarted.set(true)
        LogManager.s("HEV TProxyService started successfully (TUN -> SOCKS5 active)")
        return true
    }

    override fun stop() {
        LogManager.i("Stopping HEV TProxyService...")
        try {
            if (TProxyService.TProxyIsRunning()) {
                TProxyService.TProxyStopService()
                LogManager.s("HEV TProxyService stopped")
            }
        } catch (e: Exception) {
            LogManager.w("Error stopping TProxyService: ${e.message}")
        } finally {
            isStarted.set(false)
            configFile?.delete()
            configFile = null
        }
    }

    override fun isRunning(): Boolean {
        return try {
            TProxyService.TProxyIsRunning()
        } catch (_: Exception) {
            false
        }
    }

    override fun stats(): TrafficStats {
        // Byte counters come from the local SOCKS5 server (exact payload bytes through the SSH tunnel).
        // The native TProxyGetStats() array holds packet/byte counters whose direction semantics are
        // not guaranteed, so it is intentionally not mixed in here.
        val (socksDown, socksUp) = socksStatsProvider()
        return TrafficStats(
            downloadBytes = socksDown,
            uploadBytes = socksUp
        )
    }
}

package com.example.data.backup

/**
 * Application-level secret used to seal "locked" config files.
 *
 * It is assembled at runtime from masked fragments so it does not appear as a plain constant. This is
 * obfuscation, not secrecy: anyone who reverse-engineers the APK can recover it. For real protection a
 * locked file should also be sealed with a password (see ConfigBackup.encryptLocked).
 */
internal object AppSecret {
    private val a0 = intArrayOf(0x7B, 0x41, 0xEC, 0xB8, 0x8E, 0x4B, 0xF2, 0xE5)
    private val m0 = intArrayOf(0x95, 0xE0, 0x82, 0x32, 0xAB, 0x51, 0x24, 0x69)
    private val a1 = intArrayOf(0xCB, 0x7B, 0x44, 0xDB, 0x04, 0x72, 0x30, 0xC4)
    private val m1 = intArrayOf(0x29, 0xA3, 0x47, 0x2E, 0x85, 0x3C, 0x4B, 0xB0)
    private val a2 = intArrayOf(0xFA, 0x5F, 0x9B, 0x3A, 0x65, 0xC6, 0xDF, 0x00)
    private val m2 = intArrayOf(0x87, 0x32, 0x3D, 0xB6, 0xF7, 0xBB, 0xE2, 0x37)
    private val a3 = intArrayOf(0x12, 0x0C, 0x30, 0xF5, 0x23, 0x4F, 0x14, 0x6F)
    private val m3 = intArrayOf(0xFA, 0xED, 0x17, 0x8C, 0xBE, 0x87, 0x9C, 0xD6)

    fun material(): ByteArray {
        val out = ByteArray(32)
        val enc = listOf(a0, a1, a2, a3)
        val mask = listOf(m0, m1, m2, m3)
        for (p in 0 until 4) {
            for (i in 0 until 8) {
                out[p * 8 + i] = (enc[p][i] xor mask[p][i]).toByte()
            }
        }
        return out
    }
}

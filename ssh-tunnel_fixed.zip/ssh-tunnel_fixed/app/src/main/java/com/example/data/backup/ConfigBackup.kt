package com.example.data.backup

import org.bouncycastle.crypto.digests.SHA256Digest
import org.bouncycastle.crypto.generators.Argon2BytesGenerator
import org.bouncycastle.crypto.generators.HKDFBytesGenerator
import org.bouncycastle.crypto.params.HKDFParameters
import org.bouncycastle.crypto.params.Argon2Parameters
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class BackupException(message: String) : Exception(message)

/** How a config file is protected. */
enum class ExportMode {
    /** Sealed with a password; whoever imports it (with the password) can see and edit the configs. */
    PASSWORD,
    /** Importer can use the configs but cannot see or export their details. Optional extra password. */
    LOCKED,
    /** Readable JSON. */
    PLAIN
}

class ExportOptions(val mode: ExportMode, val password: String?)

enum class BackupKind { PLAIN_JSON, PASSWORD, LOCKED, LOCKED_PASSWORD }

/** A config with its secrets in clear text, as stored inside a backup file. */
data class PlainConfig(
    val name: String,
    val sshHost: String,
    val sshPort: Int,
    val sshUsername: String,
    val sshPassword: String,
    val sshKeyContent: String,
    val sshKeyFileName: String,
    val proxyHost: String,
    val proxyPort: Int,
    val proxyUsername: String,
    val proxyPassword: String,
    val payload: String,
    val tlsEnabled: Boolean = false,
    val sniHost: String = "",
    val tlsVerify: Boolean = false,
    val countryCode: String = "",
    val flagUrl: String = ""
)

/**
 * Backup file format.
 *
 * Plain:      UTF-8 JSON (passwords in clear text, anyone can read it).
 * Encrypted:  "SSHT" | version(1) | argon2 memory KiB (4, BE) | iterations(1) | parallelism(1)
 *             | salt(16) | iv(12) | AES-256-GCM ciphertext+tag
 *             Key = Argon2id(password, salt). The whole header is authenticated (GCM AAD),
 *             so any modification of the file or the parameters is detected.
 *
 * The strength of an encrypted file is the strength of the password: a long passphrase cannot
 * realistically be brute-forced, a short one can.
 */
object ConfigBackup {

    private val MAGIC = byteArrayOf(0x53, 0x53, 0x48, 0x54) // "SSHT"
    private const val VERSION = 1
    private const val SALT_LEN = 16
    private const val IV_LEN = 12
    private const val TAG_BITS = 128
    private const val HEADER_LEN = 4 + 1 + 4 + 1 + 1 + SALT_LEN + IV_LEN

    // Argon2id cost used when exporting (64 MiB, 3 passes, 2 lanes)
    private const val MEM_KIB = 65536
    private const val ITERATIONS = 3
    private const val PARALLELISM = 2

    // Upper bounds accepted when importing, so a crafted file cannot exhaust the phone's memory/CPU
    private const val MIN_MEM_KIB = 8192
    private const val MAX_MEM_KIB = 262144
    private const val MAX_ITERATIONS = 10
    private const val MAX_PARALLELISM = 8

    const val MIN_PASSWORD_LENGTH = 8

    private val LOCKED_MAGIC = byteArrayOf(0x53, 0x53, 0x48, 0x4B) // "SSHK"
    private const val FLAG_PASSWORD = 1
    private const val LOCKED_HEADER_LEN = 4 + 1 + 1 + 4 + 1 + 1 + SALT_LEN + IV_LEN
    private val LOCKED_INFO = "ssh-tunnel-locked-v1".toByteArray(Charsets.US_ASCII)

    fun kind(data: ByteArray): BackupKind {
        if (isEncrypted(data)) return BackupKind.PASSWORD
        if (data.size > LOCKED_HEADER_LEN && data.copyOfRange(0, 4).contentEquals(LOCKED_MAGIC)) {
            return if ((data[5].toInt() and FLAG_PASSWORD) != 0) BackupKind.LOCKED_PASSWORD else BackupKind.LOCKED
        }
        return BackupKind.PLAIN_JSON
    }

    fun needsPassword(data: ByteArray): Boolean =
        kind(data).let { it == BackupKind.PASSWORD || it == BackupKind.LOCKED_PASSWORD }

    fun isEncrypted(data: ByteArray): Boolean =
        data.size > HEADER_LEN && data.copyOfRange(0, 4).contentEquals(MAGIC)

    // ------------------------------------------------------------------ crypto

    fun encrypt(plain: ByteArray, password: String): ByteArray {
        val random = SecureRandom()
        val salt = ByteArray(SALT_LEN).also { random.nextBytes(it) }
        val iv = ByteArray(IV_LEN).also { random.nextBytes(it) }

        val header = ByteBuffer.allocate(HEADER_LEN)
            .put(MAGIC)
            .put(VERSION.toByte())
            .putInt(MEM_KIB)
            .put(ITERATIONS.toByte())
            .put(PARALLELISM.toByte())
            .put(salt)
            .put(iv)
            .array()

        val key = deriveKey(password, salt, MEM_KIB, ITERATIONS, PARALLELISM)
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, iv))
            cipher.updateAAD(header)
            return header + cipher.doFinal(plain)
        } finally {
            key.fill(0)
        }
    }

    fun decrypt(data: ByteArray, password: String): ByteArray {
        if (!isEncrypted(data)) throw BackupException("Not an encrypted backup file")

        val buffer = ByteBuffer.wrap(data)
        buffer.position(MAGIC.size)
        val version = buffer.get().toInt()
        if (version != VERSION) throw BackupException("Unsupported backup version ($version)")

        val memKib = buffer.int
        val iterations = buffer.get().toInt() and 0xFF
        val parallelism = buffer.get().toInt() and 0xFF
        if (memKib !in MIN_MEM_KIB..MAX_MEM_KIB ||
            iterations !in 1..MAX_ITERATIONS ||
            parallelism !in 1..MAX_PARALLELISM
        ) {
            throw BackupException("Backup file has unsupported or unsafe parameters")
        }

        val salt = ByteArray(SALT_LEN).also { buffer.get(it) }
        val iv = ByteArray(IV_LEN).also { buffer.get(it) }
        val header = data.copyOfRange(0, HEADER_LEN)
        val cipherText = data.copyOfRange(HEADER_LEN, data.size)

        val key = deriveKey(password, salt, memKib, iterations, parallelism)
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, iv))
            cipher.updateAAD(header)
            return cipher.doFinal(cipherText)
        } catch (e: Exception) {
            throw BackupException("Wrong password or corrupted file")
        } finally {
            key.fill(0)
        }
    }

    // ------------------------------------------------------------ locked files

    /**
     * "Locked" file: AES-256-GCM, key = HKDF-SHA256(appSecret || [Argon2id(password)], salt).
     * Without a password the key only depends on a secret embedded in the app (obfuscation level);
     * with a password the file is as strong as that password.
     */
    fun encryptLocked(plain: ByteArray, password: String?): ByteArray {
        val usePassword = !password.isNullOrEmpty()
        val random = SecureRandom()
        val salt = ByteArray(SALT_LEN).also { random.nextBytes(it) }
        val iv = ByteArray(IV_LEN).also { random.nextBytes(it) }
        val mem = if (usePassword) MEM_KIB else 0
        val iter = if (usePassword) ITERATIONS else 0
        val par = if (usePassword) PARALLELISM else 0

        val header = ByteBuffer.allocate(LOCKED_HEADER_LEN)
            .put(LOCKED_MAGIC)
            .put(VERSION.toByte())
            .put((if (usePassword) FLAG_PASSWORD else 0).toByte())
            .putInt(mem)
            .put(iter.toByte())
            .put(par.toByte())
            .put(salt)
            .put(iv)
            .array()

        val key = lockedKey(if (usePassword) password else null, salt, mem, iter, par)
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, iv))
            cipher.updateAAD(header)
            return header + cipher.doFinal(plain)
        } finally {
            key.fill(0)
        }
    }

    fun decryptLocked(data: ByteArray, password: String?): ByteArray {
        val kind = kind(data)
        if (kind != BackupKind.LOCKED && kind != BackupKind.LOCKED_PASSWORD) {
            throw BackupException("Not a locked config file")
        }
        val buffer = ByteBuffer.wrap(data)
        buffer.position(LOCKED_MAGIC.size)
        val version = buffer.get().toInt()
        if (version != VERSION) throw BackupException("Unsupported backup version ($version)")
        val flags = buffer.get().toInt()
        val usePassword = (flags and FLAG_PASSWORD) != 0
        val mem = buffer.int
        val iter = buffer.get().toInt() and 0xFF
        val par = buffer.get().toInt() and 0xFF
        if (usePassword) {
            if (password.isNullOrEmpty()) throw BackupException("A password is required")
            if (mem !in MIN_MEM_KIB..MAX_MEM_KIB || iter !in 1..MAX_ITERATIONS || par !in 1..MAX_PARALLELISM) {
                throw BackupException("Backup file has unsupported or unsafe parameters")
            }
        }
        val salt = ByteArray(SALT_LEN).also { buffer.get(it) }
        val iv = ByteArray(IV_LEN).also { buffer.get(it) }
        val header = data.copyOfRange(0, LOCKED_HEADER_LEN)
        val cipherText = data.copyOfRange(LOCKED_HEADER_LEN, data.size)

        val key = lockedKey(if (usePassword) password else null, salt, mem, iter, par)
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, iv))
            cipher.updateAAD(header)
            return cipher.doFinal(cipherText)
        } catch (e: Exception) {
            throw BackupException(
                if (usePassword) "Wrong password or corrupted file" else "This file is corrupted or not made for this app"
            )
        } finally {
            key.fill(0)
        }
    }

    private fun lockedKey(password: String?, salt: ByteArray, mem: Int, iter: Int, par: Int): ByteArray {
        val secret = AppSecret.material()
        val stretched = if (password != null) deriveKey(password, salt, mem, iter, par) else ByteArray(0)
        val ikm = secret + stretched
        try {
            val hkdf = HKDFBytesGenerator(SHA256Digest())
            hkdf.init(HKDFParameters(ikm, salt, LOCKED_INFO))
            val out = ByteArray(32)
            hkdf.generateBytes(out, 0, 32)
            return out
        } finally {
            secret.fill(0)
            stretched.fill(0)
            ikm.fill(0)
        }
    }

    private fun deriveKey(password: String, salt: ByteArray, memKib: Int, iterations: Int, parallelism: Int): ByteArray {
        val params = Argon2Parameters.Builder(Argon2Parameters.ARGON2_id)
            .withVersion(Argon2Parameters.ARGON2_VERSION_13)
            .withIterations(iterations)
            .withMemoryAsKB(memKib)
            .withParallelism(parallelism)
            .withSalt(salt)
            .build()
        val generator = Argon2BytesGenerator()
        generator.init(params)
        val key = ByteArray(32)
        generator.generateBytes(password.toByteArray(Charsets.UTF_8), key)
        return key
    }

    // -------------------------------------------------------------------- JSON

    fun toJson(items: List<PlainConfig>): ByteArray {
        val array = JSONArray()
        for (c in items) {
            array.put(
                JSONObject()
                    .put("name", c.name)
                    .put("sshHost", c.sshHost)
                    .put("sshPort", c.sshPort)
                    .put("sshUsername", c.sshUsername)
                    .put("sshPassword", c.sshPassword)
                    .put("sshKeyContent", c.sshKeyContent)
                    .put("sshKeyFileName", c.sshKeyFileName)
                    .put("proxyHost", c.proxyHost)
                    .put("proxyPort", c.proxyPort)
                    .put("proxyUsername", c.proxyUsername)
                    .put("proxyPassword", c.proxyPassword)
                    .put("payload", c.payload)
                    .put("tlsEnabled", c.tlsEnabled)
                    .put("sniHost", c.sniHost)
                    .put("tlsVerify", c.tlsVerify)
                    .put("countryCode", c.countryCode)
                    .put("flagUrl", c.flagUrl)
            )
        }
        val root = JSONObject()
            .put("app", "ssh-tunnel")
            .put("version", 1)
            .put("configs", array)
        return root.toString(2).toByteArray(Charsets.UTF_8)
    }

    fun fromJson(data: ByteArray): List<PlainConfig> {
        val root = try {
            JSONObject(String(data, Charsets.UTF_8).trimStart('﻿'))
        } catch (e: Exception) {
            throw BackupException("This is not a valid config file")
        }
        if (root.optString("app") != "ssh-tunnel") throw BackupException("This is not a config file of this app")
        val array = root.optJSONArray("configs") ?: throw BackupException("The file contains no configs")

        val result = ArrayList<PlainConfig>()
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val host = o.optString("sshHost").trim()
            if (host.isEmpty()) continue
            result.add(
                PlainConfig(
                    name = o.optString("name").ifBlank { host },
                    sshHost = host,
                    sshPort = o.optInt("sshPort", 22).takeIf { it in 1..65535 } ?: 22,
                    sshUsername = o.optString("sshUsername"),
                    sshPassword = o.optString("sshPassword"),
                    sshKeyContent = o.optString("sshKeyContent"),
                    sshKeyFileName = o.optString("sshKeyFileName"),
                    proxyHost = o.optString("proxyHost"),
                    proxyPort = o.optInt("proxyPort", 8080).takeIf { it in 1..65535 } ?: 8080,
                    proxyUsername = o.optString("proxyUsername"),
                    proxyPassword = o.optString("proxyPassword"),
                    payload = o.optString("payload"),
                    tlsEnabled = o.optBoolean("tlsEnabled", false),
                    sniHost = o.optString("sniHost"),
                    tlsVerify = o.optBoolean("tlsVerify", false),
                    countryCode = o.optString("countryCode").trim().uppercase().take(2),
                    flagUrl = o.optString("flagUrl").trim()
                )
            )
        }
        if (result.isEmpty()) throw BackupException("The file contains no valid configs")
        return result
    }
}

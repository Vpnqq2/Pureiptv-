package com.example.data.local

import android.content.Context
import com.example.data.backup.BackupException
import com.example.data.backup.BackupKind
import com.example.data.backup.ConfigBackup
import com.example.data.backup.ExportMode
import com.example.data.backup.ExportOptions
import com.example.data.backup.PlainConfig
import com.example.data.model.TunnelConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ConfigRepository(
    private val dao: TunnelConfigDao,
    private val context: Context
) {

    val allConfigs: Flow<List<TunnelConfig>> = dao.getAllConfigs()

    val selectedConfig: Flow<TunnelConfig?> = dao.getSelectedConfig()

    suspend fun getSelectedConfigSync(): TunnelConfig? = dao.getSelectedConfigSync()

    suspend fun getConfigById(id: Long): TunnelConfig? = dao.getConfigById(id)

    suspend fun saveConfig(
        config: TunnelConfig,
        rawSshPassword: String? = null,
        rawProxyPassword: String? = null
    ): Long {
        val encryptedSshPass = if (rawSshPassword != null) {
            KeystoreHelper.encrypt(rawSshPassword)
        } else config.sshPasswordEncrypted

        val encryptedProxyPass = if (rawProxyPassword != null) {
            KeystoreHelper.encrypt(rawProxyPassword)
        } else config.proxyPasswordEncrypted

        val count = dao.getConfigCount()
        val toSave = config.copy(
            sshPasswordEncrypted = encryptedSshPass,
            proxyPasswordEncrypted = encryptedProxyPass,
            isSelected = if (count == 0) true else config.isSelected
        )

        val id = if (toSave.id == 0L) {
            dao.insertConfig(toSave)
        } else {
            dao.updateConfig(toSave)
            toSave.id
        }

        if (toSave.isSelected) {
            dao.setSelectedConfig(id)
        }

        return id
    }

    /**
     * Stores a server fetched from the remote list in one fixed row (replaced on every connect),
     * so the VPN service can load it by id like any other config.
     */
    suspend fun upsertRemote(c: PlainConfig): TunnelConfig {
        val row = TunnelConfig(
            id = REMOTE_ID,
            name = c.name,
            sshHost = c.sshHost,
            sshPort = c.sshPort,
            sshUsername = c.sshUsername,
            sshPasswordEncrypted = KeystoreHelper.encrypt(c.sshPassword),
            sshKeyContent = c.sshKeyContent,
            sshKeyFileName = c.sshKeyFileName,
            proxyHost = c.proxyHost,
            proxyPort = c.proxyPort,
            proxyUsername = c.proxyUsername,
            proxyPasswordEncrypted = KeystoreHelper.encrypt(c.proxyPassword),
            payload = c.payload.ifBlank { TunnelConfig(name = "", sshHost = "", sshUsername = "").payload },
            isSelected = false,
            tlsEnabled = c.tlsEnabled,
            sniHost = c.sniHost,
            tlsVerify = c.tlsVerify,
            countryCode = c.countryCode
        )
        dao.insertConfig(row)
        return row
    }

    suspend fun selectConfig(id: Long) {
        dao.setSelectedConfig(id)
    }

    suspend fun deleteConfig(config: TunnelConfig) {
        dao.deleteConfig(config)
        // If deleted was selected, select the first available
        val remaining = dao.getSelectedConfigSync()
        if (remaining == null) {
            val count = dao.getConfigCount()
            if (count > 0) {
                // select any
            }
        }
    }

    /**
     * Serialises configs (secrets decrypted from the device keystore) according to [options].
     * Locked configs can never be exported.
     */
    suspend fun exportConfigs(configs: List<TunnelConfig>, options: ExportOptions): ByteArray =
        withContext(Dispatchers.Default) {
            val exportable = configs.filter { !it.locked }
            if (exportable.isEmpty()) throw BackupException("Locked configs cannot be exported")
            val plain = exportable.map {
                PlainConfig(
                    name = it.name,
                    sshHost = it.sshHost,
                    sshPort = it.sshPort,
                    sshUsername = it.sshUsername,
                    sshPassword = KeystoreHelper.decrypt(it.sshPasswordEncrypted),
                    sshKeyContent = it.sshKeyContent,
                    sshKeyFileName = it.sshKeyFileName,
                    proxyHost = it.proxyHost,
                    proxyPort = it.proxyPort,
                    proxyUsername = it.proxyUsername,
                    proxyPassword = KeystoreHelper.decrypt(it.proxyPasswordEncrypted),
                    payload = it.payload,
                    tlsEnabled = it.tlsEnabled,
                    sniHost = it.sniHost,
                    tlsVerify = it.tlsVerify,
                    countryCode = it.countryCode
                )
            }
            val json = ConfigBackup.toJson(plain)
            when (options.mode) {
                ExportMode.PLAIN -> json
                ExportMode.PASSWORD -> {
                    val pw = options.password
                    if (pw.isNullOrEmpty()) throw BackupException("A password is required")
                    ConfigBackup.encrypt(json, pw)
                }
                ExportMode.LOCKED -> ConfigBackup.encryptLocked(json, options.password)
            }
        }

    /**
     * Imports configs from a backup file; returns how many were added. Files sealed as "locked" produce
     * locked configs: their details are stored only as a keystore-encrypted blob and never shown.
     */
    suspend fun importConfigs(data: ByteArray, password: String?): Int {
        val kind = ConfigBackup.kind(data)
        val locked = kind == BackupKind.LOCKED || kind == BackupKind.LOCKED_PASSWORD
        val items = withContext(Dispatchers.Default) {
            val json = when (kind) {
                BackupKind.PASSWORD -> {
                    if (password.isNullOrEmpty()) throw BackupException("A password is required")
                    ConfigBackup.decrypt(data, password)
                }
                BackupKind.LOCKED, BackupKind.LOCKED_PASSWORD -> ConfigBackup.decryptLocked(data, password)
                BackupKind.PLAIN_JSON -> data
            }
            ConfigBackup.fromJson(json)
        }
        for (c in items) {
            if (locked) {
                val blob = withContext(Dispatchers.Default) {
                    KeystoreHelper.encryptStrict(String(ConfigBackup.toJson(listOf(c)), Charsets.UTF_8))
                }
                saveConfig(
                    TunnelConfig(
                        name = c.name,
                        sshHost = "locked",
                        sshPort = 22,
                        sshUsername = "locked",
                        proxyHost = if (c.proxyHost.isNotBlank()) "locked" else "",
                        proxyPort = 1,
                        payload = "",
                        locked = true,
                        lockedBlob = blob,
                        tlsEnabled = c.tlsEnabled,
                        countryCode = c.countryCode
                    )
                )
            } else {
                saveConfig(
                    TunnelConfig(
                        name = c.name,
                        sshHost = c.sshHost,
                        sshPort = c.sshPort,
                        sshUsername = c.sshUsername,
                        sshKeyContent = c.sshKeyContent,
                        sshKeyFileName = c.sshKeyFileName,
                        proxyHost = c.proxyHost,
                        proxyPort = c.proxyPort,
                        proxyUsername = c.proxyUsername,
                        payload = c.payload.ifBlank { TunnelConfig(name = "", sshHost = "", sshUsername = "").payload },
                        tlsEnabled = c.tlsEnabled,
                        sniHost = c.sniHost,
                        tlsVerify = c.tlsVerify,
                        countryCode = c.countryCode
                    ),
                    rawSshPassword = c.sshPassword,
                    rawProxyPassword = c.proxyPassword
                )
            }
        }
        return items.size
    }

    /** Returns the config with its real details. For locked configs they exist only in memory, for the engine. */
    suspend fun unlock(config: TunnelConfig): TunnelConfig {
        if (!config.locked) return config
        return withContext(Dispatchers.Default) {
            val c = ConfigBackup.fromJson(KeystoreHelper.decryptStrict(config.lockedBlob).toByteArray(Charsets.UTF_8)).first()
            config.copy(
                sshHost = c.sshHost,
                sshPort = c.sshPort,
                sshUsername = c.sshUsername,
                sshPasswordEncrypted = KeystoreHelper.encrypt(c.sshPassword),
                sshKeyContent = c.sshKeyContent,
                sshKeyFileName = c.sshKeyFileName,
                proxyHost = c.proxyHost,
                proxyPort = c.proxyPort,
                proxyUsername = c.proxyUsername,
                proxyPasswordEncrypted = KeystoreHelper.encrypt(c.proxyPassword),
                payload = c.payload.ifBlank { TunnelConfig(name = "", sshHost = "", sshUsername = "").payload },
                tlsEnabled = c.tlsEnabled,
                sniHost = c.sniHost,
                tlsVerify = c.tlsVerify,
                countryCode = c.countryCode,
                lockedBlob = ""
            )
        }
    }

    fun decryptPassword(encrypted: String): String {
        return KeystoreHelper.decrypt(encrypted)
    }

    suspend fun seedDefaultsIfEmpty() {
        if (dao.getConfigCount() == 0) {
            val defaultPayload = "CONNECT [host]:[port] HTTP/1.1[crlf]Host: [host][crlf]Connection: keep-alive[crlf][crlf]"

            val sample1 = TunnelConfig(
                name = "My Server",
                sshHost = "example.com",
                sshPort = 22,
                sshUsername = "user",
                sshPasswordEncrypted = KeystoreHelper.encrypt("password123"),
                proxyHost = "proxy.example.com",
                proxyPort = 8080,
                proxyUsername = "user",
                proxyPasswordEncrypted = KeystoreHelper.encrypt("proxypass"),
                payload = defaultPayload,
                isSelected = true
            )
            val sample2 = TunnelConfig(
                name = "Work",
                sshHost = "work.example.com",
                sshPort = 22,
                sshUsername = "worker",
                sshPasswordEncrypted = KeystoreHelper.encrypt("workpass"),
                proxyHost = "",
                proxyPort = 8080,
                payload = defaultPayload,
                isSelected = false
            )
            val sample3 = TunnelConfig(
                name = "Test",
                sshHost = "test.example.com",
                sshPort = 22,
                sshUsername = "tester",
                sshPasswordEncrypted = KeystoreHelper.encrypt("testpass"),
                proxyHost = "",
                proxyPort = 8080,
                payload = defaultPayload,
                isSelected = false
            )
            val sample4 = TunnelConfig(
                name = "Backup",
                sshHost = "backup.example.com",
                sshPort = 22,
                sshUsername = "backup",
                sshPasswordEncrypted = KeystoreHelper.encrypt("backuppass"),
                proxyHost = "",
                proxyPort = 8080,
                payload = defaultPayload,
                isSelected = false
            )

            dao.insertConfig(sample1)
            dao.insertConfig(sample2)
            dao.insertConfig(sample3)
            dao.insertConfig(sample4)
        }
    }

    companion object {
        const val REMOTE_ID = 1_000_000L
    }
}

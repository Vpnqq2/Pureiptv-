package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.TunnelConfig
import kotlinx.coroutines.flow.Flow

@Dao
interface TunnelConfigDao {

    @Query("SELECT * FROM tunnel_configs ORDER BY createdAt DESC")
    fun getAllConfigs(): Flow<List<TunnelConfig>>

    @Query("SELECT * FROM tunnel_configs WHERE id = :id LIMIT 1")
    suspend fun getConfigById(id: Long): TunnelConfig?

    @Query("SELECT * FROM tunnel_configs WHERE isSelected = 1 LIMIT 1")
    fun getSelectedConfig(): Flow<TunnelConfig?>

    @Query("SELECT * FROM tunnel_configs WHERE isSelected = 1 LIMIT 1")
    suspend fun getSelectedConfigSync(): TunnelConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(config: TunnelConfig): Long

    @Update
    suspend fun updateConfig(config: TunnelConfig)

    @Delete
    suspend fun deleteConfig(config: TunnelConfig)

    @Query("UPDATE tunnel_configs SET isSelected = 0")
    suspend fun clearSelection()

    @Query("UPDATE tunnel_configs SET isSelected = CASE WHEN id = :id THEN 1 ELSE 0 END")
    suspend fun setSelectedConfig(id: Long)

    @Query("SELECT COUNT(*) FROM tunnel_configs")
    suspend fun getConfigCount(): Int
}

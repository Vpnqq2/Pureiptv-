package com.example.data.remote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Downloads flag images once and keeps them on disk, so they also show without internet. */
object FlagLoader {

    private const val MAX_BYTES = 600_000
    private const val MAX_WIDTH = 256

    suspend fun load(context: Context, url: String): Bitmap? = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://")) return@withContext null
        val file = cacheFile(context, url)
        if (!file.exists()) {
            runCatching { download(url, file) }
        }
        if (!file.exists()) return@withContext null
        decode(file) ?: run { file.delete(); null }
    }

    /** Makes sure the image is on disk (used when the server list is refreshed). */
    suspend fun prefetch(context: Context, url: String) {
        withContext(Dispatchers.IO) {
            if (!url.startsWith("https://")) return@withContext
            val file = cacheFile(context, url)
            if (!file.exists()) runCatching { download(url, file) }
        }
    }

    private fun cacheFile(context: Context, url: String): File {
        val dir = File(context.filesDir, "flags").apply { mkdirs() }
        val name = MessageDigest.getInstance("SHA-256").digest(url.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(32)
        return File(dir, "$name.img")
    }

    private fun download(url: String, target: File) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            if (conn.responseCode != 200) return
            val out = java.io.ByteArrayOutputStream()
            conn.inputStream.use { input ->
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) return
                    out.write(buf, 0, n)
                }
            }
            val bytes = out.toByteArray()
            // keep only real images
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0) return
            val tmp = File(target.parentFile, target.name + ".tmp")
            tmp.writeBytes(bytes)
            tmp.renameTo(target)
        } finally {
            conn.disconnect()
        }
    }

    private fun decode(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= MAX_WIDTH) sample *= 2
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}

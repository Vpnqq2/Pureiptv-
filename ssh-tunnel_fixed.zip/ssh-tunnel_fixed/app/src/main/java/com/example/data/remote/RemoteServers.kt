package com.example.data.remote

import android.content.Context
import com.example.core.logs.LogManager
import com.example.data.backup.BackupKind
import com.example.data.backup.ConfigBackup
import com.example.data.backup.PlainConfig
import com.example.data.local.KeystoreHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import kotlin.random.Random

/** A server picked from the remote list, ready to connect, plus what the UI shows about it. */
data class PickedServer(val config: PlainConfig, val ip: String, val flagUrl: String)

/**
 * Downloads the server list (JSON in the app's export format) from the encrypted links in [RemoteUrls],
 * keeps an encrypted copy for offline use, and picks a random server.
 *
 * The file may be plain JSON or a "locked" export without password (readable only by this app).
 */
object RemoteServers {

    private const val CACHE_FILE = "servers.cache"
    private const val MAX_BYTES = 1_000_000

    suspend fun pick(context: Context, exclude: String? = null): PickedServer = withContext(Dispatchers.IO) {
        val list = load(context)
        val candidates = list.filter { it.sshHost != exclude }.ifEmpty { list }
        val chosen = candidates[Random.nextInt(candidates.size)]
        if (chosen.flagUrl.isNotBlank()) FlagLoader.prefetch(context, chosen.flagUrl)
        PickedServer(chosen, resolveIp(chosen.sshHost), chosen.flagUrl)
    }

    /** Downloads the list and stores it when it changed. Safe to call any time; failures are ignored. */
    suspend fun refresh(context: Context): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val data = download()
            val servers = parse(data) // must be valid before it replaces the saved copy
            servers.map { it.flagUrl }.filter { it.isNotBlank() }.distinct().forEach { FlagLoader.prefetch(context, it) }
            val text = String(data, Charsets.ISO_8859_1)
            val cache = File(context.filesDir, CACHE_FILE)
            val old = if (cache.exists()) runCatching { KeystoreHelper.decrypt(cache.readText()) }.getOrNull() else null
            if (old == text) false else {
                cache.writeText(KeystoreHelper.encrypt(text))
                true
            }
        }.getOrDefault(false)
    }

    /** Saved servers first (works offline); downloads only when nothing is saved yet. */
    private fun load(context: Context): List<PlainConfig> {
        val cache = File(context.filesDir, CACHE_FILE)
        if (cache.exists()) {
            val cached = runCatching {
                parse(KeystoreHelper.decrypt(cache.readText()).toByteArray(Charsets.ISO_8859_1))
            }.getOrNull()
            if (!cached.isNullOrEmpty()) return cached
        }
        val fresh = try {
            download()
        } catch (e: RemoteException) {
            throw RemoteException("Can't reach the server list (${e.message}). Check your internet connection and try again.")
        }
        val parsed = runCatching { parse(fresh) }.getOrNull()
            ?: throw RemoteException("The server list is not valid.")
        runCatching { cache.writeText(KeystoreHelper.encrypt(String(fresh, Charsets.ISO_8859_1))) }
        return parsed
    }

    private fun parse(data: ByteArray): List<PlainConfig> {
        val json = when (ConfigBackup.kind(data)) {
            BackupKind.PLAIN_JSON -> data
            BackupKind.LOCKED -> ConfigBackup.decryptLocked(data, null)
            else -> throw RemoteException("Unsupported server list format")
        }
        return ConfigBackup.fromJson(json)
    }

    /** Tries every link (primary first, then fallbacks), twice each. Throws a short reason code if all fail. */
    private fun download(): ByteArray {
        val urls = RemoteUrls.all()
        if (urls.isEmpty()) throw RemoteException("no links")
        var reason = "unknown"
        for (url in urls) {
            repeat(2) {
                try {
                    return fetch(url)
                } catch (e: RemoteException) {
                    reason = e.message ?: reason
                } catch (e: java.net.UnknownHostException) {
                    reason = "DNS"
                } catch (e: java.net.SocketTimeoutException) {
                    reason = "timeout"
                } catch (e: javax.net.ssl.SSLException) {
                    reason = "TLS"
                } catch (e: java.io.IOException) {
                    reason = "network"
                }
            }
        }
        LogManager.w("Server list download failed: $reason")
        throw RemoteException(reason)
    }

    private fun fetch(url: String): ByteArray {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            conn.useCaches = false
            conn.setRequestProperty("Cache-Control", "no-cache")
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android)")
            if (conn.responseCode != 200) throw RemoteException("HTTP ${conn.responseCode}")
            conn.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) throw RemoteException("too large")
                    out.write(buf, 0, n)
                }
                return out.toByteArray()
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun resolveIp(host: String): String =
        runCatching { InetAddress.getByName(host).hostAddress }.getOrNull() ?: host
}

class RemoteException(message: String) : Exception(message)

package com.example.data.remote

import com.example.data.backup.AppSecret
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import android.util.Base64

/**
 * Server-list URLs, stored AES-256-GCM encrypted (no plain URL in the APK, so `strings` / jadx searches
 * for "http" or "github" find nothing). They are decrypted only in memory, only over HTTPS.
 *
 * First entry = primary link, the rest = fallbacks tried in order when the primary is blocked or down.
 * To change them run:  python3 tools/encrypt_urls.py <url1> <url2> ...  and paste the output below.
 *
 * Honest limit: the app must be able to read the URL, so a determined person who reverse-engineers the
 * APK can still recover it. Keep the list itself protected too (use a "locked" export for servers.json).
 */
internal object RemoteUrls {

    private val blobs = listOf(
        "LasGtJXB3mKIvVG3PNnAglMR/MgxQBTaGxjT0VDg6PdoSwohuE6TXYGhirw89nyKYfYKyUlRoz81wzKcuHyic5Ee3r3rUaB3E9U7t7wCeHrxomwVfCOzbMV61lY+vWAE62RvFx16AAv9f3g=",
        "awZfyJTcQoCuCv9HULBAyexH8svbWsxWq2hxPlpkB/THP6fJbi96eSqK4tzDTie917La+I4Kgltxf6C7TXQwbNXE0Go2tgCQcEaFeFucZOUqi0cU2GfrnUMI",
        "8pDoB2nuDxWKAAiC/SUp2shoVrSNaJIB7rUBHnPX+hRZi1Sw2ik+8DFUOUsetNT6Ytvaa6VCpp6K2duICl70Vk2zzUzMVEayC/yHARaZMiB0iJNamNc=",
    )

    private const val PURPOSE = "urls-v1"

    fun all(): List<String> {
        val key = MessageDigest.getInstance("SHA-256").run {
            update(AppSecret.material())
            update(PURPOSE.toByteArray())
            digest()
        }
        return blobs.mapNotNull { blob ->
            runCatching {
                val raw = Base64.decode(blob, Base64.NO_WRAP)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
                String(cipher.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
            }.getOrNull()?.takeIf { it.startsWith("https://") }
        }
    }
}

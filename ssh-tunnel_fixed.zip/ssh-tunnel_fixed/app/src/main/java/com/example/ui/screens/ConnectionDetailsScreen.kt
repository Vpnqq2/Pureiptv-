package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionState
import com.example.data.model.TrafficStats
import com.example.data.model.TunnelConfig
import com.example.ui.theme.AccentBlueLight
import com.example.ui.theme.AccentCyanGlow
import com.example.ui.theme.CardBackground
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.ConnectedGreenDark
import com.example.ui.theme.ConnectedGreenLight
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepNavySurfaceVariant
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ConnectionDetailsScreen(
    config: TunnelConfig?,
    trafficStats: TrafficStats,
    connectionState: ConnectionState,
    onBack: () -> Unit
) {
    val isConnected = connectionState.isConnected

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .statusBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("details_back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "Connection Details",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Top Status Chips/Cards
            // 1. SSH Status
            ComponentStatusCard(
                icon = Icons.Default.Terminal,
                title = "SSH",
                subtitle = config?.displayHostPort() ?: "example.com:22",
                statusBadgeText = if (isConnected) "Connected" else "Idle",
                badgeActive = isConnected
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Proxy Status
            val hasProxy = config?.hasProxy() == true
            ComponentStatusCard(
                icon = Icons.Default.Dns,
                title = "Proxy",
                subtitle = config?.displayProxy() ?: "Direct (No Proxy)",
                statusBadgeText = if (hasProxy) (if (isConnected) "Connected" else "Configured") else "Inactive",
                badgeActive = hasProxy && isConnected
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Payload Status
            val hasPayload = config?.hasPayload() == true
            ComponentStatusCard(
                icon = Icons.Default.Code,
                title = "Payload",
                subtitle = if (hasPayload) "Custom HTTP" else "Standard HTTP CONNECT",
                statusBadgeText = if (isConnected && hasPayload) "Active" else if (hasPayload) "Ready" else "Default",
                badgeActive = isConnected && hasPayload
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Section 2: Traffic Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardBackground)
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = AccentBlueLight,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Traffic",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    TrafficRow(
                        icon = Icons.Default.ArrowDownward,
                        iconTint = AccentBlueLight,
                        label = "Download",
                        value = trafficStats.formattedDownload()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    TrafficRow(
                        icon = Icons.Default.ArrowUpward,
                        iconTint = AccentCyanGlow,
                        label = "Upload",
                        value = trafficStats.formattedUpload()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    TrafficRow(
                        icon = Icons.Default.Speed,
                        iconTint = ConnectedGreenLight,
                        label = "Total",
                        value = trafficStats.formattedTotal()
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Section 3: Duration Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardBackground)
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = AccentBlueLight,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Duration",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Text(
                        text = trafficStats.formattedDuration(),
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ComponentStatusCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    statusBadgeText: String,
    badgeActive: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBackground)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(DeepNavySurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = AccentBlueLight,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = title,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
            }

            // Green Pill Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (badgeActive) ConnectedGreenDark else DeepNavySurfaceVariant)
                    .border(
                        1.dp,
                        if (badgeActive) ConnectedGreen else SurfaceBorder,
                        RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = statusBadgeText,
                    color = if (badgeActive) ConnectedGreenLight else TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun TrafficRow(
    icon: ImageVector,
    iconTint: Color,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = label, color = TextMuted, fontSize = 14.sp)
        }
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

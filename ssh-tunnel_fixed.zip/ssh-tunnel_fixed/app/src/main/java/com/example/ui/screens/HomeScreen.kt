package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionState
import com.example.data.model.ConnectionStep
import com.example.data.model.TrafficStats
import com.example.data.model.TunnelConfig
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentBlueLight
import com.example.ui.theme.AccentCyanGlow
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardBackgroundElevated
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.ConnectedGreenDark
import com.example.ui.theme.ConnectedGreenLight
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.DeepNavySurfaceVariant
import com.example.ui.theme.DisconnectRed
import com.example.ui.theme.DisconnectRedDark
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningYellow

@Composable
fun HomeScreen(
    connectionState: ConnectionState,
    selectedConfig: TunnelConfig?,
    trafficStats: TrafficStats,
    onConnectClicked: () -> Unit,
    onDisconnectClicked: () -> Unit,
    onConfigCardClicked: () -> Unit,
    onSettingsClicked: () -> Unit,
    onServerCardClicked: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .statusBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top App Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onConfigCardClicked,
                    modifier = Modifier.testTag("menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = TextPrimary
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "SSH Tunnel",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "SSH + Proxy + Payload",
                        color = TextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal
                    )
                }

                IconButton(
                    onClick = onSettingsClicked,
                    modifier = Modifier.testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (connectionState) {
                is ConnectionState.Idle, is ConnectionState.Failed -> {
                    // SCREEN 1: Disconnected Home View
                    DisconnectedView(
                        selectedConfig = selectedConfig,
                        trafficStats = trafficStats,
                        errorMessage = (connectionState as? ConnectionState.Failed)?.reason,
                        onConnectClicked = onConnectClicked,
                        onConfigCardClicked = onConfigCardClicked
                    )
                }
                is ConnectionState.Connecting, is ConnectionState.Reconnecting -> {
                    // SCREEN 4: Connecting Stepper View
                    ConnectingView(
                        state = connectionState,
                        onCancelClicked = onDisconnectClicked
                    )
                }
                is ConnectionState.Connected -> {
                    // SCREEN 5: Connected View
                    ConnectedView(
                        selectedConfig = selectedConfig,
                        trafficStats = trafficStats,
                        onDisconnectClicked = onDisconnectClicked,
                        onServerCardClicked = onServerCardClicked
                    )
                }
            }
        }
    }
}

@Composable
private fun DisconnectedView(
    selectedConfig: TunnelConfig?,
    trafficStats: TrafficStats,
    errorMessage: String?,
    onConnectClicked: () -> Unit,
    onConfigCardClicked: () -> Unit
) {
    Spacer(modifier = Modifier.height(24.dp))

    // Big Circular Power Button with blue glow
    Box(
        modifier = Modifier
            .size(200.dp)
            .testTag("connect_power_button"),
        contentAlignment = Alignment.Center
    ) {
        // Outer glowing ring
        Box(
            modifier = Modifier
                .size(190.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            AccentCyanGlow.copy(alpha = 0.35f),
                            AccentBlueLight.copy(alpha = 0.15f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Mid circle border
        Box(
            modifier = Modifier
                .size(160.dp)
                .clip(CircleShape)
                .border(3.dp, AccentBlueLight, CircleShape)
                .background(DeepNavySurface)
        )

        // Inner button
        Box(
            modifier = Modifier
                .size(136.dp)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF1E293B),
                            Color(0xFF0F172A)
                        )
                    )
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = AccentCyanGlow),
                    onClick = onConnectClicked
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.PowerSettingsNew,
                contentDescription = "Connect",
                tint = AccentBlueLight,
                modifier = Modifier.size(54.dp)
            )
        }
    }

    Spacer(modifier = Modifier.height(28.dp))

    Text(
        text = "Disconnected",
        color = TextPrimary,
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
        text = "Tap to connect",
        color = TextMuted,
        fontSize = 14.sp
    )

    if (!errorMessage.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = errorMessage,
            color = DisconnectRed,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }

    Spacer(modifier = Modifier.height(36.dp))

    // Current Config Card
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBackground)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onConfigCardClicked)
            .padding(16.dp)
            .testTag("current_config_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(DeepNavySurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = AccentBlueLight,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = "Current Config",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                    Text(
                        text = selectedConfig?.name ?: "No Config Selected",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Select config",
                tint = TextMuted,
                modifier = Modifier.size(22.dp)
            )
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Stats Card (Download, Upload, Duration)
    StatsCard(
        trafficStats = trafficStats,
        showTrafficTotal = false
    )
}

@Composable
private fun ConnectingView(
    state: ConnectionState,
    onCancelClicked: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Spacer(modifier = Modifier.height(20.dp))

    // Spinner Ring
    Box(
        modifier = Modifier
            .size(180.dp)
            .scale(pulseScale),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(150.dp),
            color = AccentBlueLight,
            strokeWidth = 4.dp,
            strokeCap = StrokeCap.Round
        )
    }

    Spacer(modifier = Modifier.height(20.dp))

    val currentStep = (state as? ConnectionState.Connecting)?.step
    val reconnectAttempt = (state as? ConnectionState.Reconnecting)?.attempt

    Text(
        text = if (state is ConnectionState.Reconnecting) "Reconnecting..." else "Connecting...",
        color = TextPrimary,
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
        text = if (state is ConnectionState.Reconnecting) {
            "Attempt $reconnectAttempt • Retrying in ${(state).delaySec}s"
        } else {
            (state as? ConnectionState.Connecting)?.message ?: "Setting up tunnel"
        },
        color = TextMuted,
        fontSize = 14.sp
    )

    Spacer(modifier = Modifier.height(28.dp))

    // Vertical Stepper (Screen 4)
    val steps = ConnectionStep.values()
    val activeOrder = currentStep?.order ?: 1

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBackground)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
            .padding(vertical = 16.dp, horizontal = 20.dp)
    ) {
        steps.forEach { step ->
            val isDone = step.order < activeOrder
            val isCurrent = step.order == activeOrder
            val isPending = step.order > activeOrder

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                when {
                    isDone -> {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Completed",
                            tint = ConnectedGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    isCurrent -> {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .border(2.dp, AccentBlueLight, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(AccentBlueLight)
                            )
                        }
                    }
                    else -> {
                        Icon(
                            imageVector = Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Pending",
                            tint = TextMuted.copy(alpha = 0.5f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Text(
                    text = step.displayName,
                    color = when {
                        isDone -> TextPrimary
                        isCurrent -> AccentBlueLight
                        else -> TextMuted
                    },
                    fontSize = 14.sp,
                    fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }

    Spacer(modifier = Modifier.height(28.dp))

    // Cancel Button
    OutlinedButton(
        onClick = onCancelClicked,
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("cancel_connecting_button"),
        shape = RoundedCornerShape(14.dp),
        border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = Brush.horizontalGradient(listOf(SurfaceBorderHighlight, SurfaceBorderHighlight))
        ),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = TextPrimary
        )
    ) {
        Text("Cancel", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ConnectedView(
    selectedConfig: TunnelConfig?,
    trafficStats: TrafficStats,
    onDisconnectClicked: () -> Unit,
    onServerCardClicked: () -> Unit
) {
    Spacer(modifier = Modifier.height(24.dp))

    // Green Shield Ring (Screen 5)
    Box(
        modifier = Modifier.size(190.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer glowing green ring
        Box(
            modifier = Modifier
                .size(180.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            ConnectedGreen.copy(alpha = 0.30f),
                            ConnectedGreenDark.copy(alpha = 0.15f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Green border
        Box(
            modifier = Modifier
                .size(150.dp)
                .clip(CircleShape)
                .border(3.dp, ConnectedGreen, CircleShape)
                .background(DeepNavySurface),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = "Shield Connected",
                tint = ConnectedGreen,
                modifier = Modifier.size(56.dp)
            )
        }
    }

    Spacer(modifier = Modifier.height(24.dp))

    Text(
        text = "Connected",
        color = ConnectedGreen,
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold
    )

    Spacer(modifier = Modifier.height(4.dp))

    Text(
        text = trafficStats.formattedDuration(),
        color = TextPrimary,
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium
    )

    Spacer(modifier = Modifier.height(28.dp))

    // Traffic Stats Card (Download, Upload, Traffic)
    StatsCard(
        trafficStats = trafficStats,
        showTrafficTotal = true
    )

    Spacer(modifier = Modifier.height(14.dp))

    // Server Card
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBackground)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onServerCardClicked)
            .padding(16.dp)
            .testTag("server_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(DeepNavySurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Public,
                        contentDescription = null,
                        tint = AccentBlueLight,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = "Server",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                    Text(
                        text = selectedConfig?.displayHostPort() ?: "example.com:22",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Details",
                tint = TextMuted,
                modifier = Modifier.size(22.dp)
            )
        }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Red Disconnect Button
    Button(
        onClick = onDisconnectClicked,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("disconnect_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = DisconnectRed
        )
    ) {
        Icon(
            imageVector = Icons.Default.Stop,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "Disconnect",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun StatsCard(
    trafficStats: TrafficStats,
    showTrafficTotal: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBackground)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Download
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = AccentBlueLight,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Download", color = TextMuted, fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = trafficStats.formattedDownload(),
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Divider line
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(30.dp)
                    .background(SurfaceBorder)
            )

            // Upload
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = AccentCyanGlow,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Upload", color = TextMuted, fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = trafficStats.formattedUpload(),
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Divider line
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(30.dp)
                    .background(SurfaceBorder)
            )

            // Duration or Traffic
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (showTrafficTotal) Icons.Default.Security else Icons.Default.Schedule,
                        contentDescription = null,
                        tint = if (showTrafficTotal) ConnectedGreenLight else AccentBlueLight,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (showTrafficTotal) "Traffic" else "Duration",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (showTrafficTotal) trafficStats.formattedTotal() else trafficStats.formattedDuration(),
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

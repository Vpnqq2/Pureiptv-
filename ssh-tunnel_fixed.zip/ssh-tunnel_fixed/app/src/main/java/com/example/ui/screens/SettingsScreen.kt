package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppSettings
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentBlueLight
import com.example.ui.theme.CardBackground
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.DeepNavySurfaceVariant
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onUpdateSettings: (AppSettings) -> Unit,
    onBack: () -> Unit
) {
    var showGeneralDialog by remember { mutableStateOf(false) }
    var showDnsDialog by remember { mutableStateOf(false) }
    var showAdvancedDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .statusBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "Settings",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Card 1: General
            SettingsItemCard(
                icon = Icons.Default.Settings,
                title = "General",
                subtitle = "App behavior, notifications",
                onClick = { showGeneralDialog = true },
                tag = "settings_general"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Card 2: DNS
            SettingsItemCard(
                icon = Icons.Default.Public,
                title = "DNS",
                subtitle = "Custom DNS settings",
                onClick = { showDnsDialog = true },
                tag = "settings_dns"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Card 3: Advanced
            SettingsItemCard(
                icon = Icons.Default.Tune,
                title = "Advanced",
                subtitle = "MTU, timeouts, reconnect",
                onClick = { showAdvancedDialog = true },
                tag = "settings_advanced"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Card 4: About
            SettingsItemCard(
                icon = Icons.Default.Info,
                title = "About",
                subtitle = "Version 1.0.0",
                onClick = { showAboutDialog = true },
                tag = "settings_about"
            )
        }
    }

    // Dialogs
    if (showGeneralDialog) {
        GeneralSettingsDialog(
            settings = settings,
            onSave = {
                onUpdateSettings(it)
                showGeneralDialog = false
            },
            onDismiss = { showGeneralDialog = false }
        )
    }

    if (showDnsDialog) {
        DnsSettingsDialog(
            settings = settings,
            onSave = {
                onUpdateSettings(it)
                showDnsDialog = false
            },
            onDismiss = { showDnsDialog = false }
        )
    }

    if (showAdvancedDialog) {
        AdvancedSettingsDialog(
            settings = settings,
            onSave = {
                onUpdateSettings(it)
                showAdvancedDialog = false
            },
            onDismiss = { showAdvancedDialog = false }
        )
    }

    if (showAboutDialog) {
        AboutDialog(onDismiss = { showAboutDialog = false })
    }
}

@Composable
private fun SettingsItemCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    tag: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBackground)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(18.dp)
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(DeepNavySurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = AccentBlueLight,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = title,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
private fun GeneralSettingsDialog(
    settings: AppSettings,
    onSave: (AppSettings) -> Unit,
    onDismiss: () -> Unit
) {
    var wakeLock by remember { mutableStateOf(settings.wakeLockEnabled) }
    var autoReconnect by remember { mutableStateOf(settings.autoReconnect) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepNavySurface,
        title = { Text("General Settings", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto Reconnect", color = TextPrimary, fontSize = 14.sp)
                        Text("Reconnect on connection drop", color = TextMuted, fontSize = 12.sp)
                    }
                    Switch(
                        checked = autoReconnect,
                        onCheckedChange = { autoReconnect = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentBlueLight)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Keep Connection Alive", color = TextPrimary, fontSize = 14.sp)
                        Text("Acquire partial wake lock while connected", color = TextMuted, fontSize = 12.sp)
                    }
                    Switch(
                        checked = wakeLock,
                        onCheckedChange = { wakeLock = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentBlueLight)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(settings.copy(wakeLockEnabled = wakeLock, autoReconnect = autoReconnect)) },
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextMuted) }
        }
    )
}

@Composable
private fun DnsSettingsDialog(
    settings: AppSettings,
    onSave: (AppSettings) -> Unit,
    onDismiss: () -> Unit
) {
    var primaryDns by remember { mutableStateOf(settings.primaryDns) }
    var secondaryDns by remember { mutableStateOf(settings.secondaryDns) }
    var tcpDns by remember { mutableStateOf(settings.enableTcpDns) }
    var udpgwEnabled by remember { mutableStateOf(settings.udpgwEnabled) }
    var udpgwPort by remember { mutableStateOf(settings.udpgwPort.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepNavySurface,
        title = { Text("DNS & UDP Settings", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = primaryDns,
                    onValueChange = { primaryDns = it },
                    label = { Text("Primary DNS", color = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                OutlinedTextField(
                    value = secondaryDns,
                    onValueChange = { secondaryDns = it },
                    label = { Text("Secondary DNS", color = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Resolve DNS on the server (recommended)", color = TextPrimary, fontSize = 13.sp)
                    Switch(
                        checked = tcpDns,
                        onCheckedChange = { tcpDns = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentBlueLight)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("UDP via UDPGW (games, calls)", color = TextPrimary, fontSize = 13.sp)
                    Switch(
                        checked = udpgwEnabled,
                        onCheckedChange = { udpgwEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentBlueLight)
                    )
                }

                if (udpgwEnabled) {
                    OutlinedTextField(
                        value = udpgwPort,
                        onValueChange = { v -> udpgwPort = v.filter { it.isDigit() }.take(5) },
                        label = { Text("UDPGW port on server (badvpn-udpgw)", color = TextMuted) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val port = udpgwPort.toIntOrNull()?.takeIf { it in 1..65535 } ?: 7300
                    onSave(
                        settings.copy(
                            primaryDns = primaryDns,
                            secondaryDns = secondaryDns,
                            enableTcpDns = tcpDns,
                            udpgwEnabled = udpgwEnabled,
                            udpgwPort = port
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextMuted) }
        }
    )
}

@Composable
private fun AdvancedSettingsDialog(
    settings: AppSettings,
    onSave: (AppSettings) -> Unit,
    onDismiss: () -> Unit
) {
    var mtuStr by remember { mutableStateOf(settings.mtu.toString()) }
    var timeoutStr by remember { mutableStateOf(settings.connectionTimeoutSec.toString()) }
    var maxRetriesStr by remember { mutableStateOf(settings.maxReconnectAttempts.toString()) }
    var blockIpv6 by remember { mutableStateOf(settings.blockIpv6) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepNavySurface,
        title = { Text("Advanced Settings", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = mtuStr,
                    onValueChange = { mtuStr = it },
                    label = { Text("MTU (Default 1500)", color = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                OutlinedTextField(
                    value = timeoutStr,
                    onValueChange = { timeoutStr = it },
                    label = { Text("Connection Timeout (seconds)", color = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                OutlinedTextField(
                    value = maxRetriesStr,
                    onValueChange = { maxRetriesStr = it },
                    label = { Text("Max Reconnect Attempts", color = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Block IPv6 Leak", color = TextPrimary, fontSize = 13.sp)
                        Text("Prevents non-tunneled IPv6 leaks", color = TextMuted, fontSize = 11.sp)
                    }
                    Switch(
                        checked = blockIpv6,
                        onCheckedChange = { blockIpv6 = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentBlueLight)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        settings.copy(
                            mtu = mtuStr.toIntOrNull() ?: 1500,
                            connectionTimeoutSec = timeoutStr.toIntOrNull() ?: 15,
                            maxReconnectAttempts = maxRetriesStr.toIntOrNull() ?: 5,
                            blockIpv6 = blockIpv6
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextMuted) }
        }
    )
}

@Composable
private fun AboutDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepNavySurface,
        title = { Text("SSH Tunnel", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Version 1.0.0", color = AccentBlueLight, fontSize = 14.sp)
                Text(
                    "A lightweight Android VPN client tunneling device traffic through SSH, HTTP Proxy, and custom Payload.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Data path: Apps -> VpnService -> TUN -> hev-socks5-tunnel -> local SOCKS5 (127.0.0.1) -> SSH dynamic forwarding -> [Proxy -> Payload] -> SSH server -> Internet",
                    color = TextMuted,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("OK", color = AccentBlueLight) }
        }
    )
}

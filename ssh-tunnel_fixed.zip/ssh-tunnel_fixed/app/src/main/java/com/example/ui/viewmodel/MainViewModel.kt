package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.SshTunnelApp
import com.example.core.logs.LogManager
import com.example.data.backup.ExportOptions
import com.example.core.vpn.TunnelController
import com.example.data.model.AppSettings
import com.example.data.model.ConnectionState
import com.example.data.model.LogEntry
import com.example.data.model.TrafficStats
import com.example.data.model.TunnelConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import com.example.data.remote.RemoteException
import com.example.data.remote.RemoteServers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as SshTunnelApp
    private val configRepo = app.configRepository
    private val settingsRepo = app.settingsRepository
    private val engine = TunnelController.getEngine(application)

    val allConfigs: StateFlow<List<TunnelConfig>> = configRepo.allConfigs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedConfig: StateFlow<TunnelConfig?> = configRepo.selectedConfig
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeConfig: StateFlow<TunnelConfig?> = TunnelController.activeConfig

    val settings: StateFlow<AppSettings> = settingsRepo.settings

    val connectionState: StateFlow<ConnectionState> = engine.state

    val trafficStats: StateFlow<TrafficStats> = engine.stats

    val logs: StateFlow<List<LogEntry>> = LogManager.logsFlow

    /** What the home screen shows about the server in use: country flag and IP. */
    data class ServerInfo(val countryCode: String, val ip: String, val flagUrl: String)

    private val _serverInfo = MutableStateFlow<ServerInfo?>(null)
    val serverInfo: StateFlow<ServerInfo?> = _serverInfo

    private val _fetching = MutableStateFlow(false)
    val fetching: StateFlow<Boolean> = _fetching

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private var lastHost: String? = null

    init {
        // Pick up server-list updates in the background so the next connect already uses them.
        viewModelScope.launch { RemoteServers.refresh(getApplication()) }
    }

    fun clearError() { _error.value = null }

    /**
     * Downloads the server list, picks a random server and stores it for the VPN service.
     * [onReady] receives the config to connect with.
     */
    fun pickRandomServer(onReady: (TunnelConfig) -> Unit) {
        if (_fetching.value) return
        _error.value = null
        _fetching.value = true
        viewModelScope.launch {
            try {
                val picked = RemoteServers.pick(getApplication(), lastHost)
                lastHost = picked.config.sshHost
                val row = configRepo.upsertRemote(picked.config)
                _serverInfo.value = ServerInfo(picked.config.countryCode, picked.ip, picked.flagUrl)
                onReady(row)
            } catch (e: Exception) {
                _error.value = (e as? RemoteException)?.message ?: "Couldn't load a server. Try again."
            } finally {
                _fetching.value = false
            }
        }
    }

    fun selectConfig(id: Long) {
        viewModelScope.launch {
            configRepo.selectConfig(id)
        }
    }

    fun saveConfig(
        config: TunnelConfig,
        rawSshPassword: String? = null,
        rawProxyPassword: String? = null,
        onSaved: () -> Unit = {}
    ) {
        viewModelScope.launch {
            configRepo.saveConfig(config, rawSshPassword, rawProxyPassword)
            onSaved()
        }
    }

    fun deleteConfig(config: TunnelConfig) {
        viewModelScope.launch {
            configRepo.deleteConfig(config)
        }
    }

    /** Writes the given configs to [uri], protected as described by [options]. */
    fun exportConfigs(
        configs: List<TunnelConfig>,
        options: ExportOptions,
        uri: Uri,
        onResult: (Result<Int>) -> Unit
    ) {
        viewModelScope.launch {
            val result = runCatching {
                val bytes = configRepo.exportConfigs(configs, options)
                withContext(Dispatchers.IO) {
                    val out = getApplication<Application>().contentResolver.openOutputStream(uri, "w")
                        ?: throw IOException("Cannot open the destination file")
                    out.use { it.write(bytes) }
                }
                configs.size
            }
            onResult(result)
        }
    }

    /** Reads a (small) backup file; returns null when it cannot be read or is too large. */
    fun readBackupFile(uri: Uri, onResult: (ByteArray?) -> Unit) {
        viewModelScope.launch {
            val bytes = withContext(Dispatchers.IO) {
                runCatching {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { it.readLimited(2_000_000) }
                }.getOrNull()
            }
            onResult(bytes)
        }
    }

    fun importConfigs(data: ByteArray, password: String?, onResult: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            onResult(runCatching { configRepo.importConfigs(data, password) })
        }
    }

    private fun InputStream.readLimited(max: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val n = read(buffer)
            if (n < 0) break
            total += n
            if (total > max) return null
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }

    fun updateSettings(newSettings: AppSettings) {
        settingsRepo.updateSettings(newSettings)
    }

    fun connect(context: Context, targetConfig: TunnelConfig? = null) {
        val configToUse = targetConfig ?: selectedConfig.value ?: allConfigs.value.firstOrNull()
        if (configToUse == null) {
            LogManager.e("No configuration available to connect")
            return
        }
        TunnelController.startTunnel(context, configToUse)
    }

    fun disconnect(context: Context) {
        TunnelController.stopTunnel(context)
    }

    fun clearLogs() {
        LogManager.clear()
    }

    fun decryptPassword(encrypted: String): String {
        return configRepo.decryptPassword(encrypted)
    }
}

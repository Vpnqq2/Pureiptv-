package com.example.data.backup

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ConfigBackupCryptoTest {

    private val sample = "{\"app\":\"ssh-tunnel\",\"configs\":[]}".toByteArray()

    @Test
    fun `encrypt then decrypt returns the original bytes`() {
        val blob = ConfigBackup.encrypt(sample, "correct horse battery staple")
        assertTrue(ConfigBackup.isEncrypted(blob))
        assertArrayEquals(sample, ConfigBackup.decrypt(blob, "correct horse battery staple"))
    }

    @Test
    fun `wrong password is rejected`() {
        val blob = ConfigBackup.encrypt(sample, "password-one")
        try {
            ConfigBackup.decrypt(blob, "password-two")
            fail("expected BackupException")
        } catch (_: BackupException) {
        }
    }

    @Test
    fun `tampered file is rejected`() {
        val blob = ConfigBackup.encrypt(sample, "password-one")
        blob[blob.size - 1] = (blob[blob.size - 1].toInt() xor 1).toByte()
        try {
            ConfigBackup.decrypt(blob, "password-one")
            fail("expected BackupException")
        } catch (_: BackupException) {
        }
    }

    @Test
    fun `plain json is not detected as encrypted`() {
        assertFalse(ConfigBackup.isEncrypted(sample))
    }

    @Test
    fun `locked file without password round trips and is detected`() {
        val blob = ConfigBackup.encryptLocked(sample, null)
        assertTrue(ConfigBackup.kind(blob) == BackupKind.LOCKED)
        assertFalse(ConfigBackup.needsPassword(blob))
        assertArrayEquals(sample, ConfigBackup.decryptLocked(blob, null))
    }

    @Test
    fun `locked file with password needs the right password`() {
        val blob = ConfigBackup.encryptLocked(sample, "a long shared passphrase")
        assertTrue(ConfigBackup.kind(blob) == BackupKind.LOCKED_PASSWORD)
        assertTrue(ConfigBackup.needsPassword(blob))
        assertArrayEquals(sample, ConfigBackup.decryptLocked(blob, "a long shared passphrase"))
        try {
            ConfigBackup.decryptLocked(blob, "wrong passphrase")
            fail("expected BackupException")
        } catch (_: BackupException) {
        }
        try {
            ConfigBackup.decryptLocked(blob, null)
            fail("expected BackupException")
        } catch (_: BackupException) {
        }
    }

    @Test
    fun `locked file does not contain the plaintext and tampering is rejected`() {
        val blob = ConfigBackup.encryptLocked(sample, null)
        assertFalse(String(blob, Charsets.ISO_8859_1).contains("ssh-tunnel"))
        blob[10] = (blob[10].toInt() xor 1).toByte()
        try {
            ConfigBackup.decryptLocked(blob, null)
            fail("expected BackupException")
        } catch (_: BackupException) {
        }
    }
}
